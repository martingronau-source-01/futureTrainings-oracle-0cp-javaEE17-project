-- phpMyAdmin SQL Dump
-- version 5.1.1deb5ubuntu1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Erstellungszeit: 08. Sep 2023 um 16:22
-- Server-Version: 10.6.12-MariaDB-0ubuntu0.22.04.1
-- PHP-Version: 8.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `hotelbooking`
--
DROP DATABASE IF EXISTS `hotelbooking`;
CREATE DATABASE IF NOT EXISTS `hotelbooking` DEFAULT CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci;
USE `hotelbooking`;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `booking`
--

CREATE TABLE `booking` (
  `ID` int(11) NOT NULL,
  `startDate` datetime DEFAULT NULL,
  `endDate` datetime NOT NULL,
  `hotelId` int(11) DEFAULT NULL,
  `roomOccupancyId` int(11) DEFAULT NULL,
  `paymentId` int(11) DEFAULT NULL,
  `accommodationsRawPrice` double DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `created` varchar(255) DEFAULT NULL,
  `hotel_id` int(11) NOT NULL,
  `count_accommodations` int(11) NOT NULL,
  `count_beds` int(11) NOT NULL,
  `count_rooms` int(11) NOT NULL,
  `end_date` varchar(255) DEFAULT NULL,
  `has_data` bit(1) NOT NULL,
  `hotel_description` varchar(255) DEFAULT NULL,
  `hotelemail` varchar(255) DEFAULT NULL,
  `hotel_location` varchar(255) DEFAULT NULL,
  `hotel_name` varchar(255) DEFAULT NULL,
  `hotel_phone` varchar(255) DEFAULT NULL,
  `hotel_street` varchar(255) DEFAULT NULL,
  `hotel_title` varchar(255) DEFAULT NULL,
  `hotel_website` varchar(255) DEFAULT NULL,
  `hotel_zipcode` varchar(255) DEFAULT NULL,
  `region_description` varchar(255) DEFAULT NULL,
  `region_id` int(11) NOT NULL,
  `region_name` varchar(255) DEFAULT NULL,
  `region_title` varchar(255) DEFAULT NULL,
  `start_date` varchar(255) DEFAULT NULL,
  `accommodation_position_mwst` double NOT NULL,
  `accommodations_raw_price` double NOT NULL,
  `booking_id` int(11) NOT NULL,
  `formatted_accommodations_position_mwst` varchar(255) DEFAULT NULL,
  `formatted_accommodations_raw_price` varchar(255) DEFAULT NULL,
  `formatted_mwst` varchar(255) DEFAULT NULL,
  `formatted_single_raw_price` varchar(255) DEFAULT NULL,
  `formatted_totalcost` varchar(255) DEFAULT NULL,
  `invoice_number` varchar(255) DEFAULT NULL,
  `mwst` double NOT NULL,
  `payment_id` int(11) NOT NULL,
  `room_name` varchar(255) DEFAULT NULL,
  `room_occupancy_id` int(11) NOT NULL,
  `room_title` varchar(255) DEFAULT NULL,
  `single_raw_price` double NOT NULL,
  `totalcost` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Daten für Tabelle `booking`
--

INSERT INTO `booking` (`ID`, `startDate`, `endDate`, `hotelId`, `roomOccupancyId`, `paymentId`, `accommodationsRawPrice`, `creator`, `created`, `hotel_id`, `count_accommodations`, `count_beds`, `count_rooms`, `end_date`, `has_data`, `hotel_description`, `hotelemail`, `hotel_location`, `hotel_name`, `hotel_phone`, `hotel_street`, `hotel_title`, `hotel_website`, `hotel_zipcode`, `region_description`, `region_id`, `region_name`, `region_title`, `start_date`, `accommodation_position_mwst`, `accommodations_raw_price`, `booking_id`, `formatted_accommodations_position_mwst`, `formatted_accommodations_raw_price`, `formatted_mwst`, `formatted_single_raw_price`, `formatted_totalcost`, `invoice_number`, `mwst`, `payment_id`, `room_name`, `room_occupancy_id`, `room_title`, `single_raw_price`, `totalcost`) VALUES
(92, '2023-09-05 00:00:00', '2023-10-04 00:00:00', 4, 90, 86, 2262, 'MG', '2023-09-04 15:40:30', 0, 0, 0, 0, NULL, b'0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, 0, NULL, 0, 0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `guest`
--

CREATE TABLE `guest` (
  `ID` int(11) NOT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `companyName` varchar(255) DEFAULT NULL,
  `birthDate` datetime DEFAULT NULL,
  `street` varchar(255) DEFAULT NULL,
  `zipcode` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `business` bit(1) NOT NULL,
  `regularCustomer` smallint(6) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `created` varchar(255) DEFAULT NULL,
  `birth_date` varchar(255) DEFAULT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `has_data` bit(1) NOT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `regular_customer` bit(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Daten für Tabelle `guest`
--

INSERT INTO `guest` (`ID`, `firstName`, `lastName`, `companyName`, `birthDate`, `street`, `zipcode`, `location`, `email`, `phone`, `business`, `regularCustomer`, `creator`, `created`, `birth_date`, `company_name`, `first_name`, `has_data`, `last_name`, `regular_customer`) VALUES
(1, 'Martin', 'Gronau', 'J & G Software', '2023-08-17 00:00:00', 'Weidenhäuser Straße 92', '35037', 'Marburg', 'mr_gronau@web.de', '+49 163 2380475', b'1', 1, 'MG', '2023-08-10 10:31:51', NULL, NULL, NULL, b'0', NULL, b'0'),
(3, 'Sabine', 'Gronau', 'Vitos Giessen Marburg', '1963-09-30 00:00:00', 'Weidenhäuser Straße 92', '35037', 'Marburg', 'gro_sab@gmail.com', '+49 163 2380475', b'0', 1, 'MG', '2023-08-10 10:31:51', NULL, NULL, NULL, b'0', NULL, b'0'),
(4, 'Katja', 'Sirotkin', 'reuse GmbH', '2023-08-22 00:00:00', 'Weidenhäuser Straße 92', '35037', 'Marburg', 'fl-kontakt@tutanota.com', '+49 163 2380475', b'0', 1, 'MG', '2023-08-10 10:31:51', NULL, NULL, NULL, b'0', NULL, b'0'),
(5, 'Martin', 'Gronau', NULL, '1961-10-13 00:00:00', 'Weidenhäuser Straße 92', '35037', 'Marburg', 'martin.gronau@jugsoftware.de', '+49 163 2380475', b'0', 1, 'MG', '2023-08-10 10:31:51', NULL, NULL, NULL, b'0', NULL, b'0'),
(7, 'Martin', 'Gronau', NULL, '1961-10-13 00:00:00', 'Weidenhäuser Straße 92', '35037', 'Marburg', 'martin.gronau@jugsoftware.de', '+49 163 2380475', b'0', 1, 'MG', '2023-08-10 10:31:51', NULL, NULL, NULL, b'0', NULL, b'0'),
(11, 'Martin', 'Gronau', NULL, '2023-09-01 00:00:00', 'testgasse 3', '2323', 'Testort', 'tet@gmail.com', '2323 222', b'1', 1, 'MG', '2023-09-01 20:34:57', NULL, NULL, NULL, b'0', NULL, b'0'),
(15, 'Bruce', 'Dickinson', '', '2023-09-06 00:00:00', 'Eddygasse 2', '2323', 'Entenhausen', 'bruce@gmail.com', '+666 666', b'0', 1, 'MG', '2023-09-06 16:52:11', NULL, NULL, NULL, b'0', NULL, b'0');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `hibernate_sequences`
--

CREATE TABLE `hibernate_sequences` (
  `sequence_name` varchar(255) NOT NULL,
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Daten für Tabelle `hibernate_sequences`
--

INSERT INTO `hibernate_sequences` (`sequence_name`, `next_val`) VALUES
('default', 0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `hotel`
--

CREATE TABLE `hotel` (
  `ID` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `street` varchar(255) DEFAULT NULL,
  `zipcode` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `regionId` int(11) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `created` varchar(255) DEFAULT NULL,
  `has_data` bit(1) NOT NULL,
  `region` varchar(255) DEFAULT NULL,
  `region_id` int(11) NOT NULL,
  `region_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Daten für Tabelle `hotel`
--

INSERT INTO `hotel` (`ID`, `name`, `title`, `street`, `zipcode`, `location`, `description`, `email`, `phone`, `website`, `regionId`, `creator`, `created`, `has_data`, `region`, `region_id`, `region_name`) VALUES
(1, 'Traumhotel', 'ein traumhaftes Hotel', 'On the Seaside 3', '2323', 'Entenhausen', 'Ein traumhaftes Traumhotel im traumvollen Hessenlande', 'traum@traumhotel.de', '', 'www.traumhotel.de', 2, 'MG', '2023-08-10 10:31:51', b'0', NULL, 0, NULL),
(2, 'Nordsee Hotel', 'ein Hotel an der Nordsee', 'On the Seaside 4', '2323', 'Dagoberthausen', 'einfach unbeschreiblich, dieses Nordsee-Hotel', '', '', '', 6, 'MG', '2023-08-10 10:31:51', b'0', NULL, 0, NULL),
(4, 'Mein Lieblingshotel', 'Hotel nach meinem Geschmack', 'RHammer 1', '2323', 'On the Road', 'einfach unbeschreiblich', 'info@mein-lieblingshotel.de', '+49 123 456', 'www.mein-lieblingshotel.de', 1, 'MG', '2023-08-10 10:31:51', b'0', NULL, 0, NULL),
(5, 'Unser Lieblingshotel', 'Hotel nach unserem Geschmack', 'RHammer 2', '2323', 'On the Road', 'einfach unbeschreiblich', 'info@lieblingshotel.de', '+49 666 666', 'www.lieblingshotel.de', 5, 'MG', '2023-08-10 10:31:51', b'0', NULL, 0, NULL);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `hotelOption`
--

CREATE TABLE `hotelOption` (
  `ID` int(11) NOT NULL,
  `hotelId` int(11) DEFAULT NULL,
  `optionId` int(11) DEFAULT NULL,
  `approval` smallint(1) DEFAULT NULL,
  `creator` varchar(175) DEFAULT NULL,
  `created` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Daten für Tabelle `hotelOption`
--

INSERT INTO `hotelOption` (`ID`, `hotelId`, `optionId`, `approval`, `creator`, `created`) VALUES
(2, 2, 2, 0, 'MG', '2023-08-23 07:55:01'),
(4, 2, 7, 0, 'MG', '2023-08-23 07:55:31'),
(6, 5, 7, 0, 'MG', '2023-08-23 07:55:31'),
(7, 5, 2, 0, 'MG', '2023-08-23 07:55:01'),
(8, 4, 7, 0, 'MG', '2023-08-23 07:55:31'),
(9, 4, 2, 0, 'MG', '2023-08-23 07:55:01'),
(28, 1, 15, 0, 'MG', '2023-08-23 07:55:01'),
(29, 2, 15, 0, 'MG', '2023-08-23 07:55:01');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `hotel_option`
--

CREATE TABLE `hotel_option` (
  `option_id` int(11) NOT NULL,
  `approval` bit(1) NOT NULL,
  `count_hotels` int(11) NOT NULL,
  `hotel_ids` varbinary(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `logging`
--

CREATE TABLE `logging` (
  `ID` int(11) NOT NULL,
  `loginId` int(11) DEFAULT NULL,
  `loggingType` int(11) DEFAULT NULL,
  `notification` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `created` varchar(255) DEFAULT NULL,
  `has_data` bit(1) NOT NULL,
  `logging_type` int(11) NOT NULL,
  `login_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `login`
--

CREATE TABLE `login` (
  `ID` int(11) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `loginname` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `salt` varchar(255) DEFAULT NULL,
  `roleId` int(11) DEFAULT NULL,
  `guestId` int(11) DEFAULT NULL,
  `registered` bit(1) NOT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `created` varchar(255) DEFAULT NULL,
  `role_id` int(11) DEFAULT NULL,
  `guest_id` int(11) DEFAULT NULL,
  `has_data` bit(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Daten für Tabelle `login`
--

INSERT INTO `login` (`ID`, `username`, `loginname`, `password`, `salt`, `roleId`, `guestId`, `registered`, `creator`, `created`, `role_id`, `guest_id`, `has_data`) VALUES
(1, 'Martin Gronau', 'MGronau', '224290d76b62115c1ab91e0ce99684cc573dce897bb91fb8c6c09c52631ca11978e717ea75801cc5565d25961d7772dd9217915084f2f8e9ca202fe670e28c2b', '[B@16bfee85', 4, 1, b'1', 'MG', '2023-08-25 19:05:42', NULL, NULL, b'0'),
(2, 'Katja Sirotkin', 'KSirotkin', '405898f69299cbefbee115bb947958e4b682d994ae687acb006dc125c8a6851af710964a0054c09d89b06393d8cca9760d91ff399fbc0deca0895e621aaa400b', '[B@3f696fb0', 1, 4, b'1', 'MG', '2023-08-25 19:05:42', NULL, NULL, b'0'),
(3, 'Sabine Gronau', 'SGronau', 'mywifeY', '[B@367d50d', 3, 3, b'1', 'MG', '2023-08-25 19:05:42', NULL, NULL, b'0'),
(9, 'Bruce_Dickinson', 'BDickinson', 'Maiden2023', '[B@250bc822', 3, 15, b'1', 'MG', '2023-09-06 16:52:11', NULL, NULL, b'0');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `options`
--

CREATE TABLE `options` (
  `ID` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `optionType` int(11) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `created` varchar(255) DEFAULT NULL,
  `has_data` bit(1) NOT NULL,
  `option_type` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Daten für Tabelle `options`
--

INSERT INTO `options` (`ID`, `name`, `title`, `description`, `optionType`, `creator`, `created`, `has_data`, `option_type`) VALUES
(1, 'NichtRaucher', 'Nicht Raucher Zimmer', 'Rauchen ist in diesem Hotelzimmer nicht gestattet!', 2, 'MG', '2023-08-23 06:24:27', b'0', 0),
(2, 'HausParkplatz', 'Parkplatz am Haus', 'Parkplätze sind im Haus integriert!', 1, 'MG', '2023-08-23 06:26:33', b'0', 0),
(6, 'Freies-Internet', 'WLAN-Router', 'Frei verfügbarer WLAN-Router auf dem Zimmer', 2, 'MG', '2023-08-23 07:51:09', b'0', 0),
(7, 'Freies Internet', 'WLAN-Service!', 'WLAN im ganzen Haus', 1, 'MG', '2023-08-23 07:53:22', b'0', 0),
(8, 'Bar', 'Barzahlung', 'Bares ist Wares!!', 3, 'MG', '2023-08-23 08:14:38', b'0', 0),
(9, 'Überweisung', 'per Überweisung', 'Banküberweisungen innerhalb Deutschlands', 3, 'MG', '2023-08-23 08:14:38', b'0', 0),
(10, 'EC-Karte', 'per EC-Karte', 'mit handelsüblicher EC-Karte', 3, 'MG', '2023-08-23 08:16:06', b'0', 0),
(11, 'Rechnung', 'auf Rechnung', 'auf Rechnung, umgehend zu begleichen', 3, 'MG', '2023-08-23 08:16:06', b'0', 0),
(13, 'MiniBar', 'MiniBar inklusive', 'Gefüllte MiniBar inklusive', 2, 'MG', '2023-08-23 13:15:32', b'0', 0),
(14, 'Freies Internet', 'WLAN-Router', 'Frei verfügbarer WLAN-Router auf dem Zimmer', 2, 'MG', '2023-08-23 14:18:42', b'0', 0),
(15, 'Hubschrauber', 'Hubschrauber', 'eigener Hubschrauberlandeplatz \nfür VIP-Gäste', 1, 'MG', '2023-08-23 15:03:16', b'0', 0),
(16, 'Credit-Card', 'Kreditkarte', 'Bezahlung mit Kreditkarte', 2, 'MG', '2023-08-23 16:54:55', b'0', 0),
(17, 'Blasmusik ', 'Blasmusik inklusive', 'Mit schöner Blasmusik', 2, 'MG', '2023-09-05 23:59:08', b'0', 0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `payment`
--

CREATE TABLE `payment` (
  `ID` int(11) NOT NULL,
  `InvoiceNumber` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `totalcost` double NOT NULL,
  `mwst` double NOT NULL,
  `waehrung` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `created` varchar(255) DEFAULT NULL,
  `has_data` bit(1) NOT NULL,
  `invoice_number` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Daten für Tabelle `payment`
--

INSERT INTO `payment` (`ID`, `InvoiceNumber`, `name`, `title`, `description`, `totalcost`, `mwst`, `waehrung`, `creator`, `created`, `has_data`, `invoice_number`) VALUES
(1, NULL, 'Rechnung1a', 'Rechnung-2023-01-01', 'Rechnung zum 01.01.2023', 750, 142.5, 'EUR', 'MG', '2023-08-14 07:37:36', b'0', NULL),
(2, NULL, 'Rechnung2a', 'Rechnung-2023-04-02-2023-04-10', 'Rechnung zum 11.04.2023', 2500, 475, 'EUR', 'MG', '2023-08-14 07:37:36', b'0', NULL),
(3, NULL, 'Rechnung3a', 'Rechnung-2023-08-22-2023-08-23', 'Rechnung zum 24.08.2023', 1500, 285, 'EUR', 'MG', '2023-08-14 07:37:36', b'0', NULL),
(86, 'RNG_54861_HB', 'Rechnung_-810340466_2023-09-04 15:40:30', 'Ihre Rechnung_-810340466_2023-09-04 15:40:30', 'Rechnung zum 04.09.2023 15:40', 2691.78, 429.78, 'EUR', 'MG', '2023-09-04 15:40:30', b'0', NULL);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `paymentOption`
--

CREATE TABLE `paymentOption` (
  `ID` int(11) NOT NULL,
  `paymentId` int(11) DEFAULT NULL,
  `optionId` int(11) DEFAULT NULL,
  `approval` smallint(1) DEFAULT NULL,
  `creator` varchar(175) DEFAULT NULL,
  `created` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Daten für Tabelle `paymentOption`
--

INSERT INTO `paymentOption` (`ID`, `paymentId`, `optionId`, `approval`, `creator`, `created`) VALUES
(1, 1, 8, 0, 'MG', '2023-08-23 08:24:06'),
(2, 2, 9, 0, 'MG', '2023-08-23 08:24:06'),
(18, 1, 11, 0, 'MG', '2023-08-23 08:24:06'),
(19, 2, 11, 0, 'MG', '2023-08-23 08:24:06'),
(20, 3, 11, 0, 'MG', '2023-08-23 08:24:06'),
(21, 1, 10, 0, 'MG', '2023-08-23 08:24:06'),
(22, 3, 10, 0, 'MG', '2023-08-23 08:24:06'),
(23, 1, 16, 0, 'MG', '2023-08-23 16:54:55'),
(24, 3, 16, 0, 'MG', '2023-08-23 16:54:55');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `payment_option`
--

CREATE TABLE `payment_option` (
  `option_id` int(11) NOT NULL,
  `approval` bit(1) NOT NULL,
  `count_payments` int(11) NOT NULL,
  `payment_ids` varbinary(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `region`
--

CREATE TABLE `region` (
  `ID` int(11) NOT NULL,
  `name` varchar(255) NOT NULL COMMENT ' ',
  `title` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `created` varchar(255) DEFAULT NULL,
  `has_data` bit(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Daten für Tabelle `region`
--

INSERT INTO `region` (`ID`, `name`, `title`, `description`, `creator`, `created`, `has_data`) VALUES
(1, 'S-W', 'Schleswig-Holstein', 'Eine schöne Region direkt an der Küste gelegen.', 'MG', '2023-08-10 10:59:43', b'0'),
(2, 'Hess', 'Hessen', 'Mitten in Deutschland, das wunderbare Hessenland', 'MG', '2023-08-10 10:59:43', b'0'),
(3, 'BAY', 'Bayern', 'Na diese Bayern halt, Mir san Mir', 'MG', '2023-08-10 10:59:43', b'0'),
(5, 'BERLIN', 'Berlin', 'Unsere Hauptstadt', 'MG', '2023-08-10 10:59:43', b'0'),
(6, 'BREMEN', 'Bremen', 'Hansestadt', 'MG', '2023-08-10 10:59:43', b'0'),
(9, 'Itze', 'Itzehoe', 'Itzehoe bei Hamburg', 'MG', '2023-08-10 10:31:51', b'0'),
(10, 'Hild', 'Hildesheim', 'Hildesheim bei Hannover!', 'MG', '2023-08-10 10:31:51', b'0'),
(13, 'Panama', 'Panama', 'Oh wie schön ist Panama', 'MG', '2023-08-21 22:11:46', b'0'),
(15, 'Traum', 'Traumland', 'einfach ein traumland', 'MG', '2023-08-21 22:22:43', b'0');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `role`
--

CREATE TABLE `role` (
  `ID` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `roleType` int(11) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `created` varchar(255) DEFAULT NULL,
  `has_data` bit(1) NOT NULL,
  `role_type` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Daten für Tabelle `role`
--

INSERT INTO `role` (`ID`, `name`, `title`, `description`, `roleType`, `creator`, `created`, `has_data`, `role_type`) VALUES
(1, 'guest', 'Guest', 'Rolle Gast', NULL, 'MG', '2023-08-16 06:46:24', b'0', 0),
(2, 'modertor', 'Moderator', 'Rolle Moderator', NULL, 'MG', '2023-08-16 06:47:06', b'0', 0),
(3, 'manager', 'manager', 'Rolle Manager', NULL, 'MG', '2023-08-16 06:47:47', b'0', 0),
(4, 'admin', 'Admin', 'Rolle Administrator', NULL, 'MG', '2023-08-16 06:47:47', b'0', 0),
(5, 'superadmin', 'Supderadmin', 'Rolle Super-Administrator', NULL, 'MG', '2023-08-16 06:47:47', b'0', 0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `room`
--

CREATE TABLE `room` (
  `ID` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `category` varchar(255) DEFAULT NULL,
  `countOfBeds` int(11) DEFAULT NULL,
  `hotelId` int(11) DEFAULT NULL,
  `accommodationCost` double DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `created` varchar(255) DEFAULT NULL,
  `accommodation_cost` double NOT NULL,
  `count_of_beds` int(11) NOT NULL,
  `has_data` bit(1) NOT NULL,
  `hotel` varchar(255) DEFAULT NULL,
  `hotel_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Daten für Tabelle `room`
--

INSERT INTO `room` (`ID`, `name`, `title`, `description`, `category`, `countOfBeds`, `hotelId`, `accommodationCost`, `creator`, `created`, `accommodation_cost`, `count_of_beds`, `has_data`, `hotel`, `hotel_id`) VALUES
(1, 'Zimmer Z3V5', 'home sweet home', 'liebevoll eingerichtetes Appartment mit Meerblick, Doppelzimmer, Nichtraucher, Haustiere erlaubt', 'Standardklasse', 2, 1, 76, 'MG', '2023-08-10 10:31:51', 0, 0, b'0', NULL, 0),
(3, 'Zimmer Z8V9', 'my favorite room', 'mein ganz besonderes Zimmer', 'Premiumklasse', 1, 5, 75, 'MG', '2023-08-10 10:31:51', 0, 0, b'0', NULL, 0),
(4, 'Zimmer Z5V6', 'home sweet home', 'liebevoll eingerichtetes Appartment mit Meerblick, Einzelzimmer', 'Extraklasse', 2, 4, 78, 'MG', '2023-08-10 10:31:51', 0, 0, b'0', NULL, 0),
(5, 'Zimmer Z5V6', 'home sweet home', 'liebevoll eingerichtetes Appartment mit Meerblick, Einzelzimmer', 'Extraklasse', 2, 5, 80.4, 'MG', '2023-08-10 10:31:51', 0, 0, b'0', NULL, 0),
(6, 'Zimmer Z3V5', 'home sweet home', 'liebevoll eingerichtetes Appartment mit Meerblick, Doppelzimmer, Nichtraucher, Haustiere erlaubt', 'Standardklasse', 3, 2, 75, 'MG', '2023-08-10 10:31:51', 0, 0, b'0', NULL, 0),
(9, 'Zimmer Z5V68', 'home sweet away', 'liebevoll eingerichtetes Wohnmobil mit Meerblick, Einzelzimmer', 'Extraklasse', NULL, NULL, NULL, 'MG', '2023-08-10 10:31:51', 0, 0, b'0', NULL, 0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `roomFeature`
--

CREATE TABLE `roomFeature` (
  `ID` int(11) NOT NULL,
  `roomId` int(11) DEFAULT NULL,
  `optionId` int(11) DEFAULT NULL,
  `approval` smallint(1) DEFAULT NULL,
  `creator` varchar(175) DEFAULT NULL,
  `created` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Daten für Tabelle `roomFeature`
--

INSERT INTO `roomFeature` (`ID`, `roomId`, `optionId`, `approval`, `creator`, `created`) VALUES
(1, 3, 1, 0, 'MG', '2023-08-23 06:29:58'),
(14, 1, 2, 0, 'MG', '2023-08-23 06:29:58'),
(15, 4, 2, 0, 'MG', '2023-08-23 06:29:58'),
(20, 1, 17, 0, 'MG', '2023-09-05 23:59:08'),
(21, 5, 17, 0, 'MG', '2023-09-05 23:59:08'),
(22, 3, 13, 0, 'MG', '2023-08-23 06:29:58'),
(23, 5, 13, 0, 'MG', '2023-08-23 06:29:58');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `roomOccupancy`
--

CREATE TABLE `roomOccupancy` (
  `ID` int(11) NOT NULL,
  `startDate` datetime DEFAULT NULL,
  `endDate` datetime DEFAULT NULL,
  `guestId` int(11) DEFAULT NULL,
  `roomId` int(11) DEFAULT NULL,
  `creator` varchar(175) DEFAULT NULL,
  `created` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Daten für Tabelle `roomOccupancy`
--

INSERT INTO `roomOccupancy` (`ID`, `startDate`, `endDate`, `guestId`, `roomId`, `creator`, `created`) VALUES
(90, '2023-09-05 00:00:00', '2023-10-04 00:00:00', 1, 4, 'MG', '2023-09-04 15:40:30');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `room_feature`
--

CREATE TABLE `room_feature` (
  `option_id` int(11) NOT NULL,
  `approval` bit(1) NOT NULL,
  `count_rooms` int(11) NOT NULL,
  `room_ids` varbinary(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `room_occupancy`
--

CREATE TABLE `room_occupancy` (
  `id` int(11) NOT NULL,
  `created` varchar(255) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `guest_id` int(11) NOT NULL,
  `has_data` bit(1) NOT NULL,
  `room_id` int(11) NOT NULL,
  `start_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `fk_hotel_id` (`hotelId`),
  ADD KEY `fk_roomOccupancy_id` (`roomOccupancyId`) USING BTREE,
  ADD KEY `fk_payment_id` (`paymentId`) USING BTREE;

--
-- Indizes für die Tabelle `guest`
--
ALTER TABLE `guest`
  ADD PRIMARY KEY (`ID`);

--
-- Indizes für die Tabelle `hibernate_sequences`
--
ALTER TABLE `hibernate_sequences`
  ADD PRIMARY KEY (`sequence_name`);

--
-- Indizes für die Tabelle `hotel`
--
ALTER TABLE `hotel`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `fk_region_id` (`regionId`) USING BTREE;

--
-- Indizes für die Tabelle `hotelOption`
--
ALTER TABLE `hotelOption`
  ADD PRIMARY KEY (`ID`);

--
-- Indizes für die Tabelle `hotel_option`
--
ALTER TABLE `hotel_option`
  ADD PRIMARY KEY (`option_id`);

--
-- Indizes für die Tabelle `logging`
--
ALTER TABLE `logging`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `fk_login_id` (`loginId`);

--
-- Indizes für die Tabelle `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`ID`);

--
-- Indizes für die Tabelle `options`
--
ALTER TABLE `options`
  ADD PRIMARY KEY (`ID`);

--
-- Indizes für die Tabelle `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`ID`);

--
-- Indizes für die Tabelle `paymentOption`
--
ALTER TABLE `paymentOption`
  ADD PRIMARY KEY (`ID`);

--
-- Indizes für die Tabelle `payment_option`
--
ALTER TABLE `payment_option`
  ADD PRIMARY KEY (`option_id`);

--
-- Indizes für die Tabelle `region`
--
ALTER TABLE `region`
  ADD PRIMARY KEY (`ID`);

--
-- Indizes für die Tabelle `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`ID`);

--
-- Indizes für die Tabelle `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `fk_hotel` (`hotelId`);

--
-- Indizes für die Tabelle `roomFeature`
--
ALTER TABLE `roomFeature`
  ADD PRIMARY KEY (`ID`);

--
-- Indizes für die Tabelle `roomOccupancy`
--
ALTER TABLE `roomOccupancy`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `fk_guest_id` (`guestId`) USING BTREE,
  ADD KEY `fk_room_id` (`roomId`) USING BTREE;

--
-- Indizes für die Tabelle `room_feature`
--
ALTER TABLE `room_feature`
  ADD PRIMARY KEY (`option_id`);

--
-- Indizes für die Tabelle `room_occupancy`
--
ALTER TABLE `room_occupancy`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `booking`
--
ALTER TABLE `booking`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=93;

--
-- AUTO_INCREMENT für Tabelle `guest`
--
ALTER TABLE `guest`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT für Tabelle `hotel`
--
ALTER TABLE `hotel`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT für Tabelle `hotelOption`
--
ALTER TABLE `hotelOption`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT für Tabelle `logging`
--
ALTER TABLE `logging`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `login`
--
ALTER TABLE `login`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT für Tabelle `options`
--
ALTER TABLE `options`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT für Tabelle `payment`
--
ALTER TABLE `payment`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=87;

--
-- AUTO_INCREMENT für Tabelle `paymentOption`
--
ALTER TABLE `paymentOption`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT für Tabelle `region`
--
ALTER TABLE `region`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT für Tabelle `role`
--
ALTER TABLE `role`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT für Tabelle `room`
--
ALTER TABLE `room`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT für Tabelle `roomFeature`
--
ALTER TABLE `roomFeature`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT für Tabelle `roomOccupancy`
--
ALTER TABLE `roomOccupancy`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=91;

--
-- Constraints der exportierten Tabellen
--

--
-- Constraints der Tabelle `booking`
--
ALTER TABLE `booking`
  ADD CONSTRAINT `fk_bezahlung_id` FOREIGN KEY (`paymentId`) REFERENCES `payment` (`ID`),
  ADD CONSTRAINT `fk_hotel_id` FOREIGN KEY (`hotelId`) REFERENCES `hotel` (`ID`),
  ADD CONSTRAINT `fk_zimmerbelegung_id` FOREIGN KEY (`roomOccupancyId`) REFERENCES `roomOccupancy` (`ID`);

--
-- Constraints der Tabelle `logging`
--
ALTER TABLE `logging`
  ADD CONSTRAINT `fk_login_id` FOREIGN KEY (`loginId`) REFERENCES `login` (`ID`);

--
-- Constraints der Tabelle `room`
--
ALTER TABLE `room`
  ADD CONSTRAINT `fk_hotel` FOREIGN KEY (`hotelId`) REFERENCES `hotel` (`ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

package com.project.hotelbooking.playground;

import com.project.hotelbooking.datamodels.restapi.models.Lookup;
import com.project.hotelbooking.playground.components.CustomRBListView;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class TestCustomRBListView extends Application {

    public static final ObservableList<Lookup> names = FXCollections.observableArrayList();

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        primaryStage.setTitle("List View Sample");

        CustomRBListView<Lookup> listView = new CustomRBListView<>();

        listView.setPrefSize(200, 250);
        listView.setEditable(true);

        names.addAll(new Lookup(1,"Adam"), new Lookup(2,"Alex"), new Lookup(3,"Alfred"),
                new Lookup(4, "Albert"), new Lookup(5,"Brenda"), new Lookup(6, "Connie"),
                new Lookup(7, "Derek"), new Lookup(8,"Donny"), new Lookup(9, "Lynne"),
                new Lookup(10,"Myrtle"), new Lookup(11,"Rose"), new Lookup(12, "Rudolph"),
                new Lookup(13,"Tony"), new Lookup(14, "Trudy"), new Lookup(15, "Williams"),
                new Lookup(16, "Zach"));

        listView = new CustomRBListView<>(listView);

        StackPane root = new StackPane();
        root.getChildren().add(listView);
        primaryStage.setScene(new Scene(root, 200, 250));
        primaryStage.show();
    }
}

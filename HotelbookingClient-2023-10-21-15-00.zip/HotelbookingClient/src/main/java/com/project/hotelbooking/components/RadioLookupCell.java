package com.project.hotelbooking.components;

import com.project.hotelbooking.datamodels.restapi.models.Lookup;
import javafx.scene.control.ListCell;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;

public class RadioLookupCell extends ListCell<Lookup> {

    private ToggleGroup group;


    public RadioLookupCell() {
        this.group = new ToggleGroup();
    }

    public RadioLookupCell(ToggleGroup group) {
        this();
        this.group = group;
    }


    @Override
    public void updateItem(Lookup obj, boolean empty) {
        super.updateItem(obj, empty);
        if (empty) {
            setText(null);
            setGraphic(null);
        } else {
            RadioButton radioButton = new RadioButton(obj.getTitle());
            radioButton.setToggleGroup(group);
            // Add Listeners if any
            setGraphic(radioButton);
        }
    }
}

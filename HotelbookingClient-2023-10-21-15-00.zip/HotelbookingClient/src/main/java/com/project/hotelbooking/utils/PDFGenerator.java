package com.project.hotelbooking.utils;

import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfReader;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.border.Border;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.property.TextAlignment;
import lombok.Getter;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;

public class PDFGenerator {

    protected Document document;
    protected final String sDelimiter;

    public void setsDocumentName(String sDocumentName) {
        if(!sDocumentName.toLowerCase().contains(".pdf")) {
            sDocumentName += ".pdf";
        }
        this.sDocumentName = sDocumentName;
    }

    @Getter  protected  String sDocumentName = "print_document.pdf";

    public PDFGenerator(String sDocumentName) {
        this();
        this.setsDocumentName(sDocumentName);
    }

    public PDFGenerator() {
        super();
        SystemSecure systemSecure = new SystemSecure();
        sDelimiter = systemSecure.getDelimiter();
    }

    private  void initializePDFDocument()  {
        Path resourceDirectory = Paths.get("src", "main", "resources", "com", "project", "hotelbooking", "pdf");
        String sPdfPath = resourceDirectory.toFile().getAbsolutePath();

        String path = sPdfPath +sDelimiter+sDocumentName;
        String srcPath = sPdfPath+sDelimiter+"Dokumentvorlage_HotelBooking.pdf";

        try {
             PdfReader pdfReader = new PdfReader(srcPath);
             PdfWriter pdfWriter = new PdfWriter(path);
             PdfDocument pdfDocument = new PdfDocument(pdfReader, pdfWriter);

            pdfDocument.setDefaultPageSize(PageSize.A4);
            document = new Document(pdfDocument);

        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }

    public void generatePDFDocument(String sDocumentName) {
        try {
            if(!sDocumentName.trim().isEmpty()) {
                this.setsDocumentName(sDocumentName);
            }
            initializePDFDocument();
            addPDFDocumentPageContents();
            closePDFDocument();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    protected void addPDFDocumentPageContents() {
        document.add(getHeaderTextCell("Hallo Welt").setPaddingTop(75f));
    }

    protected Cell getHeaderTextCell(String textValue) {
        return new Cell().add(textValue).setBold().setBorder(Border.NO_BORDER).setTextAlignment(TextAlignment.RIGHT);
    }
    protected Cell getHeaderTextCellValue(String textValue) {
        return new Cell().add(textValue).setBorder(Border.NO_BORDER).setTextAlignment(TextAlignment.LEFT);
    }

    protected Cell getBillingAndShippingCell(String textValue) {
        return new Cell().add(textValue).setFontSize(12f).setBold().setBorder(Border.NO_BORDER).setTextAlignment(TextAlignment.LEFT);
    }

    protected Cell getCell10fLeft(String textValue, Boolean isBold) {
        Cell myCell = new Cell().add(textValue).setFontSize(10f).setBorder(Border.NO_BORDER).setTextAlignment(TextAlignment.LEFT);
        return isBold ? myCell.setBold():myCell;
    }

    private  void closePDFDocument() {
        document.close();
    }

    public static void main(String[] args) {

        PDFGenerator pdfGenerator = new PDFGenerator();
        pdfGenerator.generatePDFDocument("blablabla.pdf");
        System.out.println("hurra, hat geklappt!");
    }

}

package com.project.hotelbooking.controllers;

import com.project.hotelbooking.Main;
import com.project.hotelbooking.components.LookupCell;
import com.project.hotelbooking.datamodels.restapi.models.*;
import com.project.hotelbooking.services.HotelService;
import com.project.hotelbooking.services.RoomFeatureService;
import com.project.hotelbooking.services.RoomService;
import com.project.hotelbooking.utils.Common;
import javafx.beans.InvalidationListener;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.control.cell.CheckBoxListCell;
import javafx.scene.layout.BorderPane;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class RoomController {
    @FXML
    private Accordion accordion;
    @FXML
    private BorderPane roomsPanel;

    @FXML
    private TableView<Room> roomsTable;

    @FXML
    private TextField fldName;

    @FXML
    private TextField fldTitle;
    @FXML
    private TextArea fldDescription;

    @FXML
    private TextField fldCategory;

    @FXML
    private ComboBox<Lookup> fldHotel;

    @FXML
    private Spinner<Integer> fldCountOfBeds;

    @FXML
    private  Spinner<Double> fldAccommodationCost;

    private ObservableList<Lookup> listHotels;
    private RoomService roomService;
    private RoomFeatureService roomFeatureService;

    @FXML
    private ListView<CheckBoxLookup> listviewRoomFeatures;
    @FXML
    private TitledPane fldRoomFeatures;
    private ObservableList<CheckBoxLookup> roomFeatures;
    private int currentRoomId = 0;

    public void initialize() {
        roomService = new RoomService();
        roomFeatureService = new RoomFeatureService();

        if(roomsTable != null) {
            roomsTable.setItems(roomService.getRooms());
        } else {
            listHotels = FXCollections.observableArrayList();
            HotelService hotelService = new HotelService();

            for(Hotel hotel : hotelService.getHotels()) {
                listHotels.add(new Lookup(hotel.getId(), hotel.getName()));
            }
            fldHotel.setCellFactory(lookups -> new LookupCell());
            fldHotel.setButtonCell(new LookupCell());
            fldHotel.setItems(listHotels);
            fldHotel.setValue(listHotels.get(0));

            roomFeatures = FXCollections.observableArrayList();
            listviewRoomFeatures.setCellFactory(factory -> {
                CheckBoxListCell<CheckBoxLookup> cell = new CheckBoxListCell<CheckBoxLookup>() {
                    // a listener on the graphicProperty: it installs the "real" listener
                    final InvalidationListener graphicListener = g -> {
                        // installs the "real" listener on the graphic control once it is available
                        registerUIListener();
                    };

                    {
                        // install the graphic listener at instantiation
                        graphicProperty().addListener(graphicListener);
                    }

                    private void registerUIListener() {
                        if (!(getGraphic() instanceof CheckBox)) throw new IllegalStateException("checkBox expected");
                        graphicProperty().removeListener(graphicListener);
                        ((CheckBox) getGraphic()).selectedProperty().addListener(
                                (observable, oldValue, newValue) -> listviewRoomFeatures.getSelectionModel().select(getItem()));
                    }
                };
                cell.setSelectedStateCallback(CheckBoxLookup::selectedProperty);
                return cell;
            });

            for (RoomFeature roomFeature : roomFeatureService.getRoomFeatures()) {
                roomFeatures.add( new CheckBoxLookup(roomFeature.getName(), false, roomFeature.getOptionId()));
            }
            listviewRoomFeatures.setItems(roomFeatures);
            accordion.setExpandedPane(fldRoomFeatures);

            fldName.requestFocus();
        }

    }

    @FXML
    public void showAddRoomDialog() throws URISyntaxException {
        Dialog<ButtonType> dialog = new Dialog<ButtonType>();
        dialog.initOwner(roomsPanel.getScene().getWindow());
        dialog.setTitle("Zimmer hinzufügen");
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(Main.class.getResource("forms/roomdialog.fxml"));
        try {
            dialog.getDialogPane().setContent(fxmlLoader.load());

        } catch(IOException e) {
            System.out.println("Couldn't load the dialog");
            e.printStackTrace();
            return;
        }

        dialog.getDialogPane().getButtonTypes().add(ButtonType.OK);
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CANCEL);

        RoomController roomController = fxmlLoader.getController();
        final Button okButton = (Button) dialog.getDialogPane().lookupButton(ButtonType.OK);
        okButton.addEventFilter(ActionEvent.ACTION, ae -> {
            if (!roomController.isValidRoom()) {
                ae.consume(); //not valid
            }
        });

        Optional<ButtonType> result = dialog.showAndWait();
        if(result.isPresent() && result.get() == ButtonType.OK) {
            Room newRoom = roomController.getNewRoom();

            currentRoomId = roomService.insertRoom(newRoom);
            roomsTable.setItems(roomService.getRooms());
            roomsTable.refresh();
        }
    }

    public Room getNewRoom() {
        String name = fldName.getText();
        String title = fldTitle.getText();
        String description = fldDescription.getText();
        String category = fldCategory.getText();
        Integer countOfBeds = fldCountOfBeds.getValue();
        Lookup lookup = fldHotel.getSelectionModel().getSelectedItem();
        Double accommodationCost = fldAccommodationCost.getValue();

       Room room =  new Room(name, title,  description, countOfBeds,lookup.getId(), category,accommodationCost,
                Common.CREATOR, Common.CREATED, true);

        List<Integer> selectedRoomFeatureIds = new ArrayList<>();
        for(CheckBoxLookup item :  listviewRoomFeatures.getItems()) {
            if(item.isSelected())    {
                selectedRoomFeatureIds.add(item.getId());
            }
        }

        room.setRoomFeatureIds(selectedRoomFeatureIds);
       return  room;
    }

    public void editRoom(Room room) {
        fldName.setText(room.getName());
        fldTitle.setText(room.getTitle());
        fldDescription.setText(room.getDescription());
        fldCategory.setText(room.getCategory());
        fldCountOfBeds.getValueFactory().setValue(room.getCountOfBeds());
        fldAccommodationCost.getValueFactory().setValue(room.getAccommodationCost());

        for(Lookup lookup : fldHotel.getItems()) {
            if(lookup.getId() == room.getHotelId()) {
                fldHotel.setValue(lookup);
                break;
            }
        }
        ObservableList<RoomFeature> roomFeaturesList = roomFeatureService.getRoomFeaturesByRoom(room.getId());

        for (CheckBoxLookup lookup : listviewRoomFeatures.getItems()) {
            lookup.setSelected(roomFeaturesList.stream().anyMatch(h -> h.getOptionId() == lookup.getId()));
        }

    }

    public void updateRoom(Room room) {
        room.setName(fldName.getText());
        room.setTitle(fldTitle.getText());
        room.setDescription(fldDescription.getText());
        room.setCategory(fldCategory.getText());
        room.setCountOfBeds(fldCountOfBeds.getValue());
        room.setHotelId(fldHotel.getValue().getId());
        room.setAccommodationCost(fldAccommodationCost.getValue());

        List<Integer> selectedRoomFeatureIds = new ArrayList<>();
        for(CheckBoxLookup item :  listviewRoomFeatures.getItems()) {
            if(item.isSelected())    {
                selectedRoomFeatureIds.add(item.getId());
            }
        }

        room.setRoomFeatureIds(selectedRoomFeatureIds);
    }

    @FXML
    public void showEditRoomDialog() throws URISyntaxException {
        Room selectedRoom = roomsTable.getSelectionModel().getSelectedItem();
        if(selectedRoom == null) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle(Common.alertMessage.getProperty("confirmRoomTitle"));
            alert.setHeaderText(null);
            alert.setContentText(Common.alertMessage.getProperty("confirmEditRoom"));
            alert.showAndWait();
            return;
        }

        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.initOwner(roomsPanel.getScene().getWindow());
        dialog.setTitle("Zimmer bearbeiten");
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(Main.class.getResource("forms/roomdialog.fxml"));
        try {
            dialog.getDialogPane().setContent(fxmlLoader.load());
        } catch (IOException e) {
            System.out.println("Couldn't load the dialog");
            e.printStackTrace();
            return;
        }

        dialog.getDialogPane().getButtonTypes().add(ButtonType.OK);
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CANCEL);

        RoomController roomController = fxmlLoader.getController();
        roomController.editRoom(selectedRoom);

        final Button okButton = (Button) dialog.getDialogPane().lookupButton(ButtonType.OK);
        okButton.addEventFilter(ActionEvent.ACTION, ae -> {
            if (!roomController.isValidRoom()) {
                ae.consume(); //not valid
            }
        });

        Optional<ButtonType> result = dialog.showAndWait();
        if(result.isPresent() && result.get() == ButtonType.OK) {

            roomController.updateRoom(selectedRoom);
            currentRoomId = roomService.updateRoom(selectedRoom.getId(), selectedRoom);
            roomsTable.setItems(roomService.getRooms());
            roomsTable.refresh();
        }

    }

    public boolean isValidRoom() {
        boolean bReturn = true;
        Common.isWarningMessage = true;

        if (fldName.getText().isEmpty()) {
            Common.showValidationMessage("Das Feld Name  darf nicht leer bleiben");
            bReturn = false;
            fldName.requestFocus();
        } else if (fldTitle.getText().isEmpty()) {
            Common.showValidationMessage("Das Feld Titel  darf nicht leer bleiben");
            bReturn = false;
            fldTitle.requestFocus();
        }

        return bReturn;
    }

    @FXML
    public void deleteRoom() throws URISyntaxException {
        Room selectedRoom = roomsTable.getSelectionModel().getSelectedItem();
        if(selectedRoom == null) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle(Common.alertMessage.getProperty("confirmRoomTitle"));
            alert.setHeaderText(null);
            alert.setContentText(Common.alertMessage.getProperty("confirmDeleteRoom"));
            alert.showAndWait();
            return;
        }

        Alert alert = new Alert(Alert.AlertType.NONE,
                "Möchten Sie das Hotel-Zimmer '"+selectedRoom.getTitle()+"' wirklich löschen?",
                Common.YES, Common.NO);

        alert.setTitle("Lösch-Bestätigung!");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.orElse(Common.NO) == Common.YES) {
            roomService.deleteRoom(selectedRoom.getId());
            roomsTable.setItems(roomService.getRooms());
            roomsTable.refresh();
        }
    }
}


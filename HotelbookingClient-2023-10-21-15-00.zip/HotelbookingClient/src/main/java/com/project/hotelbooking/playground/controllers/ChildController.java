package com.project.hotelbooking.playground.controllers;

public class ChildController {
}

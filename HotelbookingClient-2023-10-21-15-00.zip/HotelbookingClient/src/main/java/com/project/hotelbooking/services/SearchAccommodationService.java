package com.project.hotelbooking.services;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.project.hotelbooking.datamodels.restapi.enums.eHttpStatusCodes;
import com.project.hotelbooking.datamodels.restapi.models.AccommodationSearchResult;
import com.project.hotelbooking.datamodels.restapi.models.Room;
import com.project.hotelbooking.utils.Common;
import com.project.hotelbooking.utils.SystemSecure;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;

import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class SearchAccommodationService extends RestApiService {

    private final String searchAccommodationURI;
    private final Gson gson;

    public SearchAccommodationService() {
        super();
        gson = new Gson();

        SystemSecure systemSecure = new SystemSecure();

        String sBaseURI = systemSecure.getRestApiConnectionUri();
        searchAccommodationURI = sBaseURI+systemSecure.getDelimiter()+"accommodation-search"+systemSecure.getDelimiter();
    }


    public ObservableList<AccommodationSearchResult> getSearchAccommodationsExtended(String region, String startDate,
                                                                                     String endDate,
                                                                                     Integer amountOfGuests, Integer numberOfRooms,
                                                                                     List<Integer> hotelOptions,
                                                                                     List<Integer> roomFeatures) {


        String commaSeparatedUsingReduceHotelOptions = !hotelOptions.isEmpty() ? hotelOptions.stream().map(String::valueOf)
                .collect(Collectors.joining(",")) : "";
        String commaSeparatedUsingReduceRoomFeatures = !roomFeatures.isEmpty() ? roomFeatures.stream().map(String::valueOf)
                .collect(Collectors.joining(",")) : "";

        String sbSearchAccommodationParams = "extended" + "/" + region +
                "/" + startDate +
                "/" + endDate +
                "/" + amountOfGuests +
                "/" + numberOfRooms +
                "/" + (!commaSeparatedUsingReduceHotelOptions.isEmpty() ? commaSeparatedUsingReduceHotelOptions: "0") +
                "/" + (!commaSeparatedUsingReduceRoomFeatures.isEmpty() ? commaSeparatedUsingReduceRoomFeatures : "0");
        HttpResponse<String> getResponse = this.sendGetRequest(searchAccommodationURI
                + sbSearchAccommodationParams);
        if(getResponse.statusCode() == eHttpStatusCodes.HTTP_OK.getValue()) {
            List<AccommodationSearchResult> searchAccommodations = gson.fromJson(getResponse.body(),
                    new TypeToken<ArrayList<AccommodationSearchResult>>() {
                    }.getType());
            return FXCollections.observableList(searchAccommodations);
        } else if(getResponse.statusCode() == eHttpStatusCodes.HTTP_NO_CONTENT.getValue()) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle(Common.alertMessage.getProperty("informationNoDataTitle"));
            alert.setHeaderText(null);
            alert.setContentText(Common.alertMessage.getProperty("informationNoAccommodationSearchData"));
            alert.showAndWait();

            return  null;
        } else {
            return null;
        }

    }


    public ObservableList<AccommodationSearchResult> getSearchAccommodationsStandard(String region, String startDate, String endDate,
                                                                                     Integer amountOfGuests, Integer numberOfRooms) {

        String sbSearchAccommodationParams = "standard" + "/" + region +
                "/" + startDate +
                "/" + endDate +
                "/" + amountOfGuests +
                "/" + numberOfRooms;
        HttpResponse<String> getResponse = this.sendGetRequest(searchAccommodationURI
                + sbSearchAccommodationParams);
        if(getResponse.statusCode() == eHttpStatusCodes.HTTP_OK.getValue()) {
            List<AccommodationSearchResult> searchAccommodations = gson.fromJson(getResponse.body(),
                    new TypeToken<ArrayList<AccommodationSearchResult>>() {
                    }.getType());
            return FXCollections.observableList(searchAccommodations);
        } else if(getResponse.statusCode() == eHttpStatusCodes.HTTP_NO_CONTENT.getValue()) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle(Common.alertMessage.getProperty("informationNoDataTitle"));
            alert.setHeaderText(null);
            alert.setContentText(Common.alertMessage.getProperty("informationNoAccommodationSearchData"));
            alert.showAndWait();

            return  null;
        } else {
            return null;
        }

    }

    public ObservableList<Room> getSearchAccommodationsRooms(String region, String startDate, String endDate,
                                                             Integer amountOfGuests, Integer numberOfRooms) {

        String sbSearchAccommodationParams = "standard-rooms" + "/" + region +
                "/" + startDate +
                "/" + endDate +
                "/" + amountOfGuests +
                "/" + numberOfRooms;

        HttpResponse<String> getResponse = this.sendGetRequest(searchAccommodationURI
                + sbSearchAccommodationParams);


        List<Room> searchAccommodationRooms = gson.fromJson(getResponse.body(),
                new TypeToken<ArrayList<Room>>() {
                }.getType());
        return FXCollections.observableList(searchAccommodationRooms);
    }
}

package com.project.hotelbooking.controllers.tabpanels;

import com.project.hotelbooking.datamodels.restapi.models.AccommodationSearchResult;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;

import java.net.URL;
import java.util.ResourceBundle;

public class TabHotelContactDataController implements Initializable {

    @FXML
    private GridPane hotelContactPanel;

    @FXML
    private Label labHotelName;

    @FXML
    private Label labHotelStreet;

    @FXML
    private Label labHotelZipcode;

    @FXML
    private Label labHotelLocation;

    @FXML
    private Label labHotelEMail;
    @FXML
    private Label labHotelPhone;
    @FXML
    private Label labHotelWebsite;
    @FXML
    private Label labHotelCountFreeBeds;
    @FXML
    private Label labHotelCountFreeRooms;
    @FXML
    private Label labHotelDescription;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        hotelContactPanel.setPadding(new Insets(30, 25, 15, 35));
        labHotelDescription.setPadding(new Insets(27.5,0,0,0));
        labHotelWebsite.setPadding(new Insets(10,0,0,0));
    }

    public void showAccommodationDetail(AccommodationSearchResult accommodationSearchResult) {
        labHotelName.setText(accommodationSearchResult.getHotelName());
        labHotelStreet.setText(accommodationSearchResult.getHotelStreet());
        labHotelZipcode.setText(accommodationSearchResult.getHotelZipcode());
        labHotelLocation.setText(accommodationSearchResult.getHotelLocation());
        labHotelEMail.setText("EMail: " + accommodationSearchResult.getHotelEMail());
        labHotelPhone.setText("Telefon: " + accommodationSearchResult.getHotelPhone());
        labHotelWebsite.setText("Homepage: " + accommodationSearchResult.getHotelWebsite());
        labHotelCountFreeRooms.setText("Freie Zimmer: " + accommodationSearchResult.getCountRooms());
        labHotelCountFreeBeds.setText("Freie Betten: " + accommodationSearchResult.getCountBeds());
        if(accommodationSearchResult.getHotelDescription() != null
                && !accommodationSearchResult.getHotelDescription().isEmpty()) {
            labHotelDescription.setText("Beschreibung: " + accommodationSearchResult.getHotelDescription());
        }

   }

}

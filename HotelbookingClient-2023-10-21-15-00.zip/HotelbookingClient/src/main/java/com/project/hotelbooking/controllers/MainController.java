package com.project.hotelbooking.controllers;

import com.project.hotelbooking.Main;
import com.project.hotelbooking.datamodels.restapi.enums.eRoleTypes;
import com.project.hotelbooking.datamodels.restapi.models.Guest;
import com.project.hotelbooking.datamodels.restapi.models.Login;
import com.project.hotelbooking.services.GuestService;
import com.project.hotelbooking.services.LoginService;
import com.project.hotelbooking.utils.Common;
import com.project.hotelbooking.utils.SystemSecure;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.Optional;

public class MainController {

    @FXML
    private BorderPane mainPanel;

    @FXML
    private RegistrationController registrationController;

    @FXML
    private Button btnLogin;

    @FXML
    private Button btnLogoff;
    @FXML
    private  Button btnSearch;

    @FXML
    private Menu adminMenuSystem;

    @FXML
    private Menu adminMenuOverviews;
    @FXML
    private ToolBar toolBarMain;
    @FXML
    private Label labUsername;

    private SystemSecure systemSecure;

    public void initialize() {
        //----------------------------------------
        initializeOnApiServerOnlineState();

        toolBarMain.getItems().remove(btnLogoff);
        setLoginLabel(false, new Login());
    }

    private void initializeOnApiServerOnlineState() {

        try {
            systemSecure = new SystemSecure();

            if(!systemSecure.checkRestApiServer()) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle(Common.alertMessage.getProperty("systemErrorTitle"));
                alert.setHeaderText(null);
                alert.setContentText(Common.alertMessage.getProperty("systemErrorServerDisconnected"));
                alert.showAndWait();
                //----------------
                btnLogin.setDisable(true);
                btnSearch.setDisable(true);
                labUsername.setDisable(true);

            }
        } catch(Exception e) {
            e.printStackTrace();
        }

    }

    @FXML
    public void showListRegionsDialog() {
        Dialog<ButtonType> dialog = new Dialog<ButtonType>();
        dialog.initOwner(mainPanel.getScene().getWindow());
        dialog.setTitle("Regionen");
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(Main.class.getResource("forms/listregionsdialog.fxml"));
        try {
            dialog.getDialogPane().setContent(fxmlLoader.load());

        } catch (IOException e) {
            System.out.println("Couldn't load the dialog");
            e.printStackTrace();
            return;
        }

        dialog.getDialogPane().getButtonTypes().add(ButtonType.OK);
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CANCEL);

        Optional<ButtonType> result = dialog.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {

        }
    }

    @FXML
    public void showListRoomFeaturesDialog() {
        Dialog<ButtonType> dialog = new Dialog<ButtonType>();
        dialog.initOwner(mainPanel.getScene().getWindow());
        dialog.setTitle("Zimmer-Features");
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(Main.class.getResource("forms/listroomfeaturesdialog.fxml"));
        try {
            dialog.getDialogPane().setContent(fxmlLoader.load());

        } catch (IOException e) {
            System.out.println("Couldn't load the dialog");
            e.printStackTrace();
            return;
        }

        dialog.getDialogPane().getButtonTypes().add(ButtonType.OK);
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CANCEL);

        Optional<ButtonType> result = dialog.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {

        }
    }

    @FXML
    public void showListHotelOptionsDialog() {
        Dialog<ButtonType> dialog = new Dialog<ButtonType>();
        dialog.initOwner(mainPanel.getScene().getWindow());
        dialog.setTitle("Hotel-Optionen");
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(Main.class.getResource("forms/listhoteloptionsdialog.fxml"));
        try {
            dialog.getDialogPane().setContent(fxmlLoader.load());

        } catch (IOException e) {
            System.out.println("Couldn't load the dialog");
            e.printStackTrace();
            return;
        }

        dialog.getDialogPane().getButtonTypes().add(ButtonType.OK);
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CANCEL);

        Optional<ButtonType> result = dialog.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {

        }
    }

    @FXML
    public void showListPaymentOptionsDialog() {
        Dialog<ButtonType> dialog = new Dialog<ButtonType>();
        dialog.initOwner(mainPanel.getScene().getWindow());
        dialog.setTitle("Bezahlungs-Optionen");
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(Main.class.getResource("forms/listpaymentoptionsdialog.fxml"));
        try {
            dialog.getDialogPane().setContent(fxmlLoader.load());

        } catch (IOException e) {
            System.out.println("Couldn't load the dialog");
            e.printStackTrace();
            return;
        }

        dialog.getDialogPane().getButtonTypes().add(ButtonType.OK);
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CANCEL);

        Optional<ButtonType> result = dialog.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {

        }
    }

    @FXML
    private void showLoginDialog() throws IOException {

        Common dlg = new Common();

        if (dlg.showLoginDialog()) {
            setLoginStateOnToolbar();

            Login login = dlg.getLogin();
            Common.guestId = login.getGuestId();

            adminMenuSystem.setDisable(login.getRoleId() != eRoleTypes.ADMIN_ROLE.getValue()
                    && login.getRoleId() != eRoleTypes.SUPERADMIN_ROLE.getValue());

            adminMenuOverviews.setDisable(login.getRoleId() != eRoleTypes.ADMIN_ROLE.getValue()
                    && login.getRoleId() != eRoleTypes.SUPERADMIN_ROLE.getValue()
                    && login.getRoleId() != eRoleTypes.MANAGER_ROLE.getValue());

            setLoginLabel(true, login);
        }

    }


    public void setLoginStateOnToolbar() {

        btnLogin.setVisible(false);
        toolBarMain.getItems().remove(btnLogin);

        btnLogoff.setVisible(true);
        toolBarMain.getItems().add(btnLogoff);
    }

    @FXML
    public void logoffUser() {
        if (!Common.guestId.equals(0)) {
            Common.guestId = 0;
            btnLogoff.setVisible(false);
            toolBarMain.getItems().remove(btnLogoff);
            btnLogin.setVisible(true);
            toolBarMain.getItems().add(btnLogin);

            adminMenuSystem.setDisable(true);
            adminMenuOverviews.setDisable(true);
            labUsername.setText("");

            setLoginLabel(false, new Login());
        }
    }

    private void setLoginLabel(boolean isLoggedIin, Login login) {

        if (isLoggedIin) {

            labUsername.setText("Angemeldet: " + login.getUsername());
            labUsername.setUnderline(false);
            labUsername.setTextFill(Color.BLACK);
            labUsername.setStyle("-fx-font-weight: normal;");
        } else {
            labUsername.setText("Registrieren");
            labUsername.setUnderline(true);
            labUsername.setTextFill(Color.BLUE);
            labUsername.setStyle("-fx-font-weight: bold;");
        }
    }

    @FXML
    public void showListHotelsDialog() {
        Dialog<ButtonType> dialog = new Dialog<ButtonType>();
        dialog.initOwner(mainPanel.getScene().getWindow());
        dialog.setTitle("Hotels");
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(Main.class.getResource("forms/listhotelsdialog.fxml"));
        try {
            dialog.getDialogPane().setContent(fxmlLoader.load());

        } catch (IOException e) {
            System.out.println("Couldn't load the dialog");
            e.printStackTrace();
            return;
        }

        dialog.getDialogPane().getButtonTypes().add(ButtonType.OK);
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CANCEL);

        Optional<ButtonType> result = dialog.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {

        }
    }

    @FXML
    public void showSearchAccommodationsDialog() {
        Dialog<ButtonType> dialog = new Dialog<ButtonType>();
        dialog.initOwner(mainPanel.getScene().getWindow());
        dialog.setTitle("Übernachtungen suchen");
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(Main.class.getResource("forms/searchaccommodationsdialog.fxml"));
        try {
            dialog.getDialogPane().setContent(fxmlLoader.load());

        } catch (IOException e) {
            System.out.println("Couldn't load the dialog");
            e.printStackTrace();
            return;
        }

        dialog.getDialogPane().getButtonTypes().add(ButtonType.OK);
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CANCEL);

        Optional<ButtonType> result = dialog.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {

        }
    }

    @FXML
    public void showListRoomsDialog() {
        Dialog<ButtonType> dialog = new Dialog<ButtonType>();
        dialog.initOwner(mainPanel.getScene().getWindow());
        dialog.setTitle("Zimmer");
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(Main.class.getResource("forms/listroomsdialog.fxml"));
        try {
            dialog.getDialogPane().setContent(fxmlLoader.load());

        } catch (IOException e) {
            System.out.println("Couldn't load the dialog");
            e.printStackTrace();
            return;
        }

        dialog.getDialogPane().getButtonTypes().add(ButtonType.OK);
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CANCEL);

        Optional<ButtonType> result = dialog.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            RoomController roomController = fxmlLoader.getController();

        }
    }

    @FXML
    public void showListGuestsDialog() {
        Dialog<ButtonType> dialog = new Dialog<ButtonType>();
        dialog.initOwner(mainPanel.getScene().getWindow());
        dialog.setTitle("Gäste");
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(Main.class.getResource("forms/listguestsdialog.fxml"));
        try {
            dialog.getDialogPane().setContent(fxmlLoader.load());

        } catch (IOException e) {
            System.out.println("Couldn't load the dialog");
            e.printStackTrace();
            return;
        }

        dialog.getDialogPane().getButtonTypes().add(ButtonType.OK);
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CANCEL);

        Optional<ButtonType> result = dialog.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            GuestController guestController = fxmlLoader.getController();

        }
    }

    @FXML
    public void showListUsersDialog() {
        Dialog<ButtonType> dialog = new Dialog<ButtonType>();
        dialog.initOwner(mainPanel.getScene().getWindow());
        dialog.setTitle("Anmeldungen");
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(Main.class.getResource("forms/listloginsdialog.fxml"));
        try {
            dialog.getDialogPane().setContent(fxmlLoader.load());

        } catch (IOException e) {
            System.out.println("Couldn't load the dialog");
            e.printStackTrace();
            return;
        }

        dialog.getDialogPane().getButtonTypes().add(ButtonType.OK);
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CANCEL);

        Optional<ButtonType> result = dialog.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            LoginController loginController = fxmlLoader.getController();

        }
    }

    @FXML
    private void showRegistrationDialog() throws IOException, URISyntaxException {

        Dialog<ButtonType> dialog = new Dialog<ButtonType>();
        dialog.initOwner(mainPanel.getScene().getWindow());
        dialog.setTitle("Anmeldungen");

        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(Main.class.getResource("forms/RegistrationDialog.fxml"));
        try {
            dialog.getDialogPane().setContent(fxmlLoader.load());
        } catch (IOException e) {
            System.out.println("Couldn't load the dialog");
            e.printStackTrace();
            return;
        }

        dialog.getDialogPane().getButtonTypes().add(ButtonType.OK);
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CANCEL);

        RegistrationController registrationController = fxmlLoader.getController();
        final Button okButton = (Button) dialog.getDialogPane().lookupButton(ButtonType.OK);
        okButton.addEventFilter(ActionEvent.ACTION, ae -> {
            if (!registrationController.isValidRegistration()) {
                ae.consume(); //not valid
            }
        });

        Optional<ButtonType> result = dialog.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            Guest guest = registrationController.getNewGuest();
            GuestService guestService = new GuestService();
            int newGuestId = guestService.insertGuest(guest);

            Login login = registrationController.getNewLogin();
            login.setGuestId(newGuestId);
            LoginService loginService = new LoginService();
            loginService.insertLogin(login);

        }

    }

    public void showHelpContextDialog() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(Common.alertMessage.getProperty("underConstructionTitle"));
        alert.setHeaderText(null);
        alert.setContentText(Common.alertMessage.getProperty("informationUnderConstruction"));
        alert.showAndWait();
    }

    public void showWelcomeDialog() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(Common.alertMessage.getProperty("underConstructionTitle"));
        alert.setHeaderText(null);
        alert.setContentText(Common.alertMessage.getProperty("informationUnderConstruction"));
        alert.showAndWait();
    }

    public void showKeywordSearchDialog() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(Common.alertMessage.getProperty("underConstructionTitle"));
        alert.setHeaderText(null);
        alert.setContentText(Common.alertMessage.getProperty("informationUnderConstruction"));
        alert.showAndWait();
    }

    public void showAboutUsDialog() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(Common.alertMessage.getProperty("underConstructionTitle"));
        alert.setHeaderText(null);
        alert.setContentText(Common.alertMessage.getProperty("informationUnderConstruction"));
        alert.showAndWait();
    }
}

package com.project.hotelbooking.services;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.project.hotelbooking.datamodels.restapi.enums.eHttpStatusCodes;
import com.project.hotelbooking.datamodels.restapi.models.Hotelbooking;
import com.project.hotelbooking.utils.SystemSecure;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.net.URISyntaxException;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.List;

public class HotelbookingService extends RestApiService {
    private final String hotelbookingsURI;
    private final Gson gson;

    public HotelbookingService() {
        super();
        gson= new Gson();

        SystemSecure systemSecure = new SystemSecure();

        String sBaseURI = systemSecure.getRestApiConnectionUri();
        hotelbookingsURI = sBaseURI+systemSecure.getDelimiter()+"hotelbookings"+systemSecure.getDelimiter();
    }

    public ObservableList<Hotelbooking> getHotelbookingsByUser(int userId) {
        HttpResponse<String> getResponse = this.sendGetRequest(hotelbookingsURI + "data-by-user/" + userId);
        System.out.println(getResponse.statusCode());
        System.out.println(getResponse.statusCode());


        if(getResponse.statusCode() == eHttpStatusCodes.HTTP_OK.getValue()) {
            List<Hotelbooking> hotelbookings = gson.fromJson(getResponse.body(), new TypeToken<ArrayList<Hotelbooking>>() {
            }.getType());

            return FXCollections.observableList(hotelbookings);
        } else {
            return null;
        }
    }

    public Hotelbooking getHotelbooking(int hotelBookingId) {
        HttpResponse<String> getResponse = this.sendGetRequest(hotelbookingsURI + hotelBookingId);
        return gson.fromJson(getResponse.body(), Hotelbooking.class);
    }

    public int bookAccomodation(Hotelbooking hotelbooking) throws URISyntaxException {
        String jsonRequest = gson.toJson(hotelbooking);
        return this.sendPostRequest(hotelbookingsURI, jsonRequest);
    }

    public int cancelBooking(int hotelbookingId) throws URISyntaxException {
          return this.sendDeleteRequest(hotelbookingsURI + hotelbookingId);
    }
}


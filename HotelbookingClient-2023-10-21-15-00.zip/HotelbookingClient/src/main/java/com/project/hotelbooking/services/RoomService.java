package com.project.hotelbooking.services;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.project.hotelbooking.datamodels.restapi.enums.eHttpStatusCodes;
import com.project.hotelbooking.datamodels.restapi.models.Room;
import com.project.hotelbooking.utils.Common;
import com.project.hotelbooking.utils.SystemSecure;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;

import java.net.URISyntaxException;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.List;

public class RoomService extends RestApiService {

    private final String roomsURI;
    private final Gson gson;

    public RoomService() {
        super();
        gson= new Gson();

        SystemSecure systemSecure = new SystemSecure();

        String sBaseURI = systemSecure.getRestApiConnectionUri();
        roomsURI = sBaseURI+systemSecure.getDelimiter()+"rooms"+systemSecure.getDelimiter();
    }

    public int insertRoom(Room room)  throws URISyntaxException  {
        String jsonRequest = gson.toJson(room);
        return this.sendPostRequest(roomsURI, jsonRequest);

    }

    public int updateRoom(int roomId, Room room) throws URISyntaxException {
        String jsonRequest = gson.toJson(room);

        return this.sendPutRequest(roomsURI + roomId, jsonRequest);
    }

    public int deleteRoom(int roomId) throws URISyntaxException {
        return this.sendDeleteRequest(roomsURI + roomId);
    }

    public Room getRoom(int roomId) {
        HttpResponse<String> getResponse = this.sendGetRequest(roomsURI + roomId);

        return gson.fromJson(getResponse.body(), Room.class);
    }

    public ObservableList<Room> getRooms() {
        HttpResponse<String> getResponse = this.sendGetRequest(roomsURI);

        if (getResponse.statusCode() == eHttpStatusCodes.HTTP_OK.getValue()) {
            List<Room> rooms = gson.fromJson(getResponse.body(), new TypeToken<ArrayList<Room>>() {
            }.getType());

            return FXCollections.observableList(rooms);
        } else if (getResponse.statusCode() == eHttpStatusCodes.HTTP_NO_CONTENT.getValue()) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle(Common.alertMessage.getProperty("informationNoDataTitle"));
            alert.setHeaderText(null);
            alert.setContentText(Common.alertMessage.getProperty("informationNoRoomsData"));
            alert.showAndWait();
            return null;
        } else {
            return null;
        }
    }

    public ObservableList<Room> getRoomsByRoomFeature(int roomFeatureId) {
        HttpResponse<String> getResponse = this.sendGetRequest(roomsURI+"by-roomfeature/"+roomFeatureId);

        List<Room> rooms = gson.fromJson(getResponse.body(), new TypeToken<ArrayList<Room>>() {
        }.getType());

        return FXCollections.observableList(rooms);
    }
}

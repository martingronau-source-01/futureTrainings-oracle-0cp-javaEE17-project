package com.project.hotelbooking.playground;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Accordion;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TitledPane;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
public class AccordionExample extends Application {
    @Override
    public void start(Stage stage) {
        //Creating toggle buttons
        RadioButton button1 = new RadioButton("Apache Tika");
        RadioButton button2 = new RadioButton("JavaFX");
        RadioButton button3 = new RadioButton("Java ML");
        ToggleGroup group1 = new ToggleGroup();
        group1.getToggles().addAll(button1, button2, button3);
        //Adding the toggle button to the pane
        VBox box1 = new VBox(10);
        box1.setPadding(new Insets(10));
        box1.getChildren().addAll(button1, button2, button3);
        //Creating the TitlePane
        TitledPane pane1 = new TitledPane("Java Libraries", box1);
        pane1.setLayoutX(1);
        pane1.setLayoutY(1);
        //Creating toggle buttons
        RadioButton button4 = new RadioButton("HBase");
        RadioButton button5 = new RadioButton("MongoDB");
        RadioButton button6 = new RadioButton("Neo4j");
        ToggleGroup group2 = new ToggleGroup();
        group2.getToggles().addAll(button4, button5, button6);
        //Adding the toggle button to the pane
        VBox box = new VBox(10);
        box.setPadding(new Insets(10));
        box.getChildren().addAll(button4, button5, button6);
        //Creating the TitlePane
        TitledPane pane2 = new TitledPane("NoSQL Databases", box);
        pane2.setLayoutX(1);
        pane2.setLayoutY(1);
        //Creating a Accordion
        Accordion accor = new Accordion();
        accor.getPanes().add(pane1);
        accor.getPanes().add(pane2);
        VBox vbox = new VBox(accor);
        vbox.setMaxWidth(400f);
        //Setting the stage
        Scene scene = new Scene(vbox, 595, 150, Color.BEIGE);
        stage.setTitle("Accordion Example");
        stage.setScene(scene);
        stage.show();
    }
    public static void main(String args[]){
        launch(args);
    }
}
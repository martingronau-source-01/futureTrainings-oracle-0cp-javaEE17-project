package com.project.hotelbooking.playground;

import java.util.Arrays;
import java.util.List;

public class ListConversionTest {

    public static void main(String[] args) {
        List<String> arraysAsList = Arrays.asList("ONE", "TWO", "THREE","FOUR", "FIVE");

        String commaSeparatedStringValueOfWithDelimiterPrefixSuffix = "(" + arraysAsList.stream()
                .reduce((x, y) ->  x + "," + y)
                .get()+")";

        System.out.println(commaSeparatedStringValueOfWithDelimiterPrefixSuffix);
        System.out.println(commaSeparatedStringValueOfWithDelimiterPrefixSuffix.equals("(ONE,TWO,THREE,FOUR,FIVE)"));
    }
}

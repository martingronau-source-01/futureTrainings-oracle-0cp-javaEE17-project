package com.project.hotelbooking.playground.components;

import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;

import java.util.Objects;

public class CustomRBListView<Lookup> extends ListView {
    private final ToggleGroup group = new ToggleGroup();

    private com.project.hotelbooking.datamodels.restapi.models.Lookup selectedName;

    public CustomRBListView() {
        super();

    }

    public CustomRBListView(ListView listView) {
        setCellFactory(param -> new RadioListCell(listView));
    }

    private class RadioListCell extends ListCell<com.project.hotelbooking.datamodels.restapi.models.Lookup> {

        private final RadioButton radioButton = new RadioButton();

        RadioListCell(ListView listView) {
            radioButton.setToggleGroup(group);
            radioButton.selectedProperty().addListener((obs, wasSelected, isNowSelected) -> {
                if (isNowSelected) {
                    selectedName = getItem();
                    System.out.println(selectedName);

                    System.out.println(listView.getItems().size());
                    listView.getSelectionModel().select(selectedName);

                } else if(wasSelected) {
                    System.out.println(wasSelected);
                }
            });
        }

        @Override
        public void updateItem(com.project.hotelbooking.datamodels.restapi.models.Lookup obj, boolean empty) {
            super.updateItem(obj, empty);
            if (empty) {
                setText(null);
                setGraphic(null);
            } else {
                radioButton.setText(obj.getTitle());

                radioButton.setSelected(Objects.equals(obj, selectedName));

                setGraphic(radioButton);
            }
        }
    }
}

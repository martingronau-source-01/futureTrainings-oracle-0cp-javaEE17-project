package com.project.hotelbooking.services;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.project.hotelbooking.datamodels.restapi.enums.eHttpStatusCodes;
import com.project.hotelbooking.datamodels.restapi.models.HotelOption;
import com.project.hotelbooking.utils.Common;
import com.project.hotelbooking.utils.SystemSecure;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;

import java.net.URISyntaxException;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.List;

public class HotelOptionService extends RestApiService {
    private final String hotelOptionsURI;
    private final Gson gson;

    public HotelOptionService() {
        super();
        gson= new Gson();

        SystemSecure systemSecure = new SystemSecure();

        String sBaseURI = systemSecure.getRestApiConnectionUri();
        hotelOptionsURI = sBaseURI+systemSecure.getDelimiter()+"hotel-options"+systemSecure.getDelimiter();
    }

    public ObservableList<HotelOption> getHotelOptionsByHotel(int hotelId) {
        System.out.println(hotelOptionsURI+"by-hotel/"+hotelId);
        HttpResponse<String> getResponse = this.sendGetRequest(hotelOptionsURI+"by-hotel/"+hotelId);

        List<HotelOption> hotelOptions = gson.fromJson(getResponse.body(), new TypeToken<ArrayList<HotelOption>>() {
        }.getType());

        return FXCollections.observableList(hotelOptions);
    }

    public ObservableList<HotelOption> getHotelOptions() {
        HttpResponse<String> getResponse = this.sendGetRequest(hotelOptionsURI);
        if(getResponse.statusCode() == eHttpStatusCodes.HTTP_OK.getValue()) {
            List<HotelOption> hotelOptions = gson.fromJson(getResponse.body(), new TypeToken<ArrayList<HotelOption>>() {
            }.getType());

            return FXCollections.observableList(hotelOptions);
        } else if(getResponse.statusCode() == eHttpStatusCodes.HTTP_NO_CONTENT.getValue()) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle(Common.alertMessage.getProperty("informationNoDataTitle"));
            alert.setHeaderText(null);
            alert.setContentText(Common.alertMessage.getProperty("informationNoHotelOptionsData"));
            alert.showAndWait();

            return  null;
        } else {
            return null;
        }
    }

    public int insertHotelOption(HotelOption hotelOption)  throws URISyntaxException {
        String jsonRequest = gson.toJson(hotelOption);

        return this.sendPostRequest(hotelOptionsURI, jsonRequest);
    }

    public int updateHotelOption(int optionType, int optionId, HotelOption hotelOption) throws URISyntaxException {
        String jsonRequest = gson.toJson(hotelOption);

        return this.sendPutRequest(hotelOptionsURI + optionType+"/"+optionId, jsonRequest);
    }

    public int deleteHotelOption(int optionType, int optionId) throws URISyntaxException {
        return this.sendDeleteRequest(hotelOptionsURI + optionType+"/"+optionId);
    }
}

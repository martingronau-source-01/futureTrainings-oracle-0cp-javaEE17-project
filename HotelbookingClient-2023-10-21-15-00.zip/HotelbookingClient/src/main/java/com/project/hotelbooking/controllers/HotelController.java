package com.project.hotelbooking.controllers;

import com.project.hotelbooking.Main;
import com.project.hotelbooking.components.LookupCell;
import com.project.hotelbooking.datamodels.restapi.models.*;
import com.project.hotelbooking.services.HotelOptionService;
import com.project.hotelbooking.services.HotelService;
import com.project.hotelbooking.services.RegionService;
import com.project.hotelbooking.utils.Common;
import javafx.beans.InvalidationListener;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.control.cell.CheckBoxListCell;
import javafx.scene.layout.BorderPane;
import lombok.Getter;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class HotelController {
    @FXML
    private Accordion accordion;
    @FXML
    private BorderPane hotelsPanel;
    @FXML
    private TableView<Hotel> hotelsTable;
    @FXML
    private TextField fldName;
    @FXML
    private TextField fldTitle;
    @FXML
    private TextField fldStreet;
    @FXML
    private TextField fldZipcode;
    @FXML
    private TextField fldLocation;
    @FXML
    private TextArea fldDescription;
    @FXML
    private TextField fldEMail;
    @FXML
    private TextField fldPhone;
    @FXML
    private TextField fldWebsite;
    @FXML
    private ComboBox<Lookup> fldRegion;
    private HotelService hotelService;
    HotelOptionService hotelOptionService;
    private int currentHotelId;
    @FXML
    private ListView<CheckBoxLookup> listviewHotelOptions;
    @FXML
    private TitledPane fldHotelOptions;
    private ObservableList<CheckBoxLookup> hotelOptions;

    @Getter
    private ObservableList<Lookup> listRegions;

    public void initialize() {
        hotelService = new HotelService();
        hotelOptionService = new HotelOptionService();

        if (hotelsTable != null) {
            hotelsTable.setItems(hotelService.getHotels());
        } else {
            listRegions = FXCollections.observableArrayList();
            RegionService regionService = new RegionService();

            for (Region region : regionService.getRegions()) {
                listRegions.add(new Lookup(region.getId(), region.getName()));
            }
            fldRegion.setCellFactory(lookups -> new LookupCell());
            fldRegion.setButtonCell(new LookupCell());
            fldRegion.setItems(listRegions);
            fldRegion.setValue(listRegions.get(0));

            hotelOptions = FXCollections.observableArrayList();
            listviewHotelOptions.setCellFactory(factory -> {
                CheckBoxListCell<CheckBoxLookup> cell = new CheckBoxListCell<CheckBoxLookup>() {
                    // a listener on the graphicProperty: it installs the "real" listener
                    final InvalidationListener graphicListener = g -> {
                        // installs the "real" listener on the graphic control once it is available
                        registerUIListener();
                    };

                    {
                        // install the graphic listener at instantiation
                        graphicProperty().addListener(graphicListener);
                    }

                    private void registerUIListener() {
                        if (!(getGraphic() instanceof CheckBox)) throw new IllegalStateException("checkBox expected");
                        graphicProperty().removeListener(graphicListener);
                        ((CheckBox) getGraphic()).selectedProperty().addListener(
                                (observable, oldValue, newValue) -> listviewHotelOptions.getSelectionModel().select(getItem()));
                    }
                };
                cell.setSelectedStateCallback(CheckBoxLookup::selectedProperty);
                return cell;
            });

            for (HotelOption hotelOption : hotelOptionService.getHotelOptions()) {
                hotelOptions.add( new CheckBoxLookup(hotelOption.getName(), false, hotelOption.getOptionId()));
            }
            listviewHotelOptions.setItems(hotelOptions);
            accordion.setExpandedPane(fldHotelOptions);

            fldName.requestFocus();
        }
    }

    @FXML
    public void showAddHotelDialog() throws URISyntaxException {
        Dialog<ButtonType> dialog = new Dialog<ButtonType>();
        dialog.initOwner(hotelsPanel.getScene().getWindow());
        dialog.setTitle("Hotel hinzufügen");
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(Main.class.getResource("forms/hoteldialog.fxml"));
     //   fxmlLoader.setLocation(Main.class.getResource("forms/tabpanels/tabPanelHotelDialog.fxml"));
        try {
            dialog.getDialogPane().setContent(fxmlLoader.load());

        } catch (IOException e) {
            System.out.println("Couldn't load the dialog");
            e.printStackTrace();
            return;
        }

        dialog.getDialogPane().getButtonTypes().add(ButtonType.OK);
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CANCEL);

        HotelController hotelController = fxmlLoader.getController();
        final Button okButton = (Button) dialog.getDialogPane().lookupButton(ButtonType.OK);
        okButton.addEventFilter(ActionEvent.ACTION, ae -> {
           if (!hotelController.isValidHotel()) {
                ae.consume(); //not valid
            }
        });

        Optional<ButtonType> result = dialog.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {

            Hotel newHotel = hotelController.getNewHotel();

            currentHotelId = hotelService.insertHotel(newHotel);
            hotelsTable.setItems(hotelService.getHotels());
            hotelsTable.refresh();
        }
    }

    public boolean isValidHotel() {
        boolean bReturn = true;
        Common.isWarningMessage = true;

        if(fldName.getText().isEmpty()) {
            Common.showValidationMessage("Das Feld Name  darf nicht leer bleiben");
            bReturn = false;
            fldName.requestFocus();
        } else if(fldTitle.getText().isEmpty()) {
            Common.showValidationMessage("Das Feld Titel  darf nicht leer bleiben");
            bReturn = false;
            fldTitle.requestFocus();
        }  else if(fldStreet.getText().isEmpty()) {
            Common.showValidationMessage("Das Feld Strasse darf nicht leer bleiben");
            bReturn = false;
            fldStreet.requestFocus();
        }  else if(fldZipcode.getText().isEmpty()) {
            Common.showValidationMessage("Das Feld PLZ darf nicht leer bleiben");
            bReturn = false;
            fldZipcode.requestFocus();
        }  else if(fldLocation.getText().isEmpty()) {
            Common.showValidationMessage("Das Feld Ort darf nicht leer bleiben");
            bReturn = false;
            fldLocation.requestFocus();
        }   else if(fldEMail.getText().isEmpty()) {
            Common.showValidationMessage("Das Feld EMail darf nicht leer bleiben");
            bReturn = false;
            fldEMail.requestFocus();
        }

        return bReturn;
    }

    public Hotel getNewHotel() {
        String name = fldName.getText();
        String title = fldTitle.getText();
        String description = fldDescription.getText();
        String street = fldStreet.getText();
        String zipcode = fldZipcode.getText();
        String location = fldLocation.getText();
        String email = fldEMail.getText();
        String phone = fldPhone.getText();
        String website = fldWebsite.getText();
        Lookup lookup = fldRegion.getSelectionModel().getSelectedItem();

        Hotel hotel = new Hotel(name, title, street, zipcode, location, description, email, phone, website,
                lookup.getId(), Common.CREATOR, Common.CREATED, true);

        List<Integer> selectedHotelOptionIds = new ArrayList<>();
        for(CheckBoxLookup item :  listviewHotelOptions.getItems()) {
            if(item.isSelected())    {
                selectedHotelOptionIds.add(item.getId());
            }
        }

        hotel.setHotelOptionIds(selectedHotelOptionIds);
        return hotel;
    }

    public void editHotel(Hotel hotel) {
        fldName.setText(hotel.getName());
        fldTitle.setText(hotel.getTitle());
        fldStreet.setText(hotel.getStreet());
        fldZipcode.setText(hotel.getZipcode());
        fldLocation.setText(hotel.getLocation());
        fldEMail.setText(hotel.getEmail());
        fldPhone.setText(hotel.getPhone());
        fldWebsite.setText(hotel.getWebsite());
        fldDescription.setText(hotel.getDescription());

        for (Lookup lookup : fldRegion.getItems()) {
            if (lookup.getId() == hotel.getRegionId()) {
                fldRegion.setValue(lookup);
              //  return;
                break;
            }
        }
        ObservableList<HotelOption> hotelOptionsList = hotelOptionService.getHotelOptionsByHotel(hotel.getId());

        for (CheckBoxLookup lookup : listviewHotelOptions.getItems()) {
            lookup.setSelected(hotelOptionsList.stream().anyMatch(h -> h.getOptionId() == lookup.getId()));
        }

    }

    public void updateHotel(Hotel hotel) {
        hotel.setName(fldName.getText());
        hotel.setTitle(fldTitle.getText());
        hotel.setDescription(fldDescription.getText());
        hotel.setStreet(fldStreet.getText());
        hotel.setZipcode(fldZipcode.getText());
        hotel.setLocation(fldLocation.getText());
        hotel.setEmail(fldEMail.getText());
        hotel.setPhone(fldPhone.getText());
        hotel.setWebsite(fldWebsite.getText());
        hotel.setRegionId(fldRegion.getValue().getId());

        List<Integer> selectedHotelOptionIds = new ArrayList<>();
        for(CheckBoxLookup item :  listviewHotelOptions.getItems()) {
            if(item.isSelected())    {
                selectedHotelOptionIds.add(item.getId());
            }
        }

        hotel.setHotelOptionIds(selectedHotelOptionIds);
    }

    @FXML
    public void showEditHotelDialog() throws URISyntaxException {
        Hotel selectedHotel = hotelsTable.getSelectionModel().getSelectedItem();
        if (selectedHotel == null) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle(Common.alertMessage.getProperty("confirmHotelTitle"));
            alert.setHeaderText(null);
            alert.setContentText(Common.alertMessage.getProperty("confirmEditHotel"));
            alert.showAndWait();
            return;
        }

        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.initOwner(hotelsPanel.getScene().getWindow());
        dialog.setTitle("Hotel bearbeiten");
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(Main.class.getResource("forms/hoteldialog.fxml"));
      //  fxmlLoader.setLocation(Main.class.getResource("forms/tabpanels/tabPanelHotelDialog.fxml"));
        try {
            dialog.getDialogPane().setContent(fxmlLoader.load());
        } catch (IOException e) {
            System.out.println("Couldn't load the dialog");
            e.printStackTrace();
            return;
        }

        dialog.getDialogPane().getButtonTypes().add(ButtonType.OK);
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CANCEL);

        HotelController hotelController = fxmlLoader.getController();

        System.out.println("HotelId (list): "+selectedHotel.getId());
        hotelController.editHotel(selectedHotel);

        final Button okButton = (Button) dialog.getDialogPane().lookupButton(ButtonType.OK);
        okButton.addEventFilter(ActionEvent.ACTION, ae -> {
        if (!hotelController.isValidHotel()) {
                ae.consume(); //not valid
            }
        });

        Optional<ButtonType> result = dialog.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.OK) {

            hotelController.updateHotel(selectedHotel);
            currentHotelId = hotelService.updateHotel(selectedHotel.getId(), selectedHotel);

            hotelsTable.setItems(hotelService.getHotels());
            hotelsTable.refresh();
        }

    }

    @FXML
    public void deleteHotel() throws URISyntaxException {
        Hotel selectedHotel = hotelsTable.getSelectionModel().getSelectedItem();
        if (selectedHotel == null) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle(Common.alertMessage.getProperty("confirmHotelTitle"));
            alert.setHeaderText(null);
            alert.setContentText(Common.alertMessage.getProperty("confirmDeleteHotel"));
            alert.showAndWait();
            return;
        }

        Alert alert = new Alert(Alert.AlertType.NONE,
                "Möchten Sie das Hotel '"+selectedHotel.getTitle()+", "
                        +selectedHotel.getZipcode()+" "+selectedHotel.getLocation()+"' wirklich löschen?",
                Common.YES, Common.NO);

        alert.setTitle("Lösch-Bestätigung!");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.orElse(Common.NO) == Common.YES) {
            hotelService.deleteHotel(selectedHotel.getId());
            hotelsTable.setItems(hotelService.getHotels());
            hotelsTable.refresh();
        }
    }


}

package com.project.hotelbooking.datamodels.restapi.models;

import java.util.Objects;


public class Lookup {

    private int id;

    private String title;

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public Lookup() {
        super();
    }

    public Lookup(int id, String title) {
        this();
        this.id = id;
        this.title = title;
    }

    @Override
    public String toString() {
        return "Lookup{" + "id=" + id + ", title=" + title + '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Lookup lookup)) return false;
        return getId() == lookup.getId() && Objects.equals(getTitle(), lookup.getTitle());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getTitle());
    }

}

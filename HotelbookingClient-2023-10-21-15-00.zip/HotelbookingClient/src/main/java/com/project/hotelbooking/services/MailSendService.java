package com.project.hotelbooking.services;

import com.project.hotelbooking.datamodels.restapi.models.Guest;
import com.project.hotelbooking.datamodels.restapi.models.Hotelbooking;
import com.project.hotelbooking.utils.Common;
import com.project.hotelbooking.utils.SystemSecure;
import jakarta.mail.*;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeBodyPart;
import jakarta.mail.internet.MimeMessage;
import jakarta.mail.internet.MimeMultipart;
import lombok.Getter;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Objects;

@Getter
public class MailSendService {

    private String emailFromAdress = "";
    private List<String> emailRecients = null;

    private String emailRecipient = "";
    private String messageSubject = "";
    private String messageBodyHtml = "";
    private String messageBodyPlain = "";

    private List<String> emailAttachments = null;

    private String emailContentType = "text/html;";

    private String emailDescription = "";
    private Session session;

    @Getter
    private Guest guest;
    @Getter
    private  Hotelbooking hotelbooking;

    public void setHotelbooking(Hotelbooking hotelbooking) {
        this.hotelbooking = hotelbooking;
    }

    public void setGuest(Guest guest) {
        this.guest = guest;
    }

    @Getter
    private  boolean hasAttachment = false;

    public void setHasAttachment(boolean hasAttachment) {
        this.hasAttachment = hasAttachment;
    }

    public MailSendService() {
        super();
        initialize();
    }


    public MailSendService(Guest guest, Hotelbooking hotelbooking, boolean hasAttachment) {
        this();
        this.guest = guest;
        this.hotelbooking = hotelbooking;
        this.hasAttachment = hasAttachment;
    }
    public MailSendService(String emailFromAdress, List<String> emailRecients, String emailRecipient,
                           String messageSubject, String messageBodyHtml, String messageBodyPlain,
                           List<String> emailAttachments, String emailContentType, String emailDescription) {
        this();
        this.emailFromAdress = emailFromAdress;
        this.emailRecients = emailRecients;
        this.emailRecipient = emailRecipient;
        this.messageSubject = messageSubject;
        this.messageBodyHtml = messageBodyHtml;
        this.messageBodyPlain = messageBodyPlain;
        this.emailAttachments = emailAttachments;
        this.emailContentType = emailContentType;
        this.emailDescription = emailDescription;
    }

    protected void initialize() {
        try {
            this.session = MailSendSourceHelper.getMailSesssion();
            if(this.guest == null) { this.guest = new Guest(); }
            if(this.hotelbooking == null) { this.hotelbooking = new Hotelbooking(); }
        } catch(Exception ex) {
            System.out.println(ex.getMessage());
            throw new RuntimeException(ex.getMessage());
        }

    }
    public void setEmailFromAdress(String emailFromAdress) {
        this.emailFromAdress = emailFromAdress;
    }

    public void setEmailRecients(List<String> emailRecients) {
        this.emailRecients = emailRecients;
    }

    public void setEmailRecipient(String emailRecipient) {
        this.emailRecipient = emailRecipient;
    }

    public void setMessageSubject(String messageSubject) {
        this.messageSubject = messageSubject;
    }

    public void setMessageBodyHtml(String messageBodyHtml) {
        this.messageBodyHtml = messageBodyHtml;
    }

    public void setMessageBodyPlain(String messageBodyPlain) {
        this.messageBodyPlain = messageBodyPlain;
    }

    public void setEmailAttachments(List<String> emailAttachments) {
        this.emailAttachments = emailAttachments;
    }

    public void setEmailContentType(String emailContentType) {
        this.emailContentType = emailContentType;
    }

    public void setEmailDescription(String emailDescription) {
        this.emailDescription = emailDescription;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof MailSendService that)) return false;
        return Objects.equals(getEmailFromAdress(), that.getEmailFromAdress()) && Objects.equals(getEmailRecients(),
                that.getEmailRecients()) && Objects.equals(getEmailRecipient(), that.getEmailRecipient())
                && Objects.equals(getMessageSubject(), that.getMessageSubject()) && Objects.equals(getMessageBodyHtml(),
                that.getMessageBodyHtml()) && Objects.equals(getMessageBodyPlain(), that.getMessageBodyPlain())
                && Objects.equals(getEmailAttachments(), that.getEmailAttachments())
                && Objects.equals(getEmailContentType(), that.getEmailContentType())
                && Objects.equals(getEmailDescription(), that.getEmailDescription());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getEmailFromAdress(), getEmailRecients(), getEmailRecipient(), getMessageSubject(),
                getMessageBodyHtml(), getMessageBodyPlain(), getEmailAttachments(), getEmailContentType(),
                getEmailDescription());
    }

    @Override
    public String toString() {
        return "MailSendService{" +
                "emailFromAdress='" + emailFromAdress + '\'' +
                ", emailRecients=" + emailRecients +
                ", emailRecipient='" + emailRecipient + '\'' +
                ", messageSubject='" + messageSubject + '\'' +
                ", messageBodyHtml='" + messageBodyHtml + '\'' +
                ", messageBodyPlain='" + messageBodyPlain + '\'' +
                ", emailAttachments=" + emailAttachments +
                ", emailContentType='" + emailContentType + '\'' +
                ", emailDescription='" + emailDescription + '\'' +
                '}';
    }


    public void sendEMail() {

        Message message = new MimeMessage(session);

        try {
            GuestService guestService = new GuestService();
            guest = guestService.getGuest(Common.guestId);

            if(this.getEmailFromAdress().isEmpty()) {
                this.setEmailFromAdress(Common.DEFAULT_MAIL_FROM_ADDRESS);
            }

            message.setFrom(new InternetAddress(getEmailFromAdress()));

            if(this.getEmailRecipient().isEmpty()) {
                this.setEmailRecipient(guest.getEmail());
            }

            message.setRecipients(
                    Message.RecipientType.TO, InternetAddress.parse(this.getEmailRecipient())
            );
            message.setSubject(getMessageSubject());

            MimeBodyPart mimeBodyPart = new MimeBodyPart();
            mimeBodyPart.setContent(this.emailContentType.equals("text/html;")? messageBodyHtml : messageBodyPlain,
                    getEmailContentType()  + "charset="+MailSendSourceHelper.sendCharset);

            Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(mimeBodyPart);

            /***----------------------------------------------------------------------------------------------------
            * Mail-Attachment: generated Invoice-pdf
            *
             **/
            if(this.hasAttachment) {
                final String nameInvoicePDF = "Rechnung_"
                        + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH-mm"));

                InvoicePDFService invoicePDFService = new InvoicePDFService(guest, hotelbooking);
                invoicePDFService.generateInvoicePositionsSingle();
                invoicePDFService.generatePDFDocument(nameInvoicePDF);

                Path resourceDirectory = Paths.get("src", "main", "resources", "com", "project", "hotelbooking", "pdf");
                String sPdfPath = resourceDirectory.toFile().getAbsolutePath();

                MimeBodyPart attachmentBodyPart = new MimeBodyPart();
                final String ATTACHMENT =  sPdfPath+ (new SystemSecure()).getDelimiter() +nameInvoicePDF+".pdf";

                attachmentBodyPart.attachFile(new File(ATTACHMENT));
                multipart.addBodyPart(attachmentBodyPart);
            }

            message.setContent(multipart);
            Transport.send(message);
        } catch (MessagingException | IOException e) {
            throw new RuntimeException(e);
        }


    }

}

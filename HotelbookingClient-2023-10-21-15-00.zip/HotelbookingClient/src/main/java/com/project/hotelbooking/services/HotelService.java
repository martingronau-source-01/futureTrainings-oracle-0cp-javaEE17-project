package com.project.hotelbooking.services;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.project.hotelbooking.datamodels.restapi.enums.eHttpStatusCodes;
import com.project.hotelbooking.datamodels.restapi.models.Hotel;
import com.project.hotelbooking.utils.Common;
import com.project.hotelbooking.utils.SystemSecure;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;

import java.net.URISyntaxException;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.List;

public class HotelService extends RestApiService {
    private final String hotelsURI;
    private final Gson gson;

    public HotelService() {
        super();
        gson= new Gson();

        SystemSecure systemSecure = new SystemSecure();

        String sBaseURI = systemSecure.getRestApiConnectionUri();
        hotelsURI = sBaseURI+systemSecure.getDelimiter()+"hotels"+systemSecure.getDelimiter();
    }

    public int insertHotel(Hotel hotel)  throws URISyntaxException {
        String jsonRequest = gson.toJson(hotel);
        return this.sendPostRequest(hotelsURI, jsonRequest);

    }

    public int updateHotel(int hotelId, Hotel hotel) throws URISyntaxException {
        String jsonRequest = gson.toJson(hotel);

        return this.sendPutRequest(hotelsURI + hotelId, jsonRequest);
    }

    public int deleteHotel(int hotelId) throws URISyntaxException {
        return this.sendDeleteRequest(hotelsURI + hotelId);
    }

    public Hotel getHotel(int hotelId) {
        System.out.println(hotelsURI + hotelId);
        HttpResponse<String> getResponse = this.sendGetRequest(hotelsURI + hotelId);

        return gson.fromJson(getResponse.body(), Hotel.class);
    }

    public ObservableList<Hotel> getHotels() {
        HttpResponse<String> getResponse = this.sendGetRequest(hotelsURI);
        List<Hotel> hotels = gson.fromJson(getResponse.body(), new TypeToken<ArrayList<Hotel>>() {
        }.getType());

        return FXCollections.observableList(hotels);
    }


    public ObservableList<Hotel> getHotelsByHotelOption(int hotelOptionId) {
        HttpResponse<String> getResponse = this.sendGetRequest(hotelsURI+"by-hoteloption/"+hotelOptionId);
        if(getResponse.statusCode() == eHttpStatusCodes.HTTP_OK.getValue()) {
            List<Hotel> hotels = gson.fromJson(getResponse.body(), new TypeToken<ArrayList<Hotel>>() {
            }.getType());

            return FXCollections.observableList(hotels);
        } else if(getResponse.statusCode() == eHttpStatusCodes.HTTP_NO_CONTENT.getValue()) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle(Common.alertMessage.getProperty("informationNoDataTitle"));
            alert.setHeaderText(null);
            alert.setContentText(Common.alertMessage.getProperty("informationNoHotelsData"));
            alert.showAndWait();

            return  null;
        } else {
            return null;
        }

    }
}

package com.project.hotelbooking.controllers;

import com.project.hotelbooking.Main;
import com.project.hotelbooking.components.LookupCell;
import com.project.hotelbooking.datamodels.restapi.models.Guest;
import com.project.hotelbooking.datamodels.restapi.models.Login;
import com.project.hotelbooking.datamodels.restapi.models.Lookup;
import com.project.hotelbooking.datamodels.restapi.models.Role;
import com.project.hotelbooking.services.GuestService;
import com.project.hotelbooking.services.LoginService;
import com.project.hotelbooking.services.RoleService;
import com.project.hotelbooking.utils.Common;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.Optional;

public class LoginController  {

    @FXML
    private BorderPane loginsPanel;
    @FXML
    private TableView<Login> loginsTable;
    private ObservableList<Lookup> listRoles;
    private ObservableList<Lookup> listGuests;
    @FXML
    private ComboBox<Lookup> fldGuest;
    @FXML
    private ComboBox<Lookup> fldRole;
    @FXML
    private TextField fldUsername;
    @FXML
    private TextField fldLoginname;
    @FXML
    private PasswordField fldPassword;
    @FXML
    private PasswordField fldPasswordRepeat;
    @FXML
    private CheckBox fldChangePassword;
    @FXML
    private CheckBox fldRegistered;
    private LoginService loginService;
    private int currentLoginId;

    public void initialize() {
        loginService = new LoginService();

        if (loginsTable != null) {
            loginsTable.setItems(loginService.getLogins());
        }  else {
            listGuests = FXCollections.observableArrayList();
            GuestService guestService = new GuestService();

            for (Guest guest : guestService.getGuests()) {
                listGuests.add(new Lookup(guest.getId(), guest.getFirstName()
                        +" "+guest.getLastName()+", "+guest.getLocation()));
            }
            fldGuest.setCellFactory(lookups -> new LookupCell());
            fldGuest.setButtonCell(new LookupCell());
            fldGuest.setItems(listGuests);
            fldGuest.setValue(listGuests.get(0));

            listRoles = FXCollections.observableArrayList();
            RoleService roleService = new RoleService();

            for (Role role : roleService.getRoles()) {
                listRoles.add(new Lookup(role.getId(), role.getDescription()));
            }
            fldRole.setCellFactory(lookups -> new LookupCell());
            fldRole.setButtonCell(new LookupCell());
            fldRole.setItems(listRoles);
            fldRole.setValue(listRoles.get(0));

            fldChangePassword.setSelected(true);

            fldUsername.requestFocus();
        }

    }

    @FXML
    public void showAddLoginDialog() throws URISyntaxException {
        Dialog<ButtonType> dialog = new Dialog<ButtonType>();
        dialog.initOwner(loginsPanel.getScene().getWindow());
        dialog.setTitle("Anmeldung hinzufügen");
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(Main.class.getResource("forms/logindialog.fxml"));
        try {
            dialog.getDialogPane().setContent(fxmlLoader.load());

        } catch (IOException e) {
            System.out.println("Couldn't load the dialog");
            e.printStackTrace();
            return;
        }

        dialog.getDialogPane().getButtonTypes().add(ButtonType.OK);
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CANCEL);

        Optional<ButtonType> result = dialog.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            LoginController loginController = fxmlLoader.getController();
            Login newLogin = loginController.getNewLogin();
            currentLoginId = loginService.insertLogin(newLogin);
            loginsTable.setItems(loginService.getLogins());
        }
    }

    public Login getNewLogin() {
        String username = fldUsername.getText();
        String loginName = fldLoginname.getText();
        String password = fldPassword.getText();
        Lookup role = fldRole.getSelectionModel().getSelectedItem();
        Lookup guest = fldGuest.getSelectionModel().getSelectedItem();
        boolean registered = fldRegistered.isSelected();

        String salt = "";
        boolean hasData = true;

        return new Login(username,loginName,password,salt,role.getId(),registered,
                guest.getId(), Common.CREATOR, Common.CREATED, hasData);
    }

    public void editLogin(Login login) {
        fldUsername.setText(login.getUsername());
        fldLoginname.setText(login.getLoginname());
  //      fldPassword.setText(login.getPassword());
        fldRegistered.setSelected(login.isRegistered());

        for (Lookup role : fldRole.getItems()) {
            if (role.getId() == login.getRoleId()) {
                fldRole.setValue(role);
                break;
            }
        }

        for (Lookup guest : fldGuest.getItems()) {
            if (guest.getId() == login.getGuestId()) {
                System.out.println(login.getGuestId());
                fldGuest.setValue(guest);
                break;
            }
        }

    }

    public void updateLogin(Login login) {
        login.setUsername(fldUsername.getText());
        login.setLoginname(fldLoginname.getText());
        if( fldChangePassword.isSelected()) {
            login.setPassword(fldPassword.getText());
        }
        login.setRegistered(fldRegistered.isSelected());

        login.setRoleId(fldRole.getValue().getId());
        login.setGuestId(fldGuest.getValue().getId());
    }
    
    @FXML
    public void showEditLoginDialog() throws URISyntaxException {
        Login selectedLogin = loginsTable.getSelectionModel().getSelectedItem();
        if (selectedLogin == null) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle(Common.alertMessage.getProperty("confirmLoginTitle"));
            alert.setHeaderText(null);
            alert.setContentText(Common.alertMessage.getProperty("confirmEditLogin"));
            alert.showAndWait();
            return;
        }

        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.initOwner(loginsPanel.getScene().getWindow());
        dialog.setTitle("Anmeldung bearbeiten");
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(Main.class.getResource("forms/logindialog.fxml"));
        try {
            dialog.getDialogPane().setContent(fxmlLoader.load());
        } catch (IOException e) {
            System.out.println("Couldn't load the dialog");
            e.printStackTrace();
            return;
        }

        dialog.getDialogPane().getButtonTypes().add(ButtonType.OK);
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CANCEL);

        LoginController loginController = fxmlLoader.getController();
        loginController.editLogin(selectedLogin);

        final Button okButton = (Button) dialog.getDialogPane().lookupButton(ButtonType.OK);
        okButton.addEventFilter(ActionEvent.ACTION, ae -> {
            if (!loginController.isValidLogin()) {
                ae.consume(); //not valid
            }
        });

        Optional<ButtonType> result = dialog.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {

            loginController.updateLogin(selectedLogin);
            currentLoginId = loginService.updateLogin(selectedLogin.getId(), selectedLogin);

            loginsTable.setItems(loginService.getLogins());
            loginsTable.refresh();
        }

    }

    private boolean isValidLogin() {
        boolean bReturn = true;
        Common.isWarningMessage = true;

        if(fldUsername.getText().isEmpty()) {
            Common.showValidationMessage("Das Feld Benutzername  darf nicht leer bleiben");
            bReturn = false;
            fldUsername.requestFocus();
        } else if(fldLoginname.getText().isEmpty()) {
            Common.showValidationMessage("Das Feld Anmeldename  darf nicht leer bleiben");
            bReturn = false;
            fldLoginname.requestFocus();
        } else if(fldPassword.getText().isEmpty() && fldChangePassword.isSelected()) {
            Common.showValidationMessage("Das Feld Kennwort  darf nicht leer bleiben");
            bReturn = false;
            fldPassword.requestFocus();
        } else if(!fldPassword.getText().isEmpty() && !fldChangePassword.isSelected()) {
            Common.showValidationMessage("Das Kennwort soll nicht geändert werden, bitte leer lassen.");
            bReturn = false;
            fldPassword.requestFocus();
        } else if(fldPasswordRepeat.getText().isEmpty() && fldChangePassword.isSelected()) {
            Common.showValidationMessage("Das Feld Kennwort-Wiederholung  darf nicht leer bleiben");
            bReturn = false;
            fldPasswordRepeat.requestFocus();
        }   else if(!fldPassword.getText().equals(fldPasswordRepeat.getText()) && fldChangePassword.isSelected()) {
            Common.showValidationMessage("Die Felder Kennwort und Kennwort-Wiederholung stimmen nicht überein");
            bReturn = false;
            fldPassword.setText("");
            fldPasswordRepeat.setText("");

            fldPassword.requestFocus();
        }

        return bReturn;
    }

    @FXML
    public void deleteLogin() throws URISyntaxException {
        Login selectedLogin = loginsTable.getSelectionModel().getSelectedItem();
        if (selectedLogin == null) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle(Common.alertMessage.getProperty("confirmLoginTitle"));
            alert.setHeaderText(null);
            alert.setContentText(Common.alertMessage.getProperty("confirmDeleteLogin"));
            alert.showAndWait();
            return;
        }

        Alert alert = new Alert(Alert.AlertType.NONE,
                "Möchten Sie das Login '"+selectedLogin.getLoginname()+", "
                        +selectedLogin.getRole()+"' wirklich löschen?",
                Common.YES, Common.NO);

        alert.setTitle("Lösch-Bestätigung!");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.orElse(Common.NO) == Common.YES) {
            loginService.deleteLogin(selectedLogin.getId());
            loginsTable.setItems(loginService.getLogins());
            loginsTable.refresh();
        }
    }
}

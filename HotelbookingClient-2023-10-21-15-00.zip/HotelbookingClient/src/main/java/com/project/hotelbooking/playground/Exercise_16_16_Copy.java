package com.project.hotelbooking.playground;

import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class Exercise_16_16_Copy extends Application {

    ListView<String> listCountries = new ListView<String>();

    public static void main(String[] args) {
        Application.launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        HBox topSection = new HBox();
        topSection.setPadding(new Insets(3));
        topSection.setSpacing(5);
        topSection.setAlignment(Pos.CENTER);

        ComboBox<SelectionMode> comboList = new ComboBox<SelectionMode>();
        comboList.getItems().add(SelectionMode.SINGLE);
        comboList.getItems().add(SelectionMode.MULTIPLE);
        comboList.setValue(comboList.getItems().get(0));
        comboList.setOnAction(e-> listCountries.getSelectionModel().setSelectionMode(comboList.getValue()));

        Label comboBoxLabel = new Label("Selection Mode: ", comboList);

        comboBoxLabel.setContentDisplay(ContentDisplay.RIGHT);

        topSection.getChildren().add(comboBoxLabel);

        HBox bottomSection = new HBox();
        bottomSection.setPadding(new Insets(3));
        bottomSection.setAlignment(Pos.CENTER_LEFT);

        Label lblSelectedItem = new Label("No Selected Items");
        lblSelectedItem.setPadding(new Insets(5));

        bottomSection.getChildren().add(lblSelectedItem);

        Pane centerSection = new Pane();
        listCountries.getItems().addAll("China", "Japan", "Korea", "India", "Malaysia", "Vietnam");
        listCountries.setPrefHeight(listCountries.getItems().size() * 26);
        centerSection.getChildren().add(listCountries);

        listCountries.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            lblSelectedItem.setText(getItems());
            primaryStage.sizeToScene();
        });

        BorderPane brdrPane = new BorderPane();
        brdrPane.setTop(topSection);
        brdrPane.setCenter(centerSection);
        brdrPane.setBottom(bottomSection);
        Scene scene = new Scene(brdrPane);
        primaryStage.setScene(scene);
        primaryStage.setTitle("ListView");
        primaryStage.show();
    }

    private String getItems() {
        ObservableList<String> selectedCountries = listCountries.getSelectionModel().getSelectedItems();
        if (selectedCountries.size() == 0) {
            return "No Countries Selected";
        }
        if (selectedCountries.size() == 1) {
            return "Selected Item " + selectedCountries.get(0);
        }
        String displayText = "Selected Items are ";
        for (String country : selectedCountries) {
            displayText += country + " ";
        }
        return displayText;
    }
}

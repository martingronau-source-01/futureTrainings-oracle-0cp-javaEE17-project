package com.project.hotelbooking.controllers.tabpanels;

import com.project.hotelbooking.datamodels.restapi.models.CheckBoxLookup;
import com.project.hotelbooking.datamodels.restapi.models.HotelOption;
import com.project.hotelbooking.services.HotelOptionService;
import javafx.beans.InvalidationListener;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ListView;
import javafx.scene.control.cell.CheckBoxListCell;
import javafx.scene.layout.GridPane;

import java.net.URL;
import java.util.ResourceBundle;

public class TabHotelOptionsEditController  implements Initializable {

    @FXML
    private GridPane hotelOptionsEditPanel;
    private HotelOptionService hotelOptionService;
    @FXML
    private ListView<CheckBoxLookup> listviewHotelOptionsEdit;
    private ObservableList<CheckBoxLookup> hotelOptions;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        hotelOptionsEditPanel.setPadding(new Insets(10,20,10,20));

        hotelOptionService = new HotelOptionService();
        hotelOptions = FXCollections.observableArrayList();
    }

    public void editHotelOptionsByHotel(int hotelId) {

        listviewHotelOptionsEdit.setCellFactory(factory -> {
            CheckBoxListCell<CheckBoxLookup> cell = new CheckBoxListCell<CheckBoxLookup>() {
                // a listener on the graphicProperty: it installs the "real" listener
                final InvalidationListener graphicListener = g -> {
                    // installs the "real" listener on the graphic control once it is available
                    registerUIListener();
                };

                {
                    // install the graphic listener at instantiation
                    graphicProperty().addListener(graphicListener);
                }

                private void registerUIListener() {
                    if (!(getGraphic() instanceof CheckBox)) throw new IllegalStateException("checkBox expected");
                    graphicProperty().removeListener(graphicListener);
                    ((CheckBox) getGraphic()).selectedProperty().addListener(
                            (observable, oldValue, newValue) -> listviewHotelOptionsEdit.getSelectionModel().select(getItem()));
                }
            };
            cell.setSelectedStateCallback(CheckBoxLookup::selectedProperty);
            return cell;
        });

        for (HotelOption hotelOption : hotelOptionService.getHotelOptionsByHotel(hotelId)) {
            hotelOptions.add( new CheckBoxLookup(hotelOption.getTitle(), true, hotelOption.getId()));
        }

        listviewHotelOptionsEdit.setItems(hotelOptions);
    }

}

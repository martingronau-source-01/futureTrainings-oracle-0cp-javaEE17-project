package com.project.hotelbooking.datamodels.restapi.enums;

public enum eRoleTypes {
	NO_ROLE(0), GUEST_ROLE(1), MODERATOR_ROLE(2), MANAGER_ROLE(3), ADMIN_ROLE(4), SUPERADMIN_ROLE(5);

	private final int value;

	eRoleTypes(int value) {
		this.value = value;
	}

	public int getValue() {
		return value;
	}
}

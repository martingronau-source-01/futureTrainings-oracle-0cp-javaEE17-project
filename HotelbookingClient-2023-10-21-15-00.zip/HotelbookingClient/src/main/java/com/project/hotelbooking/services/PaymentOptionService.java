package com.project.hotelbooking.services;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.project.hotelbooking.datamodels.restapi.enums.eHttpStatusCodes;
import com.project.hotelbooking.datamodels.restapi.models.PaymentOption;
import com.project.hotelbooking.utils.Common;
import com.project.hotelbooking.utils.SystemSecure;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;

import java.net.URISyntaxException;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.List;

public class PaymentOptionService extends RestApiService {
    private final String paymentOptionsURI;
    private final Gson gson;

    public PaymentOptionService() {
        super();
        gson= new Gson();

        SystemSecure systemSecure = new SystemSecure();

        String sBaseURI = systemSecure.getRestApiConnectionUri();
        paymentOptionsURI = sBaseURI+systemSecure.getDelimiter()+"payment-options"+systemSecure.getDelimiter();
    }

    public ObservableList<PaymentOption> getPaymentOptions() {
        HttpResponse<String> getResponse = this.sendGetRequest(paymentOptionsURI);
        if(getResponse.statusCode() == eHttpStatusCodes.HTTP_OK.getValue()) {
            List<PaymentOption> paymentOptions = gson.fromJson(getResponse.body(), new TypeToken<ArrayList<PaymentOption>>() {
            }.getType());

            return FXCollections.observableList(paymentOptions);
        } else if(getResponse.statusCode() == eHttpStatusCodes.HTTP_NO_CONTENT.getValue()) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle(Common.alertMessage.getProperty("informationNoDataTitle"));
            alert.setHeaderText(null);
            alert.setContentText(Common.alertMessage.getProperty("informationNoPaymentOptionsData"));
            alert.showAndWait();

            return  null;
        } else {
            return null;
        }
    }

    public ObservableList<PaymentOption> getPaymentOptionsByPayment(int paymentId) {
        HttpResponse<String> getResponse = this.sendGetRequest(paymentOptionsURI+"by-payment/"+paymentId);

        List<PaymentOption> paymentOptions = gson.fromJson(getResponse.body(), new TypeToken<ArrayList<PaymentOption>>() {
        }.getType());

        return FXCollections.observableList(paymentOptions);
    }

    public int insertPaymentOption(PaymentOption paymentOption)  throws URISyntaxException {
        String jsonRequest = gson.toJson(paymentOption);

        return this.sendPostRequest(paymentOptionsURI, jsonRequest);
    }

    public int updatePaymentOption(int optionType, int optionId, PaymentOption paymentOption) throws URISyntaxException {
        String jsonRequest = gson.toJson(paymentOption);

        return this.sendPutRequest(paymentOptionsURI + optionType+"/"+optionId, jsonRequest);
    }

    public int deletePaymentOption(int optionType, int optionId) throws URISyntaxException {
        return this.sendDeleteRequest(paymentOptionsURI + optionType+"/"+optionId);
    }
}

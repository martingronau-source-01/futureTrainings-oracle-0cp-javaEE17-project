package com.project.hotelbooking.playground.controllers.tabPanels;

import com.project.hotelbooking.datamodels.restapi.models.Guest;
import com.project.hotelbooking.utils.Common;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.control.CheckBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;

public class TabRegistrationGuestController {

    @FXML
    private GridPane registrationGuestDataPanel;
    @FXML
    private TextField fldFirstName;

    @FXML
    private TextField fldLastName;

    @FXML
    private DatePicker fldBirthDate;

    @FXML
    private TextField fldStreet;

    @FXML
    private TextField fldZipcode;

    @FXML
    private TextField fldLocation;

    @FXML
    private TextField fldEMail;

    @FXML
    private TextField fldPhone;

    @FXML
    private CheckBox fldBusiness;

    @FXML
    private CheckBox fldRegularCustomer;

    public void initialize() {
        registrationGuestDataPanel.setPadding(new Insets(30, 25, 15, 35));

        fldFirstName.setText("test");
    }

    public Guest getNewGuest() {
        String firstName = fldFirstName.getText();
        String lastName = fldLastName.getText();
    //    String birthDate = fldBirthDate.getValue().toString();
        String birthDate = "";
        String street = fldStreet.getText();
        String zipcode = fldZipcode.getText();
        String location = fldLocation.getText();
        String email = fldEMail.getText();
        String phone = fldPhone.getText();
        boolean isBusiness = fldBusiness.isSelected();
        boolean isRegularCustomer = fldRegularCustomer.isSelected();

        System.out.println(firstName);

        return new Guest(firstName, lastName,  birthDate, street, zipcode, location, email, phone,
                isBusiness,isRegularCustomer, Common.CREATOR,  Common.CREATED, true);
    }
}

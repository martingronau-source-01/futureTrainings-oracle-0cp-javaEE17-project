package com.project.hotelbooking.datamodels.restapi.models;

import com.project.hotelbooking.datamodels.restapi.enums.eOptionTypes;

import java.util.List;
import java.util.Objects;

public class PaymentOption extends Option {
	private int optionId = 0;
	private int countPayments = 0;
	private List<Integer> paymentIds = null;
	private boolean approval = false;

	public PaymentOption() {
		super();
	}

	public PaymentOption(int id, String name, String title, String description, boolean approval, int optionId,
			String creator, String created, boolean hasData) {
		this(id, name, title, description, creator, created, hasData);
		this.approval = approval;
		this.optionId = optionId;
	}

	public PaymentOption(int id, String name, String title, String description, String creator, String created,
			boolean hasData) {
		super(id, name, title, description, eOptionTypes.ROOM_FEATURE.getValue(), creator, created, hasData);
	}

	public PaymentOption(String name, String title, String description, String creator, String created,
			boolean hasData) {
		super(name, title, description, eOptionTypes.ROOM_FEATURE.getValue(), creator, created, hasData);
	}

	public boolean isApproval() {
		return approval;
	}

	public void setApproval(boolean approval) {
		this.approval = approval;
	}

	public int getOptionId() {
		return optionId;
	}

	public void setOptionId(int optionId) {
		this.optionId = optionId;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		PaymentOption other = (PaymentOption) obj;
		return approval == other.approval && countPayments == other.countPayments && optionId == other.optionId
				&& Objects.equals(paymentIds, other.paymentIds);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Objects.hash(approval, countPayments, optionId, paymentIds);
		return result;
	}

	@Override
	public String toString() {
		return "PaymentOption [optionId=" + optionId + ", countPayments=" + countPayments + ", paymentIds=" + paymentIds
				+ ", approval=" + approval + "]";
	}

	public int getCountPayments() {
		return countPayments;
	}

	public void setCountPayments(int countPayments) {
		this.countPayments = countPayments;
	}

	public List<Integer> getPaymentIds() {
		return paymentIds;
	}

	public void setPaymentIds(List<Integer> paymentIds) {
		this.paymentIds = paymentIds;
	}

}

package com.project.hotelbooking.services;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.project.hotelbooking.datamodels.restapi.enums.eHttpStatusCodes;
import com.project.hotelbooking.datamodels.restapi.models.Region;
import com.project.hotelbooking.utils.Common;
import com.project.hotelbooking.utils.SystemSecure;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;

import java.net.URISyntaxException;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.List;

public class RegionService extends RestApiService {

    private final String regionsURI;
    private final Gson gson;

    public RegionService() {
        super();
        gson= new Gson();

        SystemSecure systemSecure = new SystemSecure();

        String sBaseURI = systemSecure.getRestApiConnectionUri();
        regionsURI = sBaseURI+systemSecure.getDelimiter()+"regions"+systemSecure.getDelimiter();
    }

    public int insertRegion(Region region)  throws URISyntaxException  {
        String jsonRequest = gson.toJson(region);
        return this.sendPostRequest(regionsURI, jsonRequest);

    }

    public int updateRegion(int regionId, Region region) throws URISyntaxException {
        String jsonRequest = gson.toJson(region);

        return this.sendPutRequest(regionsURI + regionId, jsonRequest);
    }

    public int deleteRegion(int regionId) throws URISyntaxException {
        return this.sendDeleteRequest(regionsURI + regionId);
    }

    public Region getRegion(int regionId) {
        HttpResponse<String> getResponse = this.sendGetRequest(regionsURI + regionId);

        return gson.fromJson(getResponse.body(), Region.class);
    }

    public ObservableList<Region> getRegions() {
        HttpResponse<String> getResponse = this.sendGetRequest(regionsURI);

        if (getResponse.statusCode() == eHttpStatusCodes.HTTP_OK.getValue()) {
            List<Region> regions = gson.fromJson(getResponse.body(), new TypeToken<ArrayList<Region>>() {
            }.getType());
            return FXCollections.observableList(regions);
        } else if (getResponse.statusCode() == eHttpStatusCodes.HTTP_NO_CONTENT.getValue()) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle(Common.alertMessage.getProperty("informationNoDataTitle"));
            alert.setHeaderText(null);
            alert.setContentText(Common.alertMessage.getProperty("informationNoRegionsData"));
            alert.showAndWait();
            return null;
        } else {
            return null;
        }
    }
}

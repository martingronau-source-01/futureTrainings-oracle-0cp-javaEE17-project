package com.project.hotelbooking.datamodels.restapi.models;

import java.util.Objects;

public class Payment {
	private int id = 0;
	private String invoiceNumber = "";
	private String name = "";
	private String title = "";
	private String description = "";
	private double totalcost = 0.00;
	private double mwst = 0.00;
	private String waehrung = "";
	private String creator = "";
	private String created = "";
	private boolean hasData = false;

	public Payment() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Payment(int id, String invoiceNumber, String name, String title, String description, 
			double totalcost, double mwst, String waehrung, String creator, String created, boolean hasData) {
		super();
		this.id = id;
		this.setInvoiceNumber(invoiceNumber);
		this.name = name;
		this.title = title;
		this.description = description;
		this.totalcost = totalcost;
		this.mwst = mwst;
		this.waehrung = waehrung;
		this.creator = creator;
		this.created = created;
		this.hasData = hasData;
	}

	@Override
	public int hashCode() {
		return Objects.hash(created, creator, description, hasData, id, invoiceNumber, mwst, name, title, totalcost,
				waehrung);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Payment other = (Payment) obj;
		return Objects.equals(created, other.created) && Objects.equals(creator, other.creator)
				&& Objects.equals(description, other.description) && hasData == other.hasData && id == other.id
				&& Objects.equals(invoiceNumber, other.invoiceNumber)
				&& Double.doubleToLongBits(mwst) == Double.doubleToLongBits(other.mwst)
				&& Objects.equals(name, other.name) && Objects.equals(title, other.title)
				&& Double.doubleToLongBits(totalcost) == Double.doubleToLongBits(other.totalcost)
				&& Objects.equals(waehrung, other.waehrung);
	}

	@Override
	public String toString() {
		return "Payment [id=" + id + ", invoiceNumber=" + invoiceNumber + ", name=" + name + ", title=" + title
				+ ", description=" + description + ", totalcost=" + totalcost + ", mwst=" + mwst + ", waehrung="
				+ waehrung + ", creator=" + creator + ", created=" + created + ", hasData=" + hasData + "]";
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public double getTotalcost() {
		return totalcost;
	}

	public void setTotalcost(double totalcost) {
		this.totalcost = totalcost;
	}

	public double getMwst() {
		return mwst;
	}

	public void setMwst(double mwst) {
		this.mwst = mwst;
	}

	public String getWaehrung() {
		return waehrung;
	}

	public void setWaehrung(String waehrung) {
		this.waehrung = waehrung;
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public String getCreated() {
		return created;
	}

	public void setCreated(String created) {
		this.created = created;
	}

	public boolean isHasData() {
		return hasData;
	}

	public void setHasData(boolean hasData) {
		this.hasData = hasData;
	}

	public String getInvoiceNumber() {
		return invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

}

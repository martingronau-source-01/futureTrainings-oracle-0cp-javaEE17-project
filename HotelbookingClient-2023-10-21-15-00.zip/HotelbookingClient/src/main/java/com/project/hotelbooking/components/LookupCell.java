package com.project.hotelbooking.components;

import com.project.hotelbooking.datamodels.restapi.models.Lookup;
import javafx.scene.control.ListCell;

public class LookupCell  extends ListCell<Lookup> {

    @Override
    protected void updateItem(Lookup item, boolean empty) {
        super.updateItem(item, empty);
        if (item != null) {
            setText(item.getTitle());
        } else {
            setText(null);
        }
    }

}

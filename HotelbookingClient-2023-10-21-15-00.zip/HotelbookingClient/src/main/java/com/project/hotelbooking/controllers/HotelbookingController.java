package com.project.hotelbooking.controllers;

import com.project.hotelbooking.datamodels.restapi.models.Guest;
import com.project.hotelbooking.datamodels.restapi.models.Hotelbooking;
import com.project.hotelbooking.services.GuestService;
import com.project.hotelbooking.services.HotelbookingService;
import com.project.hotelbooking.services.MailSendService;
import com.project.hotelbooking.utils.Common;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableView;

import java.net.URISyntaxException;
import java.net.URL;
import java.time.LocalDate;
import java.util.Optional;
import java.util.ResourceBundle;

public class HotelbookingController implements Initializable {
    HotelbookingService hotelbookingService;
    @FXML
    private TableView<Hotelbooking> hotelbookingsTable;
    @FXML
    private MenuItem menCancelHotelbooking;
    @FXML
    private MenuItem menDisplayBookingDetails;


    @Override
    public void initialize(URL location, ResourceBundle resources) {
        hotelbookingService = new HotelbookingService();

        if (hotelbookingsTable != null) {
            hotelbookingsTable.setItems(hotelbookingService.getHotelbookingsByUser(Common.guestId ));
        }
    }

    @FXML
    public void cancelHotelbooking() throws URISyntaxException {
        Hotelbooking selectedHotelbooking = hotelbookingsTable.getSelectionModel().getSelectedItem();
        if (selectedHotelbooking == null) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle(Common.alertMessage.getProperty("confirmHotelbookingTitle"));
            alert.setHeaderText(null);
            alert.setContentText(Common.alertMessage.getProperty("confirmCancelHotelbooking"));
            alert.showAndWait();
            return;
        }

        Alert alert = new Alert(Alert.AlertType.NONE,
                "Möchten Sie die Buchung des Hotelzimmers '"+selectedHotelbooking.getRoomName()+"' wirklich stornieren?",
                Common.YES, Common.NO);

        alert.setTitle("Lösch-Bestätigung!");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.orElse(Common.NO) == Common.YES) {
            hotelbookingService.cancelBooking(selectedHotelbooking.getBookingId());
            hotelbookingsTable.setItems(hotelbookingService.getHotelbookingsByUser(Common.guestId));
            hotelbookingsTable.refresh();

            menCancelHotelbooking.setDisable(hotelbookingsTable.getItems() == null || hotelbookingsTable.getItems().isEmpty());
            menDisplayBookingDetails.setDisable(hotelbookingsTable.getItems() == null || hotelbookingsTable.getItems().isEmpty());

            sendSubmitMessageOnCancelHotelBooking(selectedHotelbooking);

            Common.showValidationMessage("Gratulation, Sie haben Ihre ausgewählte Buchung erfolgreich storniert!");
        }
    }

    private void sendSubmitMessageOnCancelHotelBooking(Hotelbooking hotelbooking) {

        GuestService guestService = new GuestService();

        Guest guest = guestService.getGuest(Common.guestId);
        MailSendService mailSendService = new MailSendService();

        mailSendService.setEmailRecipient(guest.getEmail());
        mailSendService.setEmailFromAdress(!hotelbooking.getHotelEMail().isEmpty() ?
                hotelbooking.getHotelEMail() : Common.DEFAULT_MAIL_FROM_ADDRESS);

        mailSendService.setMessageSubject("Stornierung gebuchter Übernachtungen!");
        mailSendService.setEmailContentType("text/html;");

        StringBuilder sbMessageBody = new StringBuilder("<div class=\"mailtext\">")
                .append("<p stype='margin-top: 3rem'>").append(hotelbooking.getHotelName())
                .append(" (").append(hotelbooking.getHotelTitle()).append(")</p>")
                .append("<p>").append(hotelbooking.getHotelStreet()).append("</p>")
                .append("<p>").append(hotelbooking.getHotelZipcode()).append(" ")
                .append(hotelbooking.getHotelLocation()).append("</p>")
                .append("<p style='margin-bottom: 5rem'>").append(hotelbooking.getHotelWebsite())
                .append("</p>")
                .append("<p style='margin-top: 2rem; margin-right: 0; margin-bottom: 5rem; margin-left: 24rem;'>")
                .append(hotelbooking.getHotelLocation()).append(", ")
                .append(LocalDate.now().format(Common.CUSTOM_FORMATTER_GERMAN_SHORT)).append("</p>")
                .append("<p> Guten Tag ").append(guest.getFirstName() + " " + guest.getLastName() + ",</p>")
                .append("<p style='margin-top:1.75rem'>hiermit bestätigen wir die Stornierung Ihrer Übernachtungen vom ")
                .append(hotelbooking.getStartDate()).append(" bis ").append(hotelbooking.getEndDate())
                .append("</p>").append("<p> in dem Hotelzimmer ").append(hotelbooking.getRoomName())
                .append(" - (").append(hotelbooking.getRoomTitle()).append(")</p>")
                .append("<p> in der Unterkunft '").append(hotelbooking.getHotelName()).append("' - (")
                .append(hotelbooking.getHotelTitle()).append(")</p>").append("<p>in unserer wunderschönen Region ")
                .append(hotelbooking.getRegionTitle()).append(".</p>")
                .append("<p style='margin-top:2rem'>Der beglichene Rechnungsbetrag über ")
                .append(hotelbooking.getFormattedTotalcost()).append(" wird zeitnah Ihrem Konto gutgeschrieben.</p>")
                .append("<p style='margin-top: 4rem'>Mit besten Grüßen</p>")
                .append("<p style='margin-top: 1.5rem'>Ihre Hotelleitung ").append(hotelbooking.getHotelName())
                .append("</p><p>").append(hotelbooking.getHotelZipcode()).append(" ")
                .append(hotelbooking.getHotelLocation()).append("</p>")
                .append(".</div");

        mailSendService.setMessageBodyHtml(sbMessageBody.toString());

        mailSendService.sendEMail();
    }


    public void displayBookingDetails() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(Common.alertMessage.getProperty("underConstructionTitle"));
        alert.setHeaderText(null);
        alert.setContentText(Common.alertMessage.getProperty("informationUnderConstruction"));
        alert.showAndWait();
   }
}

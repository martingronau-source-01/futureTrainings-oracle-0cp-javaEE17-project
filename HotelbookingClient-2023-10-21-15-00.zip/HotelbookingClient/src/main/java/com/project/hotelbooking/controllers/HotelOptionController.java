package com.project.hotelbooking.controllers;

import com.project.hotelbooking.Main;
import com.project.hotelbooking.datamodels.restapi.models.CheckBoxLookup;
import com.project.hotelbooking.datamodels.restapi.models.Hotel;
import com.project.hotelbooking.datamodels.restapi.models.HotelOption;
import com.project.hotelbooking.datamodels.restapi.models.Lookup;
import com.project.hotelbooking.services.HotelOptionService;
import com.project.hotelbooking.services.HotelService;
import com.project.hotelbooking.utils.Common;
import javafx.beans.InvalidationListener;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.control.cell.CheckBoxListCell;
import javafx.scene.layout.BorderPane;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class HotelOptionController {

    @FXML
    private Accordion accordion;
    HotelOptionService hotelOptionService;
    HotelService hotelService;


    @FXML
    private BorderPane hotelOptionsPanel;
    @FXML
    private TableView<HotelOption> hotelOptionsTable;
    private ObservableList<Lookup> listHotels;
    @FXML
    private TextField fldName;
    @FXML
    private TextField fldTitle;
    @FXML
    private TextArea fldDescription;
    @FXML
    private ListView<CheckBoxLookup> listviewHotels;
    @FXML
    private TitledPane fldHotels;
    private ObservableList<CheckBoxLookup> hotels;
    private int currentHotelOptionId;

    public void initialize() {
        hotelOptionService = new HotelOptionService();
        hotelService = new HotelService();

        hotels = FXCollections.observableArrayList();

        if (hotelOptionsTable != null) {
            hotelOptionsTable.setItems(hotelOptionService.getHotelOptions());
        } else {
            listviewHotels.setCellFactory(factory -> {
                CheckBoxListCell<CheckBoxLookup> cell = new CheckBoxListCell<CheckBoxLookup>() {
                    // a listener on the graphicProperty: it installs the "real" listener
                    final InvalidationListener graphicListener = g -> {
                        // installs the "real" listener on the graphic control once it is available
                        registerUIListener();
                    };

                    {
                        // install the graphic listener at instantiation
                        graphicProperty().addListener(graphicListener);
                    }

                    private void registerUIListener() {
                        if (!(getGraphic() instanceof CheckBox)) throw new IllegalStateException("checkBox expected");
                        graphicProperty().removeListener(graphicListener);
                        ((CheckBox) getGraphic()).selectedProperty().addListener(
                                (observable, oldValue, newValue) -> listviewHotels.getSelectionModel().select(getItem()));
                    }
                };
                cell.setSelectedStateCallback(CheckBoxLookup::selectedProperty);
                return cell;
            });

            for (Hotel hotel : hotelService.getHotels()) {
                hotels.add( new CheckBoxLookup(hotel.getName(), false, hotel.getId()));
            }
            listviewHotels.setItems(hotels);
            accordion.setExpandedPane(fldHotels);

            fldName.requestFocus();
        }

    }

    @FXML
    public void showAddHotelOptionDialog() throws URISyntaxException {
        Dialog<ButtonType> dialog = new Dialog<ButtonType>();
        dialog.initOwner(hotelOptionsPanel.getScene().getWindow());
        dialog.setTitle("Hotel-Option hinzufügen");
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(Main.class.getResource("forms/hoteloptiondialog.fxml"));
        try {
            dialog.getDialogPane().setContent(fxmlLoader.load());

        } catch (IOException e) {
            System.out.println("Couldn't load the dialog");
            e.printStackTrace();
            return;
        }

        dialog.getDialogPane().getButtonTypes().add(ButtonType.OK);
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CANCEL);

        HotelOptionController hotelOptionController = fxmlLoader.getController();
        final Button okButton = (Button) dialog.getDialogPane().lookupButton(ButtonType.OK);
        okButton.addEventFilter(ActionEvent.ACTION, ae -> {
            if (!hotelOptionController.isValidHotelOption()) {
                ae.consume(); //not valid
            }
        });

        Optional<ButtonType> result = dialog.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            HotelOption newHotelOption = hotelOptionController.getNewHotelOption();
            currentHotelOptionId = hotelOptionService.insertHotelOption(newHotelOption);
            hotelOptionsTable.setItems(hotelOptionService.getHotelOptions());
        }
    }

    public HotelOption getNewHotelOption() {
        String name = fldName.getText();
        String title = fldTitle.getText();
        String description = fldDescription.getText();

        HotelOption hotelOption =  new HotelOption( name, title, description, Common.CREATOR,
                Common.CREATED, true);

        List<Integer> selectedHotelIds = new ArrayList<>();
        for(CheckBoxLookup item :  listviewHotels.getItems()) {
            if(item.isSelected())    {
                selectedHotelIds.add(item.getId());
            }
        }
        hotelOption.setHotelIds(selectedHotelIds);

        return hotelOption;
    }

    public void editHotelOption(HotelOption hotelOption) {
        fldName.setText(hotelOption.getName());
        fldTitle.setText(hotelOption.getTitle());
        fldDescription.setText(hotelOption.getDescription());

        ObservableList<Hotel> hotelsList = hotelService.getHotelsByHotelOption(hotelOption.getOptionId());

        for (CheckBoxLookup lookup : listviewHotels.getItems()) {
            lookup.setSelected(hotelsList.stream().anyMatch(h -> h.getId() == lookup.getId()));
        }

    }

    public boolean isValidHotelOption() {
        boolean bReturn = true;
        Common.isWarningMessage = true;

        if (fldName.getText().isEmpty()) {
            Common.showValidationMessage("Das Feld Name  darf nicht leer bleiben");
            bReturn = false;
            fldName.requestFocus();
        } else if (fldTitle.getText().isEmpty()) {
            Common.showValidationMessage("Das Feld Titel  darf nicht leer bleiben");
            bReturn = false;
            fldTitle.requestFocus();
        }

        return bReturn;
    }

    public void updateHotelOption(HotelOption hotelOption) {
        hotelOption.setName(fldName.getText());
        hotelOption.setTitle(fldTitle.getText());
        hotelOption.setDescription(fldDescription.getText());

        List<Integer> selectedHotelIds = new ArrayList<>();
        for(CheckBoxLookup item :  listviewHotels.getItems()) {
            if(item.isSelected())    {
                selectedHotelIds.add(item.getId());
            }
        }
        hotelOption.setHotelIds(selectedHotelIds);
    }

    @FXML
    public void showEditHotelOptionDialog() throws URISyntaxException {
        HotelOption selectedHotelOption = hotelOptionsTable.getSelectionModel().getSelectedItem();
        if (selectedHotelOption == null) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle(Common.alertMessage.getProperty("confirmHotelOptionTitle"));
            alert.setHeaderText(null);
            alert.setContentText(Common.alertMessage.getProperty("confirmEditHotelOption"));
            alert.showAndWait();
            return;
        }

        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.initOwner(hotelOptionsPanel.getScene().getWindow());
        dialog.setTitle("Edit Hotel Oṕtion");
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(Main.class.getResource("forms/hoteloptiondialog.fxml"));
        try {
            dialog.getDialogPane().setContent(fxmlLoader.load());
        } catch (IOException e) {
            System.out.println("Couldn't load the dialog");
            e.printStackTrace();
            return;
        }

        dialog.getDialogPane().getButtonTypes().add(ButtonType.OK);
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CANCEL);

        HotelOptionController hotelOptionController = fxmlLoader.getController();
        hotelOptionController.editHotelOption(selectedHotelOption);

        final Button okButton = (Button) dialog.getDialogPane().lookupButton(ButtonType.OK);
        okButton.addEventFilter(ActionEvent.ACTION, ae -> {
            if (!hotelOptionController.isValidHotelOption()) {
                ae.consume(); //not valid
            }
        });

        Optional<ButtonType> result = dialog.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            hotelOptionController.updateHotelOption(selectedHotelOption);
            currentHotelOptionId = hotelOptionService.updateHotelOption(
                   selectedHotelOption.getOptionType(),selectedHotelOption.getOptionId(), selectedHotelOption);
            hotelOptionsTable.setItems(hotelOptionService.getHotelOptions());
            hotelOptionsTable.refresh();
        }

    }

    @FXML
    public void deleteHotelOption() throws URISyntaxException {
        HotelOption selectedHotelOption = hotelOptionsTable.getSelectionModel().getSelectedItem();
        if (selectedHotelOption == null) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle(Common.alertMessage.getProperty("confirmHotelOptionTitle"));
            alert.setHeaderText(null);
            alert.setContentText(Common.alertMessage.getProperty("confirmDeleteHotelOption"));
            alert.showAndWait();
            return;
        }

        Alert alert = new Alert(Alert.AlertType.NONE,
                "Möchten Sie die HotelOption '"+selectedHotelOption.getTitle()+"' wirklich löschen?",
                Common.YES, Common.NO);

        alert.setTitle("Lösch-Bestätigung!");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.orElse(Common.NO) == Common.YES) {
            hotelOptionService.deleteHotelOption(selectedHotelOption.getOptionType(), selectedHotelOption.getOptionId());
            hotelOptionsTable.setItems(hotelOptionService.getHotelOptions());
            hotelOptionsTable.refresh();
        }
    }
}

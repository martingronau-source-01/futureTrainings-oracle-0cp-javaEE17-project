package com.project.hotelbooking.controllers;

import com.project.hotelbooking.components.LookupCell;
import com.project.hotelbooking.datamodels.restapi.models.*;
import com.project.hotelbooking.services.HotelOptionService;
import com.project.hotelbooking.services.RegionService;
import com.project.hotelbooking.services.RoomFeatureService;
import com.project.hotelbooking.services.SearchAccommodationService;
import com.project.hotelbooking.utils.Common;
import javafx.beans.InvalidationListener;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.control.cell.CheckBoxListCell;
import javafx.scene.layout.GridPane;
import lombok.Getter;

import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class ExtendedSearchController implements Initializable {
    @FXML
    private GridPane extendedSearchOptionsPanel;
    private HotelOptionService hotelOptionService;
    private RoomFeatureService roomFeatureService;

    @FXML
    private ListView<CheckBoxLookup> listviewHotelOptions;
    private ObservableList<CheckBoxLookup> hotelOptions;
    @FXML
    private ListView<CheckBoxLookup> listviewRoomFeatures;
    private ObservableList<CheckBoxLookup> roomFeatures;

    @FXML
    private ComboBox<Lookup> fldRegion;

    @FXML
    private DatePicker fldStartDate;

    @FXML
    private DatePicker fldEndDate;

    @FXML
    private Spinner<Integer> fldCountRooms;
    @FXML
    private Spinner<Integer> fldCountBeds;
    private ObservableList<Lookup> listRegions;

    private SearchAccommodationService searchAccommodationService;

    private   List<Integer> selectedHotelOptionsIds;
    private List<Integer> selectedRoomFeaturesIds;
    private List<String> choosenHotelOptionList;
    @Getter
    private String sChoosenHotelOptions = "";
    private List<String> choosenRoomFeatureList;
    @Getter
    private String sChoosenRoomFeatures = "";

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        choosenHotelOptionList = new ArrayList<>();
        choosenRoomFeatureList = new ArrayList<>();

        listRegions = FXCollections.observableArrayList();
        RegionService regionService = new RegionService();

        for (Region region : regionService.getRegions()) {
            listRegions.add(new Lookup(region.getId(), region.getTitle()));
        }
        fldRegion.setCellFactory(lookups -> new LookupCell());
        fldRegion.setButtonCell(new LookupCell());
        fldRegion.setItems(listRegions);
        fldRegion.setValue(listRegions.get(0));

        fldStartDate.setValue(LocalDate.now().plusDays(1));
        fldEndDate.setValue(LocalDate.now().plusMonths(1));

        extendedSearchOptionsPanel.setPadding(new Insets(10, 20, 10, 20));

        hotelOptionService = new HotelOptionService();
        hotelOptions = FXCollections.observableArrayList();

        roomFeatureService = new RoomFeatureService();
        roomFeatures = FXCollections.observableArrayList();
    }

    private void showExtendedSearchHotelOptions() {
        try {
            listviewHotelOptions.setCellFactory(factory -> {
                CheckBoxListCell<CheckBoxLookup> cell = new CheckBoxListCell<CheckBoxLookup>() {
                    final InvalidationListener graphicListener = g -> {
                        // installs the "real" listener on the graphic control once it is available
                        registerUIListener();
                    };

                    {
                        // install the graphic listener at instantiation
                        graphicProperty().addListener(graphicListener);
                    }                    // a listener on the graphicProperty: it installs the "real" listener

                    private void registerUIListener() {
                        if (!(getGraphic() instanceof CheckBox)) throw new IllegalStateException("checkBox expected");
                        graphicProperty().removeListener(graphicListener);
                        ((CheckBox) getGraphic()).selectedProperty().addListener(
                                (observable, oldValue, newValue) -> listviewHotelOptions.getSelectionModel().select(getItem()));
                    }


                };
                cell.setSelectedStateCallback(CheckBoxLookup::selectedProperty);
                return cell;
            });

            for (HotelOption hotelOption : hotelOptionService.getHotelOptions()) {
                hotelOptions.add(new CheckBoxLookup(hotelOption.getTitle(), hotelOption.isApproval(), hotelOption.getOptionId()));
            }
            listviewHotelOptions.setItems(hotelOptions);

            if(SearchController.selectedHotelOptionIds != null) {
                for (CheckBoxLookup lookup : listviewHotelOptions.getItems()) {
                    lookup.setSelected(SearchController.selectedHotelOptionIds.stream().anyMatch(h -> h == lookup.getId()));
                }
            }

        } catch (ClassCastException | NullPointerException e) {
            throw new RuntimeException(e);
        }

    }

    private void showExtendedSearchRoomFeatures() {

        try {
            listviewRoomFeatures.setCellFactory(factory -> {
                CheckBoxListCell<CheckBoxLookup> cell = new CheckBoxListCell<CheckBoxLookup>() {
                    final InvalidationListener graphicListener = g -> {
                        // installs the "real" listener on the graphic control once it is available
                        registerUIListener();
                    };

                    {
                        // install the graphic listener at instantiation
                        graphicProperty().addListener(graphicListener);
                    }                    // a listener on the graphicProperty: it installs the "real" listener

                    private void registerUIListener() {
                        if (!(getGraphic() instanceof CheckBox)) throw new IllegalStateException("checkBox expected");
                        graphicProperty().removeListener(graphicListener);
                        ((CheckBox) getGraphic()).selectedProperty().addListener(
                                (observable, oldValue, newValue) -> listviewRoomFeatures.getSelectionModel().select(getItem()));
                    }


                };
                cell.setSelectedStateCallback(CheckBoxLookup::selectedProperty);
                return cell;
            });

            for (RoomFeature roomFeature : roomFeatureService.getRoomFeatures()) {
                roomFeatures.add(new CheckBoxLookup(roomFeature.getTitle(), roomFeature.isApproval(), roomFeature.getOptionId()));
            }
            listviewRoomFeatures.setItems(roomFeatures);

            if(SearchController.selectedRoomFeatureIds != null) {
                for (CheckBoxLookup lookup : listviewRoomFeatures.getItems()) {
                    lookup.setSelected(SearchController.selectedRoomFeatureIds.stream().anyMatch(h -> h == lookup.getId()));
                }
            }

        } catch (ClassCastException | NullPointerException e) {
            throw new RuntimeException(e);
        }

    }

    public void showExtendedSearchDetails(Lookup region, LocalDate startDate, LocalDate endDate,
                                          Integer countRooms, Integer countBeds) {

        fldRegion.setValue(region);
        fldStartDate.setValue(startDate);
        fldEndDate.setValue(endDate);
        fldCountRooms.getValueFactory().setValue(countRooms);
        fldCountBeds.getValueFactory().setValue(countBeds);

        showExtendedSearchHotelOptions();
        // ---------------------------------------
        showExtendedSearchRoomFeatures();
    }

    public ObservableList<AccommodationSearchResult> searchAccommodationsExtended() {
            selectedHotelOptionsIds = new ArrayList<>();
            for (CheckBoxLookup item : listviewHotelOptions.getItems()) {
                if (item.isSelected()) {
                    selectedHotelOptionsIds.add(item.getId());
                    choosenHotelOptionList.add(item.getName());
                }
            }

            selectedRoomFeaturesIds = new ArrayList<>();
            for (CheckBoxLookup item : listviewRoomFeatures.getItems()) {
                if (item.isSelected()) {
                    selectedRoomFeaturesIds.add(item.getId());
                    choosenRoomFeatureList.add(item.getName());
                }
            }

            //---------------------store Option selection for next dialog call on extended search
            SearchController.selectedHotelOptionIds = selectedHotelOptionsIds;
            SearchController.selectedRoomFeatureIds = selectedRoomFeaturesIds;

            sChoosenHotelOptions = !choosenHotelOptionList.isEmpty() ? choosenHotelOptionList.stream().reduce((x, y) -> x + "," + y).get() : "";
            sChoosenRoomFeatures = !choosenRoomFeatureList.isEmpty() ? choosenRoomFeatureList.stream().reduce((x, y) -> x + "," + y).get() : "";

            searchAccommodationService = new SearchAccommodationService();
            return searchAccommodationService.getSearchAccommodationsExtended(fldRegion.getValue().getTitle(),
                    fldStartDate.getValue().toString(), fldEndDate.getValue().toString(),
                    fldCountRooms.getValue(), fldCountBeds.getValue(), selectedHotelOptionsIds, selectedRoomFeaturesIds);
    }

    public StandardSearchParams getStandardSearchParams() {
        return new StandardSearchParams(
                fldStartDate.getValue(), fldEndDate.getValue(),fldRegion.getValue(), fldCountRooms.getValue(),
                fldCountBeds.getValue());
    }

    public  boolean isValidSearchAccommodations() {
        boolean bReturn = true;
        Common.isWarningMessage = true;

        try {
            if (fldStartDate.getValue() == null) {
                Common.showValidationMessage("Das Feld StartDatum  darf nicht leer bleiben");
                bReturn = false;
                fldStartDate.requestFocus();
            } else if (fldEndDate.getValue() == null) {
                Common.showValidationMessage("Das Feld EndDatum  darf nicht leer bleiben");
                bReturn = false;
                fldEndDate.requestFocus();
            } else if (fldEndDate.getValue().isBefore(fldStartDate.getValue())) {
                Common.showValidationMessage("Das Feld EndDatum  darf nicht vor dem StartDatum liegen");
                bReturn = false;
                fldEndDate.requestFocus();
            } else if (fldEndDate.getValue().isEqual(fldStartDate.getValue())) {
                Common.showValidationMessage("Die Felder StartDatum und EndDatum dürfen nicht identisch sein.");
                bReturn = false;
                fldStartDate.requestFocus();
            } else if(fldCountRooms.getValue() < 1) {
                Common.showValidationMessage("Die Anzahl der Zimmer darf nicht 0 sein.");
                bReturn = false;
                fldCountRooms.requestFocus();
            } else if( fldCountBeds.getValue() < 1 ) {
                Common.showValidationMessage("Die Anzahl der Betten darf nicht 0 sein.");
                bReturn = false;
                fldCountBeds.requestFocus();
            } else if(fldCountBeds.getValue() < fldCountRooms.getValue() ) {
                Common.showValidationMessage("Die Anzahl der Betten darf nicht kleiner als die Anzahl der Zimmer sein.");
                bReturn = false;
                fldCountRooms.requestFocus();
            }
            return bReturn;
        } catch(NumberFormatException | NullPointerException e) {
            System.out.println("Exception - Reason: "+e.getMessage());
            return  false;
        }
    }

}

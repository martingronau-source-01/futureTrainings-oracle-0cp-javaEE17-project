package com.project.hotelbooking.datamodels.restapi.models;

import java.util.Objects;

public class AccommodationSearchResult {

	private int hotelId = 0;
	private int regionId = 0;
	private String regionName = "";
	private String startDate = "";
	private String endDate = "";
	private String regionTitle = "";
	private String regionDescription = "";
	private String hotelName = "";
	private String hotelTitle = "";
	private String hotelDescription = "";
	private String hotelStreet = "";
	private String hotelZipcode = "";
	private String hotelLocation = "";
	private String hotelEMail = "";
	private String hotelPhone = "";
	private String hotelWebsite = "";
	private int countRooms = 0;
	private int countBeds = 0;
	private int countAccommodations = 0;

	private String creator = "";
	private String created = "";
	private boolean hasData = false;

	public AccommodationSearchResult() {
		super();
	}

	public AccommodationSearchResult(int hotelId, String startDate, String endDate, String regionName, String regionTitle, 
			String regionDescription,String hotelName, String hotelTitle, String hotelDescription, String hotelStreet, 
			String hotelZipcode,String hotelLocation, String hotelEMail, String hotelPhone, String hotelWebsite, 
			int countRooms, int countBeds, int countAccommodations, int regionId, String creator, String created, boolean hasData) {
		super();
		this.hotelId = hotelId;
		this.startDate = startDate;
		this.endDate = endDate;
		this.regionName = regionName;
		this.regionTitle = regionTitle;
		this.regionDescription = regionDescription;
		this.hotelName = hotelName;
		this.hotelTitle = hotelTitle;
		this.hotelDescription = hotelDescription;
		this.hotelStreet = hotelStreet;
		this.hotelZipcode = hotelZipcode;
		this.hotelLocation = hotelLocation;
		this.hotelEMail = hotelEMail;
		this.hotelPhone = hotelPhone;
		this.hotelWebsite = hotelWebsite;
		this.countRooms = countRooms;
		this.countBeds = countBeds;
		this.countAccommodations = countAccommodations;
		this.regionId = regionId;
		this.creator = creator;
		this.created = created;
		this.hasData = hasData;
	}

	public int getHotelId() {
		return hotelId;
	}

	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}

	public String getRegionName() {
		return regionName;
	}

	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}

	public String getRegionTitle() {
		return regionTitle;
	}

	public void setRegionTitle(String regionTitle) {
		this.regionTitle = regionTitle;
	}

	public String getRegionDescription() {
		return regionDescription;
	}

	public void setRegionDescription(String regionDescription) {
		this.regionDescription = regionDescription;
	}

	public String getHotelName() {
		return hotelName;
	}

	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}

	public String getHotelTitle() {
		return hotelTitle;
	}

	public void setHotelTitle(String hotelTitle) {
		this.hotelTitle = hotelTitle;
	}

	public String getHotelDescription() {
		return hotelDescription;
	}

	public void setHotelDescription(String hotelDescription) {
		this.hotelDescription = hotelDescription;
	}

	public String getHotelStreet() {
		return hotelStreet;
	}

	public void setHotelStreet(String hotelStreet) {
		this.hotelStreet = hotelStreet;
	}

	public String getHotelZipcode() {
		return hotelZipcode;
	}

	public void setHotelZipcode(String hotelZipcode) {
		this.hotelZipcode = hotelZipcode;
	}

	public String getHotelLocation() {
		return hotelLocation;
	}

	public void setHotelLocation(String hotelLocation) {
		this.hotelLocation = hotelLocation;
	}

	public String getHotelEMail() {
		return hotelEMail;
	}

	public void setHotelEMail(String hotelEMail) {
		this.hotelEMail = hotelEMail;
	}

	public String getHotelPhone() {
		return hotelPhone;
	}

	public void setHotelPhone(String hotelPhone) {
		this.hotelPhone = hotelPhone;
	}

	public String getHotelWebsite() {
		return hotelWebsite;
	}

	public void setHotelWebsite(String hotelWebsite) {
		this.hotelWebsite = hotelWebsite;
	}

	public int getCountRooms() {
		return countRooms;
	}

	public void setCountRooms(int countRooms) {
		this.countRooms = countRooms;
	}

	public int getCountBeds() {
		return countBeds;
	}

	public void setCountBeds(int countBeds) {
		this.countBeds = countBeds;
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public String getCreated() {
		return created;
	}

	public void setCreated(String created) {
		this.created = created;
	}

	public boolean isHasData() {
		return hasData;
	}

	public void setHasData(boolean hasData) {
		this.hasData = hasData;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public int getCountAccommodations() {
		return countAccommodations;
	}

	public void setCountAccommodations(int countAccommodations) {
		this.countAccommodations = countAccommodations;
	}

	@Override
	public String toString() {
		return "AccommodationSearchResult [hotelId=" + hotelId + ", regionId=" + regionId + ", regionName=" + regionName
				+ ", startDate=" + startDate + ", endDate=" + endDate + ", regionTitle=" + regionTitle
				+ ", regionDescription=" + regionDescription + ", hotelName=" + hotelName + ", hotelTitle=" + hotelTitle
				+ ", hotelDescription=" + hotelDescription + ", hotelStreet=" + hotelStreet + ", hotelZipcode="
				+ hotelZipcode + ", hotelLocation=" + hotelLocation + ", hotelEMail=" + hotelEMail + ", hotelPhone="
				+ hotelPhone + ", hotelWebsite=" + hotelWebsite + ", countRooms=" + countRooms + ", countBeds="
				+ countBeds + ", countAccommodations=" + countAccommodations + ", creator=" + creator + ", created="
				+ created + ", hasData=" + hasData + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(countAccommodations, countBeds, countRooms, created, creator, endDate, hasData,
				hotelDescription, hotelEMail, hotelId, hotelLocation, hotelName, hotelPhone, hotelStreet, hotelTitle,
				hotelWebsite, hotelZipcode, regionDescription, regionId, regionName, regionTitle, startDate);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AccommodationSearchResult other = (AccommodationSearchResult) obj;
		return countAccommodations == other.countAccommodations && countBeds == other.countBeds
				&& countRooms == other.countRooms && Objects.equals(created, other.created)
				&& Objects.equals(creator, other.creator) && Objects.equals(endDate, other.endDate)
				&& hasData == other.hasData && Objects.equals(hotelDescription, other.hotelDescription)
				&& Objects.equals(hotelEMail, other.hotelEMail) && hotelId == other.hotelId
				&& Objects.equals(hotelLocation, other.hotelLocation) && Objects.equals(hotelName, other.hotelName)
				&& Objects.equals(hotelPhone, other.hotelPhone) && Objects.equals(hotelStreet, other.hotelStreet)
				&& Objects.equals(hotelTitle, other.hotelTitle) && Objects.equals(hotelWebsite, other.hotelWebsite)
				&& Objects.equals(hotelZipcode, other.hotelZipcode)
				&& Objects.equals(regionDescription, other.regionDescription) && regionId == other.regionId
				&& Objects.equals(regionName, other.regionName) && Objects.equals(regionTitle, other.regionTitle)
				&& Objects.equals(startDate, other.startDate);
	}

	public int getRegionId() {
		return regionId;
	}

	public void setRegionId(int regionId) {
		this.regionId = regionId;
	}


}

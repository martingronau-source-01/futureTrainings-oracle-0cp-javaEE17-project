package com.project.hotelbooking.datamodels.restapi.models;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;

public class CheckBoxLookup {

    private final String name ;

    private final int Id;

    private final BooleanProperty selected = new SimpleBooleanProperty();

    public CheckBoxLookup(int id, String name) {
        this.name = name ;
        Id = id;
    }

    public String getName() {
        return this.name;
    }

    public int getId() { return this.Id; }

    public CheckBoxLookup(String name, Boolean selected, int id) {
        this.name = name ;
        Id = id;
        this.selected.set(selected);
    }


    public BooleanProperty selectedProperty() {
        return selected ;
    }

    public final boolean isSelected() {
        return selectedProperty().get();
    }

    public final void setSelected(boolean selected) {
        selectedProperty().set(selected);
    }

    @Override
    public String toString() {
        return getName();
    }
}



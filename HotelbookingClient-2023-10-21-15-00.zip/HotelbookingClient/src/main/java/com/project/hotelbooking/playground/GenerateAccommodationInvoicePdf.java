package com.project.hotelbooking.playground;

import com.itextpdf.kernel.color.Color;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfReader;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.border.Border;
import com.itextpdf.layout.border.DashedBorder;
import com.itextpdf.layout.border.SolidBorder;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.property.TextAlignment;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

public class GenerateAccommodationInvoicePdf {
    private  static  final String DELIMITER = "/";

    public static void main(String[] args) throws IOException {
        Path resourceDirectory = Paths.get("src", "main", "resources", "com", "project", "hotelbooking", "pdf");
        String sPdfPath = resourceDirectory.toFile().getAbsolutePath();

        String path = sPdfPath +DELIMITER+"Rechnung_"+ LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH-mm"))+".pdf";
        String srcPath = sPdfPath+DELIMITER+"Dokumentvorlage_HotelBooking.pdf";


        PdfReader pdfReader = new PdfReader(srcPath);
        PdfWriter pdfWriter = new PdfWriter(path);
        PdfDocument pdfDocument = new PdfDocument(pdfReader, pdfWriter);
      //  PdfDocument pdfDocument = new PdfDocument(pdfWriter);
        pdfDocument.setDefaultPageSize(PageSize.A4);
        Document document = new Document(pdfDocument);

        float threeCol = 190f;
        float twoCol=285f;
        float twoCol150=twoCol+150f;
        float[] twoColumnWidth = {twoCol150, twoCol};
        float[] fiveColumnWidth= {90, 90, 175, 90, 90};

        float[] fullwidth = {threeCol*3};

        Table table=new Table(twoColumnWidth);
        table.addCell(new Cell().add("Rechnung").setFontSize(18f).setBorder(Border.NO_BORDER).setBold());
        Table nestedTable = new Table(new float[]{twoCol/2, twoCol/2});
        nestedTable.addCell(getHeaderTextCell("Rechnung-Nr:"));
        nestedTable.addCell(getHeaderTextCellValue("4262626"));
        nestedTable.addCell(getHeaderTextCell("Rechnung-Datum:"));
        nestedTable.addCell(getHeaderTextCellValue(LocalDate.now().format(DateTimeFormatter.ofPattern("dd.MM.yyyy"))));

        table.addCell(new Cell().add(nestedTable).setBorder(Border.NO_BORDER));

        Border gb = new SolidBorder(Color.GRAY, 1f/2f);
        Table divider = new Table(fullwidth);
        divider.setBorder(gb);

        document.add(table.setMarginTop(45f).setMarginLeft(15f));
        document.add(divider);

        Table tableInformation = new Table(twoColumnWidth);
        tableInformation.addCell(getBillingAndShippingCell("BillingInformation"));
        tableInformation.addCell(getBillingAndShippingCell("ShippingInformation"));
        document.add(tableInformation.setMarginBottom(12f));

        Table tableBillingInformation = new Table(twoColumnWidth);
        tableBillingInformation.addCell(getCell10fLeft("Firma:", true));
        tableBillingInformation.addCell(getCell10fLeft("Name:", true));
        tableBillingInformation.addCell(getCell10fLeft("Coding Error", false));
        tableBillingInformation.addCell(getCell10fLeft("Coding", false));
        document.add(tableBillingInformation);


        Table tableShippingInformation = new Table(twoColumnWidth);
        tableShippingInformation.addCell(getCell10fLeft("Name:", true));
        tableShippingInformation.addCell(getCell10fLeft("Address:", true));
        tableShippingInformation.addCell(getCell10fLeft("Arlyn Puttergill", false));
        tableShippingInformation.addCell(getCell10fLeft("8570 Gulseth Terra, 3324 Eastwood\nSpringfi, Ma, 01114", false));
        document.add(tableShippingInformation);

        float[] oneColumnWidth = {twoCol150};
        Table tableBillingInformationAddress = new Table(oneColumnWidth);
        tableBillingInformationAddress.addCell(getCell10fLeft("Address:", true));
        tableBillingInformationAddress.addCell(getCell10fLeft("8570 Gulseth Terra, 3324 Eastwood\nSpringfi, Ma, 01114", false));
        tableBillingInformationAddress.addCell(getCell10fLeft("EMail:", true));
        tableBillingInformationAddress.addCell(getCell10fLeft("stern@example.com", false));
        document.add(tableBillingInformationAddress.setMarginBottom(10f));

        Table tableDivider2 = new Table(fullwidth);
        Border dgb = new DashedBorder(Color.GRAY, 0.5f);
        tableDivider2.setBorder(dgb);

        Table tablePositionDataHeader = new Table(fiveColumnWidth);
        tablePositionDataHeader.setBackgroundColor(Color.BLACK, 0.7f);

        tablePositionDataHeader.addCell(new Cell().add("Beginn").setBold().setFontColor(Color.WHITE).setBorder(Border.NO_BORDER).setTextAlignment(TextAlignment.CENTER));
        tablePositionDataHeader.addCell(new Cell().add("Ende").setBold().setFontColor(Color.WHITE).setBorder(Border.NO_BORDER).setTextAlignment(TextAlignment.CENTER));
        tablePositionDataHeader.addCell(new Cell().add("Beschreibung").setBold().setFontColor(Color.WHITE).setBorder(Border.NO_BORDER).setTextAlignment(TextAlignment.CENTER));
        tablePositionDataHeader.addCell(new Cell().add("Mwst").setBold().setFontColor(Color.WHITE).setBorder(Border.NO_BORDER).setTextAlignment(TextAlignment.RIGHT).setPaddingRight(15f));
        tablePositionDataHeader.addCell(new Cell().add("Kosten").setBold().setFontColor(Color.WHITE).setBorder(Border.NO_BORDER).setTextAlignment(TextAlignment.RIGHT).setPaddingRight(15f));
        document.add(tablePositionDataHeader.setMarginTop(10f));

        List<myAccommodation> accommodationList = new ArrayList<>();

        accommodationList.add(new myAccommodation("27.09.2023", "14.10.2023", "Hotel Seeblick - Zimmer: RX2 Exclusive-Room 2", 16.19f, 85.00f, 17));
        accommodationList.add(new myAccommodation("01.01.2023", "01.03.2023", "Hotel Seeblick - Zimmer: R2D2 Standard 1", 14.25f, 75.00f, 59));
        accommodationList.add(new myAccommodation("01.12.2023", "25.12.2023", "Hotel Seeblick - Zimmer: RX2 Exclusive-Room 1", 16.19f, 85.00f, 24));
        accommodationList.add(new myAccommodation("13.10.2023", "27.10.2023", "Hotel Seeblick - Zimmer: RX2 Seaside Room 3", 16.19f, 85.00f,14));
        accommodationList.add(new myAccommodation("08.05.2023", "10.05.2023", "Hotel Seeblick - Zimmer: RX2 Luxus-Room 3", 16.19f, 85.00f,2));


        float totalSum = 0f;
        float totalMwst = 0f;
        Table tablePositionData = new Table(fiveColumnWidth);
        for(myAccommodation accommodation : accommodationList) {

            float cost = accommodation.getSinglePrice()*accommodation.getQuantity();
            float mwst = accommodation.getSingleMwst()*accommodation.getQuantity();

            tablePositionData.addCell(new Cell().add(accommodation.getStartDate()).setBorder(Border.NO_BORDER)).setTextAlignment(TextAlignment.CENTER).setMarginLeft(5f);
            tablePositionData.addCell(new Cell().add(accommodation.getEndDate()).setTextAlignment(TextAlignment.CENTER)
                    .setBorder(Border.NO_BORDER).setMarginLeft(5f));
            tablePositionData.addCell(new Cell().add(accommodation.getDescription())
                    .setBorder(Border.NO_BORDER).setMarginLeft(0.5f).setTextAlignment(TextAlignment.LEFT));
            tablePositionData.addCell(new Cell().add(DecimalFormat.getCurrencyInstance(Locale.GERMANY).format(mwst)).setTextAlignment(TextAlignment.RIGHT)
                    .setBorder(Border.NO_BORDER)).setMarginRight(5f);
            tablePositionData.addCell(new Cell().add(DecimalFormat.getCurrencyInstance(Locale.GERMANY).format(cost)).setTextAlignment(TextAlignment.RIGHT)
                    .setBorder(Border.NO_BORDER)).setMarginRight(5f);

            totalSum += cost;
            totalMwst += mwst;
        }
        document.add(tablePositionData.setMarginBottom(20f));

        float[] onetwo = {threeCol+125f, threeCol*2};
        Table threeColTable4 = new Table(onetwo);
        threeColTable4.addCell(new Cell().add("").setBorder(Border.NO_BORDER));
        threeColTable4.addCell(new Cell().add(tableDivider2).setBorder(Border.NO_BORDER));
        document.add(threeColTable4);

        Table tableSummary = new Table(fiveColumnWidth);
        tableSummary.addCell(new Cell().add("").setBorder(Border.NO_BORDER)).setMarginLeft(10f);
        tableSummary.addCell(new Cell().add("").setBorder(Border.NO_BORDER));
        tableSummary.addCell(new Cell().add("Summe:").setBold().setTextAlignment(TextAlignment.CENTER).setBorder(Border.NO_BORDER));
        tableSummary.addCell(new Cell().add(DecimalFormat.getCurrencyInstance(Locale.GERMANY).format(totalMwst)).setTextAlignment(TextAlignment.RIGHT).setBorder(Border.NO_BORDER).setMarginRight(15f));
        tableSummary.addCell(new Cell().add(DecimalFormat.getCurrencyInstance(Locale.GERMANY).format(totalSum)).setTextAlignment(TextAlignment.RIGHT).setBorder(Border.NO_BORDER).setMarginRight(15f));

        document.add(tableSummary);
        document.add(tableDivider2);
        Table tableTermsAndConditions = new Table(fullwidth);
        tableTermsAndConditions.addCell(new Cell().add("Geschäftsbedingungen\n").setBold().setBorder(Border.NO_BORDER));

        List<String> TncList=new ArrayList<>();
        TncList.add("1. Der Verkäufer haftet gegenüber dem Käufer weder direkt noch indirekt für Verluste oder Schäden, die dem Käufer entstehen.");
        TncList.add("2. Der Verkäufer gewährt auf das Produkt eine Garantie von zwei (1) Jahren ab Ausstellungsdatum");

        for(String tnc: TncList) {
            tableTermsAndConditions.addCell(new Cell().add(tnc).setBorder(Border.NO_BORDER).setFontSize(8f));
        }
       document.add(tableTermsAndConditions.setMarginLeft(30f).setMarginBottom(25f).setMarginTop(15f));

        document.close();
        System.out.println("Pdf generated");
    }

    static Cell getHeaderTextCell(String textValue) {
        return new Cell().add(textValue).setBold().setBorder(Border.NO_BORDER).setTextAlignment(TextAlignment.RIGHT);
    }
    static Cell getHeaderTextCellValue(String textValue) {
        return new Cell().add(textValue).setBorder(Border.NO_BORDER).setTextAlignment(TextAlignment.LEFT);
    }

    static Cell getBillingAndShippingCell(String textValue) {
        return new Cell().add(textValue).setFontSize(12f).setBold().setBorder(Border.NO_BORDER).setTextAlignment(TextAlignment.LEFT);
    }

    static Cell getCell10fLeft(String textValue, Boolean isBold) {
        Cell myCell = new Cell().add(textValue).setFontSize(10f).setBorder(Border.NO_BORDER).setTextAlignment(TextAlignment.LEFT);
        return isBold ? myCell.setBold():myCell;
    }
}


class  myAccommodation {
    private String startDate;

    public myAccommodation() {
    }

    @Override
    public String toString() {
        return "myAccommodation{" +
                "startDate='" + startDate + '\'' +
                ", endDate='" + endDate + '\'' +
                ", description='" + description + '\'' +
                ", quantity=" + quantity +
                ", singleMwst=" + singleMwst +
                ", singlePrice=" + singlePrice +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof myAccommodation that)) return false;
        return getQuantity() == that.getQuantity() && Float.compare(getSingleMwst(), that.getSingleMwst()) == 0 && Float.compare(getSinglePrice(), that.getSinglePrice()) == 0 && Objects.equals(getStartDate(), that.getStartDate()) && Objects.equals(getEndDate(), that.getEndDate()) && Objects.equals(getDescription(), that.getDescription());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getStartDate(), getEndDate(), getDescription(), getQuantity(), getSingleMwst(), getSinglePrice());
    }

    public myAccommodation(String startDate, String endDate, String description,
                           float singleMwst, float singlePrice, int quantity) {
        this.startDate = startDate;
        this.endDate = endDate;
        this.description = description;
        this.singleMwst = singleMwst;
        this.singlePrice = singlePrice;
        this.quantity = quantity;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public float getSingleMwst() {
        return singleMwst;
    }

    public void setSingleMwst(float singleMwst) {
        this.singleMwst = singleMwst;
    }

    public float getSinglePrice() {
        return singlePrice;
    }

    public void setSinglePrice(float singlePrice) {
        this.singlePrice = singlePrice;
    }

    private String endDate;

    private String description;

    private int quantity;

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    private float singleMwst;
    private float singlePrice;

}

package com.project.hotelbooking.components;

import javafx.scene.control.ListCell;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
public class RadioListCell extends ListCell<String> {

    private final ToggleGroup group;

    public RadioListCell() {
        super();
        this.group = new ToggleGroup();
    }

    public RadioListCell(ToggleGroup group) {
        this.group = group;
    }


    @Override
    public void updateItem(String obj, boolean empty) {
        super.updateItem(obj, empty);
        if (empty) {
            setText(null);
            setGraphic(null);
        } else {
            RadioButton radioButton = new RadioButton(obj);
            radioButton.setToggleGroup(group);
            // Add Listeners if any

            setGraphic(radioButton);
        }
    }
}

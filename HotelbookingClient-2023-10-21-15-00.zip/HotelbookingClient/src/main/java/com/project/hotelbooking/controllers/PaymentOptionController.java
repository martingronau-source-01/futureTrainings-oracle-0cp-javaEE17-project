package com.project.hotelbooking.controllers;

import com.project.hotelbooking.Main;
import com.project.hotelbooking.datamodels.restapi.models.CheckBoxLookup;
import com.project.hotelbooking.datamodels.restapi.models.Lookup;
import com.project.hotelbooking.datamodels.restapi.models.Payment;
import com.project.hotelbooking.datamodels.restapi.models.PaymentOption;
import com.project.hotelbooking.services.PaymentOptionService;
import com.project.hotelbooking.services.PaymentService;
import com.project.hotelbooking.utils.Common;
import javafx.beans.InvalidationListener;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.control.cell.CheckBoxListCell;
import javafx.scene.layout.BorderPane;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class PaymentOptionController {
    @FXML
    private Accordion accordion;
    @FXML
    private BorderPane paymentOptionsPanel;
    @FXML
    private TableView<PaymentOption> paymentOptionsTable;
    private ObservableList<Lookup> listPayments;
    @FXML
    private TextField fldName;
    @FXML
    private TextField fldTitle;
    @FXML
    private TextArea fldDescription;
    PaymentOptionService paymentOptionService;
    PaymentService paymentService;
    @FXML
    private ListView<CheckBoxLookup> listviewPayments;
    @FXML
    private TitledPane fldPayments;
    private ObservableList<CheckBoxLookup> payments;
    private int currentPaymentOptionId;

    public void initialize() {
        paymentOptionService = new PaymentOptionService();
        paymentService = new PaymentService();

        payments = FXCollections.observableArrayList();

        if(paymentOptionsTable != null) {
            paymentOptionsTable.setItems(paymentOptionService.getPaymentOptions());
        } else {
            listPayments = FXCollections.observableArrayList();
            PaymentService paymentService = new PaymentService();

            for (Payment payment : paymentService.getPayments()) {
                listPayments.add(new Lookup(payment.getId(), payment.getName()));
            }

            listPayments = FXCollections.observableArrayList();

            for(Payment payment : paymentService.getPayments()) {
                listPayments.add(new Lookup(payment.getId(), payment.getName()));
            }
            listviewPayments.setCellFactory(factory -> {
                CheckBoxListCell<CheckBoxLookup> cell = new CheckBoxListCell<CheckBoxLookup>() {
                    // a listener on the graphicProperty: it installs the "real" listener
                    final InvalidationListener graphicListener = g -> {
                        // installs the "real" listener on the graphic control once it is available
                        registerUIListener();
                    };

                    {
                        // install the graphic listener at instantiation
                        graphicProperty().addListener(graphicListener);
                    }

                    private void registerUIListener() {
                        if (!(getGraphic() instanceof CheckBox)) throw new IllegalStateException("checkBox expected");
                        graphicProperty().removeListener(graphicListener);
                        ((CheckBox) getGraphic()).selectedProperty().addListener(
                                (observable, oldValue, newValue) -> listviewPayments.getSelectionModel().select(getItem()));
                    }
                };
                cell.setSelectedStateCallback(CheckBoxLookup::selectedProperty);
                return cell;
            });

            for (Payment payment : paymentService.getPayments()) {
                payments.add( new CheckBoxLookup(payment.getName(), false, payment.getId()));
            }
            listviewPayments.setItems(payments);
            accordion.setExpandedPane(fldPayments);

            fldName.requestFocus();
        }

    }

    @FXML
    public void showAddPaymentOptionDialog() throws URISyntaxException {
        Dialog<ButtonType> dialog = new Dialog<ButtonType>();
        dialog.initOwner(paymentOptionsPanel.getScene().getWindow());
        dialog.setTitle("Bezahlungs-Option hinzufügen");
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(Main.class.getResource("forms/paymentoptiondialog.fxml"));
        try {
            dialog.getDialogPane().setContent(fxmlLoader.load());

        } catch (IOException e) {
            System.out.println("Couldn't load the dialog");
            e.printStackTrace();
            return;
        }

        dialog.getDialogPane().getButtonTypes().add(ButtonType.OK);
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CANCEL);

        PaymentOptionController paymentOptionController = fxmlLoader.getController();
        final Button okButton = (Button) dialog.getDialogPane().lookupButton(ButtonType.OK);
        okButton.addEventFilter(ActionEvent.ACTION, ae -> {
            if (!paymentOptionController.isValidPaymentOption()) {
                ae.consume(); //not valid
            }
        });

        Optional<ButtonType> result = dialog.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            PaymentOption newPaymentOption = paymentOptionController.getNewPaymentOption();
            currentPaymentOptionId = paymentOptionService.insertPaymentOption(newPaymentOption);
            paymentOptionsTable.setItems(paymentOptionService.getPaymentOptions());
        }
    }

    public PaymentOption getNewPaymentOption() {
        String name = fldName.getText();
        String title = fldTitle.getText();
        String description = fldDescription.getText();

        PaymentOption paymentOption =  new PaymentOption(0, name, title, description, Common.CREATOR,
                Common.CREATED, true);

        List<Integer> selectedPaymentIds = new ArrayList<>();
        for(CheckBoxLookup item :  listviewPayments.getItems()) {
            if(item.isSelected())    {
                selectedPaymentIds.add(item.getId());
            }
        }
        paymentOption.setPaymentIds(selectedPaymentIds);

        return paymentOption;
    }

    public void editPaymentOption(PaymentOption paymentOption) {
        fldName.setText(paymentOption.getName());
        fldTitle.setText(paymentOption.getTitle());
        fldDescription.setText(paymentOption.getDescription());

        ObservableList<Payment> paymentsList = paymentService.getPaymentsByPaymentOption(paymentOption.getOptionId());

        for (CheckBoxLookup lookup : listviewPayments.getItems()) {
            lookup.setSelected(paymentsList.stream().anyMatch(h -> h.getId() == lookup.getId()));
        }
    }

    public void updatePaymentOption(PaymentOption paymentOption) {
        paymentOption.setName(fldName.getText());
        paymentOption.setTitle(fldTitle.getText());
        paymentOption.setDescription(fldDescription.getText());

        List<Integer> selectedPaymentIds = new ArrayList<>();
        for(CheckBoxLookup item :  listviewPayments.getItems()) {
            if(item.isSelected())    {
                selectedPaymentIds.add(item.getId());
            }
        }
        paymentOption.setPaymentIds(selectedPaymentIds);
    }

    @FXML
    public void showEditPaymentOptionDialog() throws URISyntaxException {
        PaymentOption selectedPaymentOption = paymentOptionsTable.getSelectionModel().getSelectedItem();
        if (selectedPaymentOption == null) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle(Common.alertMessage.getProperty("confirmPaymentOptionTitle"));
            alert.setHeaderText(null);
            alert.setContentText(Common.alertMessage.getProperty("confirmEditPaymentOption"));
            alert.showAndWait();
            return;
        }

        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.initOwner(paymentOptionsPanel.getScene().getWindow());
        dialog.setTitle("Bezahlungs-Optionen");
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(Main.class.getResource("forms/paymentoptiondialog.fxml"));
        try {
            dialog.getDialogPane().setContent(fxmlLoader.load());
        } catch (IOException e) {
            System.out.println("Couldn't load the dialog");
            e.printStackTrace();
            return;
        }

        dialog.getDialogPane().getButtonTypes().add(ButtonType.OK);
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CANCEL);

        PaymentOptionController paymentOptionController = fxmlLoader.getController();
        paymentOptionController.editPaymentOption(selectedPaymentOption);

        final Button okButton = (Button) dialog.getDialogPane().lookupButton(ButtonType.OK);
        okButton.addEventFilter(ActionEvent.ACTION, ae -> {
            if (!paymentOptionController.isValidPaymentOption()) {
                ae.consume(); //not valid
            }
        });

        Optional<ButtonType> result = dialog.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {

            paymentOptionController.updatePaymentOption(selectedPaymentOption);
            currentPaymentOptionId = paymentOptionService.updatePaymentOption(
                    selectedPaymentOption.getOptionType(), selectedPaymentOption.getOptionId(), selectedPaymentOption);
            paymentOptionsTable.setItems(paymentOptionService.getPaymentOptions());
            paymentOptionsTable.refresh();
        }

    }

    public boolean isValidPaymentOption() {
        boolean bReturn = true;
        Common.isWarningMessage = true;

        if (fldName.getText().isEmpty()) {
            Common.showValidationMessage("Das Feld Name  darf nicht leer bleiben");
            bReturn = false;
            fldName.requestFocus();
        } else if (fldTitle.getText().isEmpty()) {
            Common.showValidationMessage("Das Feld Titel  darf nicht leer bleiben");
            bReturn = false;
            fldTitle.requestFocus();
        }

        return bReturn;
    }

    @FXML
    public void deletePaymentOption() throws URISyntaxException {
        PaymentOption selectedPaymentOption = paymentOptionsTable.getSelectionModel().getSelectedItem();
        if (selectedPaymentOption == null) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle(Common.alertMessage.getProperty("confirmPaymentOptionTitle"));
            alert.setHeaderText(null);
            alert.setContentText(Common.alertMessage.getProperty("confirmDeletePaymentOption"));
            alert.showAndWait();
            return;
        }

        Alert alert = new Alert(Alert.AlertType.NONE,
                "Möchten Sie das Zimmer Feature '"+selectedPaymentOption.getTitle()+"' wirklich löschen?",
                Common.YES, Common.NO);

        alert.setTitle("Lösch-Bestätigung!");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.orElse(Common.NO) == Common.YES) {
            paymentOptionService.deletePaymentOption(selectedPaymentOption.getOptionType(), selectedPaymentOption.getOptionId());
            paymentOptionsTable.setItems(paymentOptionService.getPaymentOptions());
            paymentOptionsTable.refresh();
        }
    }   
}

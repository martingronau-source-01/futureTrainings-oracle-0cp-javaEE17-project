package com.project.hotelbooking.playground.controllers.tabPanels;

import com.project.hotelbooking.components.LookupCell;
import com.project.hotelbooking.datamodels.restapi.models.Login;
import com.project.hotelbooking.datamodels.restapi.models.Lookup;
import com.project.hotelbooking.datamodels.restapi.models.Role;
import com.project.hotelbooking.services.RoleService;
import com.project.hotelbooking.utils.Common;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;

public class TabRegistrationLoginController {

    @FXML
    GridPane registrationLoginDataPanel;
    @FXML
    private ComboBox<Lookup> fldRole;
    private ObservableList<Lookup> listRoles;
    @FXML
    private TextField fldUsername;
    @FXML
    private TextField fldLoginname;
    @FXML
    private PasswordField fldPassword;
    @FXML
    private CheckBox fldRegistered;

    public void initialize() {
        registrationLoginDataPanel.setPadding(new Insets(30, 25, 15, 35));

        listRoles = FXCollections.observableArrayList();
        RoleService roleService = new RoleService();

        for (Role role : roleService.getRoles()) {
            listRoles.add(new Lookup(role.getId(), role.getDescription()));
        }
        fldRole.setCellFactory(lookups -> new LookupCell());
        fldRole.setButtonCell(new LookupCell());
        fldRole.setItems(listRoles);
        fldRole.setValue(listRoles.get(0));
    }

    public Login getNewLogin() {
        String username = fldUsername.getText();
        String loginName = fldLoginname.getText();
        String password = fldPassword.getText();
        Lookup role = fldRole.getSelectionModel().getSelectedItem();
     //   Lookup guest = fldGuest.getSelectionModel().getSelectedItem();
        boolean registered = fldRegistered.isSelected();

        int guestId = 0;

        String salt = "";
        String hash = "";
        boolean hasData = true;

        return new Login(username,loginName,password,salt,role.getId(),registered,
                guestId, Common.CREATOR, Common.CREATED, hasData);
    }
}

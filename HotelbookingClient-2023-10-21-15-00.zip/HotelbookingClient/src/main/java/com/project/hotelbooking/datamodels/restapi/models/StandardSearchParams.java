package com.project.hotelbooking.datamodels.restapi.models;

import java.time.LocalDate;

public record StandardSearchParams(LocalDate startDate, LocalDate endDate,
                                   Lookup region,
                                   Integer countRooms,
                                   Integer countBeds) {

}

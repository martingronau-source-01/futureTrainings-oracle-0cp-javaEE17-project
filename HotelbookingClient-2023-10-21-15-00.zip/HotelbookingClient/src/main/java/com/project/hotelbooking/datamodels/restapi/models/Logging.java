package com.project.hotelbooking.datamodels.restapi.models;

import java.util.Objects;

public class Logging {
	private int id = 0;
	private int loginId = 0;
	private int loggingType = 0;
	private String notification = "";
	private String description = "";
	private String creator = "";
	private String created = "";
	private boolean hasData = false;

	public Logging() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Logging(int id, int loginId, int loggingType, String notification, String description, String creator,
			String created, boolean hasData) {
		super();
		this.id = id;
		this.loginId = loginId;
		this.loggingType = loggingType;
		this.notification = notification;
		this.description = description;
		this.creator = creator;
		this.created = created;
		this.hasData = hasData;
	}

	@Override
	public int hashCode() {
		return Objects.hash(id, created, creator, description, hasData, loggingType, loginId, notification);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Logging other = (Logging) obj;
		return id == other.id && Objects.equals(created, other.created) && Objects.equals(creator, other.creator)
				&& Objects.equals(description, other.description) && hasData == other.hasData
				&& loggingType == other.loggingType && loginId == other.loginId
				&& Objects.equals(notification, other.notification);
	}

	@Override
	public String toString() {
		return "Logging [id=" + id + ", loginId=" + loginId + ", loggingType=" + loggingType + ", notification="
				+ notification + ", description=" + description + ", creator=" + creator + ", created=" + created
				+ ", hasData=" + hasData + "]";
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getLoginId() {
		return loginId;
	}

	public void setLoginId(int loginId) {
		this.loginId = loginId;
	}

	public int getLoggingType() {
		return loggingType;
	}

	public void setLoggingType(int loggingType) {
		this.loggingType = loggingType;
	}

	public String getNotification() {
		return notification;
	}

	public void setNotification(String notification) {
		this.notification = notification;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public String getCreated() {
		return created;
	}

	public void setCreated(String created) {
		this.created = created;
	}

	public boolean isHasData() {
		return hasData;
	}

	public void setHasData(boolean hasData) {
		this.hasData = hasData;
	}

}

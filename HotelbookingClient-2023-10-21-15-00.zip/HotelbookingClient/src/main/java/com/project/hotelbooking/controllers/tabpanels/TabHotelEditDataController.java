package com.project.hotelbooking.controllers.tabpanels;

import com.project.hotelbooking.components.LookupCell;
import com.project.hotelbooking.datamodels.restapi.models.Hotel;
import com.project.hotelbooking.datamodels.restapi.models.Lookup;
import com.project.hotelbooking.datamodels.restapi.models.Region;
import com.project.hotelbooking.services.HotelService;
import com.project.hotelbooking.services.RegionService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import lombok.Getter;

import java.net.URL;
import java.util.ResourceBundle;

public class TabHotelEditDataController  implements Initializable {
    @FXML
    private TextField fldName;
    @FXML
    private TextField fldTitle;
    @FXML
    private TextField fldStreet;
    @FXML
    private TextField fldZipcode;
    @FXML
    private TextField fldLocation;
    @FXML
    private TextArea fldDescription;
    @FXML
    private TextField fldEMail;
    @FXML
    private TextField fldPhone;
    @FXML
    private TextField fldWebsite;
    @FXML
    private ComboBox<Lookup> fldRegion;
    @FXML
    private GridPane hotelEditDataPanel;
    private HotelService hotelService;
    private int currentHotelId;

    @Getter
    private ObservableList<Lookup> listRegions;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        hotelService = new HotelService();

        listRegions = FXCollections.observableArrayList();
        RegionService regionService = new RegionService();

        hotelEditDataPanel.setPadding(new Insets(30, 25, 15, 35));

        for (Region region : regionService.getRegions()) {
            listRegions.add(new Lookup(region.getId(), region.getName()));
        }
        fldRegion.setCellFactory(lookups -> new LookupCell());
        fldRegion.setButtonCell(new LookupCell());
        fldRegion.setItems(listRegions);
        fldRegion.setValue(listRegions.get(0));

        fldName.setText("Martin");

        fldName.requestFocus();
    }

    public void editHotel(Hotel hotel) {
        fldName.setText(hotel.getName());
        fldTitle.setText(hotel.getTitle());
        fldStreet.setText(hotel.getStreet());
        fldZipcode.setText(hotel.getZipcode());
        fldLocation.setText(hotel.getLocation());
        fldEMail.setText(hotel.getEmail());
        fldPhone.setText(hotel.getPhone());
        fldWebsite.setText(hotel.getWebsite());
        fldDescription.setText(hotel.getDescription());

        for (Lookup lookup : fldRegion.getItems()) {
            if (lookup.getId() == hotel.getRegionId()) {
                fldRegion.setValue(lookup);
                return;
            }
        }
    }
}

package com.project.hotelbooking.controllers;

import com.project.hotelbooking.controllers.tabpanels.TabHotelEditDataController;
import com.project.hotelbooking.controllers.tabpanels.TabHotelOptionsEditController;
import com.project.hotelbooking.datamodels.restapi.models.Hotel;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.control.TabPane;

import java.net.URL;
import java.util.ResourceBundle;

public class HotelMainController implements Initializable  {

    @FXML
    private TabPane tabPaneHotelMain;
    @FXML
    private TabHotelEditDataController tabHotelEditDataController;
    @FXML
    private TabHotelOptionsEditController tabHotelOptionsEditController;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        tabPaneHotelMain.setPadding(new Insets(15, 25, 15, 25));
    }

    public void editHotel(Hotel hotel) {
        tabHotelEditDataController.editHotel(hotel);
        tabHotelOptionsEditController.editHotelOptionsByHotel(hotel.getId());
    }
}

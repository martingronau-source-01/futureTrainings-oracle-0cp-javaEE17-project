package com.project.hotelbooking.services;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.project.hotelbooking.datamodels.restapi.models.Login;
import com.project.hotelbooking.utils.SystemSecure;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.net.URISyntaxException;
import java.net.http.HttpResponse;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;

public class LoginService  extends RestApiService {
    private final String loginsURI;
    private final SystemSecure secureLogin;
    private final Gson gson;

    public LoginService() {
        super();
        secureLogin= new SystemSecure();
         gson= new Gson();

        SystemSecure systemSecure = new SystemSecure();

        String sBaseURI = systemSecure.getRestApiConnectionUri();
        loginsURI = sBaseURI+systemSecure.getDelimiter()+"logins"+systemSecure.getDelimiter();
    }

    public ObservableList<Login> getLogins() {
        HttpResponse<String> getResponse = this.sendGetRequest(loginsURI);

        List<Login> logins = gson.fromJson(getResponse.body(), new TypeToken<ArrayList<Login>>() {
        }.getType());

        return FXCollections.observableList(logins);
    }
    
    public boolean checkLogin(String loginname, String password) {

        SystemSecure systemSecure = new SystemSecure();
        Login login = getLoginByUsername(loginname);

        String saltedAndPepperedPassword = password + login.getSalt()+systemSecure.getPepperHash();
        String passwordHash = systemSecure.getHashString(saltedAndPepperedPassword);

        HttpResponse<String> getResponse = this.sendGetRequest(loginsURI + "check/"+loginname+"/"+passwordHash);

        return gson.fromJson(getResponse.body(), Boolean.class);
    }


    public Login getLoginByUsername(String username) {
        HttpResponse<String> getResponse = this.sendGetRequest(loginsURI + "data-by-username/"+username);

        return gson.fromJson(getResponse.body(), Login.class);
    }

    public int insertLogin(Login login)  throws URISyntaxException {

        try {
            if(secureLogin.getPepperHash().isEmpty()) {
                secureLogin.generatePepperHash();
            }

            String salt = secureLogin.getSalt();
            String hashedPassword = secureLogin.getHashedPassword(login.getPassword(), salt);

            login.setPassword(hashedPassword);
            login.setSalt(salt);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }

        String jsonRequest = gson.toJson(login);
        return this.sendPostRequest(loginsURI, jsonRequest);
    }

    public int updateLogin(int loginId, Login login) throws URISyntaxException {
        try {
            if(secureLogin.getPepperHash().isEmpty()) {
                secureLogin.generatePepperHash();
            }

            String salt = secureLogin.getSalt();
            String hashedPassword = secureLogin.getHashedPassword(login.getPassword(), salt);

            login.setPassword(hashedPassword);
            login.setSalt(salt);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }

        Gson gson = new Gson();
        String jsonRequest = gson.toJson(login);

        return this.sendPutRequest(loginsURI + loginId, jsonRequest);
    }

    public int deleteLogin(int loginId) throws URISyntaxException {
        return this.sendDeleteRequest(loginsURI + loginId);
    }
}

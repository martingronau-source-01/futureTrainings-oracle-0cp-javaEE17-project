package com.project.hotelbooking.datamodels.restapi.models;

import com.project.hotelbooking.datamodels.restapi.enums.eOptionTypes;

import java.util.List;
import java.util.Objects;

public class RoomFeature extends Option {

	private int optionId = 0;
	private boolean approval = false;
	private int countRooms = 0;
	private List<Integer> roomIds = null;

	public RoomFeature() {
		super();
	}

	public RoomFeature(int id, String name, String title, String description, boolean approval, int optionId,
			int countRooms, String creator, String created, boolean hasData) {
		this(id, name, title, description, creator, created, hasData);
		this.approval = approval;
		this.optionId = optionId;
		this.setCountRooms(countRooms);
	}

	public RoomFeature(int id, String name, String title, String description, String creator, String created,
			boolean hasData) {
		super(id, name, title, description, eOptionTypes.ROOM_FEATURE.getValue(), creator, created, hasData);
	}

	public RoomFeature(String name, String title, String description, String creator, String created, boolean hasData) {
		super(name, title, description, eOptionTypes.ROOM_FEATURE.getValue(), creator, created, hasData);
	}

	public boolean isApproval() {
		return approval;
	}

	public void setApproval(boolean approval) {
		this.approval = approval;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Objects.hash(approval, countRooms, optionId, roomIds);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		RoomFeature other = (RoomFeature) obj;
		return approval == other.approval && countRooms == other.countRooms && optionId == other.optionId
				&& Objects.equals(roomIds, other.roomIds);
	}

	@Override
	public String toString() {
		return "RoomFeature [optionId=" + optionId + ", approval=" + approval + ", countRooms=" + countRooms
				+ ", roomIds=" + roomIds + "]";
	}

	public int getOptionId() {
		return optionId;
	}

	public void setOptionId(int optionId) {
		this.optionId = optionId;
	}

	public List<Integer> getRoomIds() {
		return roomIds;
	}

	public void setRoomIds(List<Integer> roomIds) {
		this.roomIds = roomIds;
	}

	public int getCountRooms() {
		return countRooms;
	}

	public void setCountRooms(int countRooms) {
		this.countRooms = countRooms;
	}

}

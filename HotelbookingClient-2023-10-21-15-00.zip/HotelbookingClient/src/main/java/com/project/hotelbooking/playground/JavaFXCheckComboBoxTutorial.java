package com.project.hotelbooking.playground;

//Reduced import code

import com.project.hotelbooking.datamodels.restapi.models.Hotel;
import com.project.hotelbooking.datamodels.restapi.models.Lookup;
import com.project.hotelbooking.services.HotelService;
import javafx.application.Application;
import javafx.beans.InvalidationListener;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.StringConverter;
import org.controlsfx.control.CheckComboBox;

import java.util.List;

public class JavaFXCheckComboBoxTutorial extends Application {
    StringBuilder sbChoosen = new StringBuilder("");

    private CheckComboBox<Lookup> createCheckComboBox() {


        // Create the list of items to be shown on the combobox
        ObservableList<String> programmingLanguages = FXCollections.observableArrayList(
                "Java",
                "Cpp",
                "Python",
                "C#",
                "Kotlin"
        );
        HotelService hotelService = new HotelService();
        ObservableList<Hotel> hotels = hotelService.getHotels();

//        ObservableList<String> hotelNames = FXCollections.observableArrayList();
        ObservableList<Lookup> listHotels = FXCollections.observableArrayList();
        for(Hotel hotel : hotels) {
            listHotels.add(new Lookup(hotel.getId(), hotel.getTitle()) );
        }


        // Attach the list to the Combobox
//        CheckComboBox<String> checkComboBox = new CheckComboBox<>(programmingLanguages);
        CheckComboBox<Lookup> checkComboBox = new CheckComboBox<>(listHotels);
      //  checkComboBox.setCellFactory(lookups -> new LookupCell());
      //  checkComboBox.setButtonCell(new LookupCell());
        //As soon as an item is selected or selection is changed, display all the selected items
        checkComboBox.getCheckModel().getCheckedItems().addListener((InvalidationListener) observable -> {
          //  System.out.println("\n-------------------------------------------------------------------------------");

            sbChoosen = new StringBuilder();
            sbChoosen.append("(");
            for(Lookup lookup : getSelectedItems(checkComboBox)) {
             //   System.out.printf("\nCurrend Id: %s", lookup.getId());
                sbChoosen.append(lookup.getId()).append(",");
            }
            sbChoosen.append(")");


                });
        checkComboBox.setConverter(new StringConverter() {

            @Override
            public String toString(Object object) {
                Lookup person =  (Lookup) object;
                return person.getTitle();
            }

            @Override
            public Person fromString(String string) {
                return null;
            }
        });
    checkComboBox.setShowCheckedCount(false);

        return checkComboBox;


    }

    /**
     * Get the currently selected items from the CheckComboBox
     */
    private List<Lookup> getSelectedItems(CheckComboBox<Lookup> checkComboBox) {
        return checkComboBox.getCheckModel().getCheckedItems();
    }

    @Override
    public void start(Stage stage) {
        VBox contentPane = new VBox(10);
        contentPane.setAlignment(Pos.CENTER);
        contentPane.getChildren().addAll(new Label("CheckComboBox Example"), createCheckComboBox());

        Button button = new Button("Get Data!");
        button.setOnAction(e -> {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("test");
            alert.setHeaderText(null);
            alert.setContentText(sbChoosen.toString());
            alert.showAndWait();

        //    stage.close();
        });

        contentPane.getChildren().add(button);


        //contentPane.getChildren().addAll(


        Scene scene = new Scene(contentPane, 400, 500);
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}
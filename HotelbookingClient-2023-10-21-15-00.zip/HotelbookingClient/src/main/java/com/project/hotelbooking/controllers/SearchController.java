package com.project.hotelbooking.controllers;

import com.project.hotelbooking.Main;
import com.project.hotelbooking.components.LookupCell;
import com.project.hotelbooking.datamodels.restapi.models.*;
import com.project.hotelbooking.services.HotelbookingService;
import com.project.hotelbooking.services.RegionService;
import com.project.hotelbooking.services.SearchAccommodationService;
import com.project.hotelbooking.utils.Common;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;

import java.io.IOException;
import java.net.URISyntaxException;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public class SearchController {
    private ObservableList<Lookup> listRegions;

    private SearchAccommodationService searchAccommodationService;

    @FXML
    private BorderPane searchAccommodationPanel;

    @FXML
    private TableView<AccommodationSearchResult> searchTable;

    @FXML
    private ComboBox<Lookup> fldRegion;

    @FXML
    private DatePicker fldStartDate;

    @FXML
    private DatePicker fldEndDate;

    @FXML
    private Spinner<Integer> fldCountRooms;
    @FXML
    private Spinner<Integer> fldCountBeds;
    @FXML
    private VBox vBoxExtendedSearchAndMenuBar;
    @FXML
    private Label labSearchedHotelOptions;
    @FXML
    private Label labSearchedRoomFeatures;

    public static List<Integer> selectedHotelOptionIds;
    public static List<Integer> selectedRoomFeatureIds;

    @FXML
    private  MenuItem menYourBookings;
    @FXML
    private  MenuItem contextMenYourBookings;

    public void initialize() {
        listRegions = FXCollections.observableArrayList();
        RegionService regionService = new RegionService();

        for (Region region : regionService.getRegions()) {
            listRegions.add(new Lookup(region.getId(), region.getTitle()));
        }
        fldRegion.setCellFactory(lookups -> new LookupCell());
        fldRegion.setButtonCell(new LookupCell());
        fldRegion.setItems(listRegions);
        fldRegion.setValue(listRegions.get(0));

        fldStartDate.setValue(LocalDate.now().plusDays(1));
        fldEndDate.setValue(LocalDate.now().plusMonths(1));

        searchTable.setEditable(false);
        vBoxExtendedSearchAndMenuBar.setPadding(new Insets(15, 0, 0, 0.25));
        vBoxExtendedSearchAndMenuBar.setSpacing(15);


        if(!hasBookingDataByUser(Common.guestId)) {
            menYourBookings.setDisable(true);
            contextMenYourBookings.setDisable(true);
        }

        fldRegion.requestFocus();
    }

    public  boolean isValidSearchAccommodations() {
        boolean bReturn = true;
        Common.isWarningMessage = true;

        try {
            if (fldStartDate.getValue() == null) {
                Common.showValidationMessage("Das Feld StartDatum  darf nicht leer bleiben");
                bReturn = false;
                fldStartDate.requestFocus();
            } else if (fldEndDate.getValue() == null) {
                Common.showValidationMessage("Das Feld EndDatum  darf nicht leer bleiben");
                bReturn = false;
                fldEndDate.requestFocus();
            } else if (fldEndDate.getValue().isBefore(fldStartDate.getValue())) {
                Common.showValidationMessage("Das Feld EndDatum  darf nicht vor dem StartDatum liegen");
                bReturn = false;
                fldEndDate.requestFocus();
            } else if (fldEndDate.getValue().isEqual(fldStartDate.getValue())) {
                Common.showValidationMessage("Die Felder StartDatum und EndDatum dürfen nicht identisch sein.");
                bReturn = false;
                fldStartDate.requestFocus();
            } else if(fldCountRooms.getValue() < 1) {
                Common.showValidationMessage("Die Anzahl der Zimmer darf nicht 0 sein.");
                bReturn = false;
                fldCountRooms.requestFocus();
            } else if( fldCountBeds.getValue() < 1 ) {
                Common.showValidationMessage("Die Anzahl der Betten darf nicht 0 sein.");
                bReturn = false;
                fldCountBeds.requestFocus();
            } else if(fldCountBeds.getValue() < fldCountRooms.getValue() ) {
                Common.showValidationMessage("Die Anzahl der Betten darf nicht kleiner als die Anzahl der Zimmer sein.");
                bReturn = false;
                fldCountRooms.requestFocus();
            }
            return bReturn;
        } catch(NumberFormatException | NullPointerException e) {
            System.out.println("Exception - Reason: "+e.getMessage());
            return  false;
        }
    }

    @FXML
    public void SearchAccommodations() {
        searchAccommodationService = new SearchAccommodationService();

        if (searchTable != null && isValidSearchAccommodations()) {
            searchTable.setItems(searchAccommodationService.getSearchAccommodationsStandard(fldRegion.getValue().getTitle(),
                    fldStartDate.getValue().toString(), fldEndDate.getValue().toString(),
                    fldCountRooms.getValue(), fldCountBeds.getValue()));
            searchTable.setEditable(true);

            labSearchedHotelOptions.setText("");
            labSearchedRoomFeatures.setText("");
        }

        boolean hasBookingData = hasBookingDataByUser(Common.guestId);

        menYourBookings.setDisable(!hasBookingData);
        contextMenYourBookings.setDisable(!hasBookingData);
    }

    @FXML
    public void showExtendedSearchDialog() {
        Dialog<ButtonType> dialog = new Dialog<ButtonType>();
        dialog.initOwner(searchAccommodationPanel.getScene().getWindow());
        dialog.setTitle("Übernachtungen suchen");
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(Main.class.getResource("forms/extendedSearchDialog.fxml"));
        try {
            dialog.getDialogPane().setContent(fxmlLoader.load());

        } catch(IOException e) {
            System.out.println("Couldn't load the dialog");
            e.printStackTrace();
            return;
        }

        dialog.getDialogPane().getButtonTypes().add(ButtonType.OK);
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CANCEL);

        ExtendedSearchController extendedSearchController = fxmlLoader.getController();

        extendedSearchController.showExtendedSearchDetails(fldRegion.getValue(),
                fldStartDate.getValue(),fldEndDate.getValue(), fldCountRooms.getValue(), fldCountBeds.getValue());

        final Button okButton = (Button) dialog.getDialogPane().lookupButton(ButtonType.OK);
        okButton.addEventFilter(ActionEvent.ACTION, ae -> {
            if (!extendedSearchController.isValidSearchAccommodations()) {
                ae.consume(); //not valid
            }
        });

        Optional<ButtonType> result = dialog.showAndWait();
        if(result.isPresent() && result.get() == ButtonType.OK) {
            if (searchTable != null) {
                searchTable.setItems(extendedSearchController.searchAccommodationsExtended());
                searchTable.setEditable(true);
                StandardSearchParams standardSearchParams = extendedSearchController.getStandardSearchParams();

                if(!extendedSearchController.getSChoosenHotelOptions().isEmpty()) {
                    labSearchedHotelOptions.setText("* Hotel-Optionen: ["+extendedSearchController.getSChoosenHotelOptions()+"]");
                }

                if(!extendedSearchController.getSChoosenRoomFeatures().isEmpty()) {
                    labSearchedRoomFeatures.setText("* Zimmer-Features: ["+extendedSearchController.getSChoosenRoomFeatures()+"]");
                }

                fldRegion.setValue(standardSearchParams.region());
                fldStartDate.setValue(standardSearchParams.startDate());
                fldEndDate.setValue(standardSearchParams.endDate());
                fldCountBeds.getValueFactory().setValue(standardSearchParams.countBeds());
                fldCountRooms.getValueFactory().setValue(standardSearchParams.countRooms());
            }

        }
    }

    @FXML
    public void showDisplayAccommodationDetailsDialog() throws URISyntaxException {

        AccommodationSearchResult selectedAccommodationSearchResult = searchTable.getSelectionModel().getSelectedItem();

        if (selectedAccommodationSearchResult == null) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle(Common.alertMessage.getProperty("confirmSearchTitle"));
            alert.setHeaderText(null);
            alert.setContentText(Common.alertMessage.getProperty("confirmBookSearch"));
            alert.showAndWait();
            return;
        }

        Dialog<ButtonType> dialog = new Dialog<ButtonType>();
        dialog.initOwner(searchAccommodationPanel.getScene().getWindow());
        dialog.setTitle("Ihre Buchungsauswahl");
        FXMLLoader fxmlLoader = new FXMLLoader();

        fxmlLoader.setLocation(Main.class.getResource("forms/tabpanels/tabPanelAccommodationDetails.fxml"));

        try {
            dialog.getDialogPane().setContent(fxmlLoader.load());

        } catch (IOException e) {
            System.out.println("Couldn't load the dialog");
            e.printStackTrace();
            return;
        }


        ButtonType bookBinding = new ButtonType("Verbindlich buchen", ButtonBar.ButtonData.OK_DONE);
        ButtonType cancelOffer = new ButtonType("Angebot stornieren", ButtonBar.ButtonData.OK_DONE);

        dialog.getDialogPane().getButtonTypes().addAll(bookBinding, ButtonType.CANCEL);

        AccommodationDetailsMainController accommodationDetailsMainController = fxmlLoader.getController();
        accommodationDetailsMainController.showAccommodationDetail(selectedAccommodationSearchResult);

        if (Common.guestId == 0) {
            Common.showValidationMessage("Bitte melden Sie sich zuerst bei HotelBooking an!");
        } else {
            Optional<ButtonType> result = dialog.showAndWait();

            if (result.isPresent() && result.get() == bookBinding) {
                accommodationDetailsMainController.generateHotelBooking(selectedAccommodationSearchResult);

                Common.showValidationMessage("Gratulation, Sie haben Ihre gewünschte Übernachtung erfolgreich gebucht!");
                SearchAccommodations();
            } else if (result.isPresent() && result.get() == cancelOffer) {
                System.out.println("Storniert!");
            }

        }

    }

    @FXML
    public void showListHotelbookingsDialog() {

        AccommodationSearchResult selectedAccommodationSearchResult = searchTable.getSelectionModel().getSelectedItem();

        Dialog<ButtonType> dialog = new Dialog<ButtonType>();
        dialog.initOwner(searchAccommodationPanel.getScene().getWindow());
        dialog.setTitle("Ihre Buchungen");
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(Main.class.getResource("forms/listhotelbookingsdialog.fxml"));
        try {
            dialog.getDialogPane().setContent(fxmlLoader.load());

        } catch(IOException e) {
            System.out.println("Couldn't load the dialog");
            e.printStackTrace();
            return;
        }

        dialog.getDialogPane().getButtonTypes().add(ButtonType.OK);
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CANCEL);

        if(hasBookingDataByUser(Common.guestId)) {
            Optional<ButtonType> result = dialog.showAndWait();
            if(result.isPresent() && result.get() == ButtonType.OK) {
                SearchAccommodations();
            }

        } else {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle(Common.alertMessage.getProperty("informationNoDataTitle"));
            alert.setHeaderText(null);
            alert.setContentText(Common.alertMessage.getProperty("informationNoHotelbookingsData"));
            alert.showAndWait();
        }

    }


    private boolean hasBookingDataByUser(int guestId) {

        HotelbookingService hotelbookingService = new HotelbookingService();
        ObservableList<Hotelbooking> hotelbookings = hotelbookingService.getHotelbookingsByUser(guestId );

        return  hotelbookings != null && !hotelbookings.isEmpty();
    }

}

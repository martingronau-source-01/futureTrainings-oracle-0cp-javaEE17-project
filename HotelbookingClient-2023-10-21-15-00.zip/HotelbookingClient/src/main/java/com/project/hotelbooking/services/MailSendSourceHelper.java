package com.project.hotelbooking.services;

import com.project.hotelbooking.Main;
import jakarta.mail.Authenticator;
import jakarta.mail.PasswordAuthentication;
import jakarta.mail.Session;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class MailSendSourceHelper {
    private static final Boolean smtpAuth;
    private static final Boolean startTlsEnable;
    private static final String smtpHost;
    private static final Integer smtpPort;
    private static final String smtpSslTrust;

    private static final String smtpUserName;
    private static final String smtpPassword;

    private static final Properties smtpProperties = new Properties();
    public static final String sendCharset;

    static {
        Properties props = new Properties();
        try (InputStream is = Main.class.getResourceAsStream("mailsend.properties")) {
            props.load(is);
            smtpAuth = Boolean.valueOf(props.getProperty("mail.smtp.auth"));
            startTlsEnable = Boolean.valueOf(props.getProperty("mail.smtp.starttls.enable"));
            smtpHost = props.getProperty("mail.smtp.host");
            smtpPort = Integer.valueOf(props.getProperty("mail.smtp.port"));
            smtpSslTrust = props.getProperty("mail.smtp.ssl.trust");
            smtpUserName = props.getProperty("mail.smtp.username");
            smtpPassword = props.getProperty("mail.smtp.password");
            sendCharset = props.getProperty("mail.send.charset");

        } catch (IOException e) {
            throw new ExceptionInInitializerError(e);
        }
    }

    private static void setMailProperties() {
        smtpProperties.put("mail.smtp.auth", smtpAuth);
        smtpProperties.put("mail.smtp.starttls.enable", startTlsEnable);
        smtpProperties.put("mail.smtp.host", smtpHost);
        smtpProperties.put("mail.smtp.port", smtpPort);
        smtpProperties.put("mail.smtp.ssl.trust", smtpSslTrust);
    }

    public static Session getMailSesssion() {
        setMailProperties();
        return Session.getInstance(smtpProperties, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(smtpUserName, smtpPassword);
            }
        });
    }

}

package com.project.hotelbooking.utils;

import com.project.hotelbooking.datamodels.restapi.models.Login;
import com.project.hotelbooking.services.LoginService;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import lombok.Getter;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Properties;
import java.util.concurrent.atomic.AtomicBoolean;

public class Common {

    public static Properties alertMessage;

    public static final ButtonType YES = new ButtonType("JA", ButtonBar.ButtonData.OK_DONE);

    @Getter
    public static final ButtonType NO = new ButtonType("NEIN", ButtonBar.ButtonData.CANCEL_CLOSE);

    public static final DateTimeFormatter CUSTOM_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    public static final DateTimeFormatter CUSTOM_FORMATTER_SHORT = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    public static final DateTimeFormatter CUSTOM_FORMATTER_GERMAN_SHORT = DateTimeFormatter.ofPattern("dd.MM.yyyy");
    public static final String DEFAULT_MAIL_FROM_ADDRESS = "martin.gronau@futuristen.education";

    public static final String CREATOR = "MG";
    public static final String CREATED = LocalDateTime.now().format(CUSTOM_FORMATTER);

    public static Integer guestId = 0;

    public static boolean isWarningMessage = false;

    public void setLogin(Login login) {
        this.login = login;
    }

    public Login getLogin() {
        return login;
    }

    private Login login;

    static {
        initAlertMessages();
    }

    public Common() {
        super();
        this.login = new Login();

        initAlertMessages();
    }

    private static void initAlertMessages() {
        alertMessage = new Properties();

        alertMessage.setProperty("confirmHotelTitle", "Kein Hotel ausgewählt");
        alertMessage.setProperty("confirmGuestTitle", "Kein Gast ausgewählt");
        alertMessage.setProperty("confirmRegionTitle", "Keine Region ausgewählt");
        alertMessage.setProperty("confirmRoomTitle", "Kein Zimmer ausgewählt");
        alertMessage.setProperty("confirmRoomFeatureTitle", "Kein Zimmer-Feature ausgewählt");
        alertMessage.setProperty("confirmHotelOptionTitle", "Keine Hotel-Option ausgewählt");
        alertMessage.setProperty("confirmPaymentOptionTitle", "Keine Bezahlungs-Option ausgewählt");
        alertMessage.setProperty("confirmLoginTitle", "Keine Anmeldung ausgewählt");
        alertMessage.setProperty("confirmHotelbookingTitle", "Keine Buchung ausgewählt");
        alertMessage.setProperty("confirmSearchTitle", "Keine Hotel-Übernachtung ausgewählt");

        alertMessage.setProperty("confirmEditHotel", "Bitte wählen Sie ein Hotel zur Bearbeitung aus!");
        alertMessage.setProperty("confirmEditRoom", "Bitte wählen Sie ein Zimmer zur Bearbeitung aus!");
        alertMessage.setProperty("confirmEditGuest", "Bitte wählen Sie einen Gast zur Bearbeitung aus!");
        alertMessage.setProperty("confirmEditRegion", "Bitte wählen Sie eine Region zur Bearbeitung aus!");
        alertMessage.setProperty("confirmEditRoomFeature", "Bitte wählen Sie ein Zimmer-Feature zur Bearbeitung aus!");
        alertMessage.setProperty("confirmEditHotelOption", "Bitte wählen Sie eine Hotel-Option zur Bearbeitung aus!");
        alertMessage.setProperty("confirmEditPaymentOption", "Bitte wählen Sie eine Bezahlungs-Option zur Bearbeitung aus!");
        alertMessage.setProperty("confirmEditLogin", "Bitte wählen Sie eine Anmeldung zur Bearbeitung aus!");
        alertMessage.setProperty("confirmBookSearch", "Bitte wählen Sie eine Hotel-Übernachtung zur Buchung aus!");

        alertMessage.setProperty("confirmDeleteHotel", "Bitte wählen Sie das Hotel aus das Sie löschen möchten!");
        alertMessage.setProperty("confirmDeleteGuest", "Bitte wählen Sie den Gast aus den Sie löschen möchten!");
        alertMessage.setProperty("confirmDeleteRegion", "Bitte wählen Sie die Region aus die Sie löschen möchten!");
        alertMessage.setProperty("confirmDeleteRoom", "Bitte wählen Sie das Zimmer aus welches Sie löschen möchten!");
        alertMessage.setProperty("confirmDeleteRoomFeature", "Bitte wählen Sie das Zimmer-Feature aus welches Sie löschen möchten!");
        alertMessage.setProperty("confirmDeleteHotelOption", "Bitte wählen Sie die Hotel-Option aus welche Sie löschen möchten!");
        alertMessage.setProperty("confirmDeletePaymentOption", "Bitte wählen Sie die Bezahlungs-Option aus welche Sie löschen möchten!");
        alertMessage.setProperty("confirmDeleteLogin", "Bitte wählen Sie die Anmeldung aus welche Sie löschen möchten!");
        alertMessage.setProperty("confirmCancelHotelbooking", "Bitte wählen Sie die Buchung aus welche Sie stornieren möchten!");

        alertMessage.setProperty("underConstructionTitle", "Modul noch in Bearbeitung");
        alertMessage.setProperty("informationUnderConstruction", "Dieses Modul ist gegenwärtig noch in Bearbeitung und wird in Kürze fertiggestellt.\n Wir bitten um etwas Geduld. Danke!");

        alertMessage.setProperty("systemErrorTitle", "Fehlermeldung des internen Systems");
        alertMessage.setProperty("systemErrorServerDisconnected", "Der Zugriff auf unser zentrales System zur Datenverwaltung ist aus technischen Gründen vorübergehend leider  nicht möglich.\n\n "
                +"Bitte versuchen Sie zu späteren Zeitpunkt sich erneut anzumelden!!");


        alertMessage.setProperty("informationNoDataTitle", "Keine entsprechenden Datensätze vorhanden!");
        alertMessage.setProperty("informationNoHotelsData", "Keine Hotels zur Auswahl vorhanden!");
        alertMessage.setProperty("informationNoGuestsData", "Keine Gäste zur Auswahl vorhanden!");
        alertMessage.setProperty("informationNoRegionsData", "Keine Regionen zur Auswahl vorhanden!");
        alertMessage.setProperty("informationNoRoomsData", "Keine Zimmer zur Auswahl vorhanden!");
        alertMessage.setProperty("informationNoHotelbookingsData", "Keine Buchungsdaten zu Ihrer Anmeldung vorhanden!");
        alertMessage.setProperty("informationNoAccommodationSearchData", "Keine Übernachtungen entsprechend Ihrer Suchkriterien vorhanden!");
        alertMessage.setProperty("informationNoPaymentsData", "Keine Bezahlungs-Daten zur Auswahl vorhanden!");
        alertMessage.setProperty("informationNoRolesData", "Keine Benutzer-Rollen zur Auswahl vorhanden!");
        alertMessage.setProperty("informationNoLoginsData", "Keine Anmeldedaten zur Auswahl vorhanden!");
        alertMessage.setProperty("informationNoHotelOptionsData", "Keine Hotel-Optionen zur Auswahl vorhanden!");
        alertMessage.setProperty("informationNoPaymentOptionsData", "Keine Bezahlungs-Optionen zur Auswahl vorhanden!");
        alertMessage.setProperty("informationNoRoomFeaturesData", "Keine Room-Features zur Auswahl vorhanden!");
        alertMessage.setProperty("informationNoLoginsData", "Keine Anmeldedaten zur Auswahl vorhanden!");
    }


    public Common(Login login) {
        this();
        this.login = login;
    }

    public boolean showLoginDialog() throws IOException {

        Stage stage = new Stage();
        AtomicBoolean retValue = new AtomicBoolean(false);

        stage.initModality(Modality.APPLICATION_MODAL);

        TextField fldLoginname = new TextField();
        fldLoginname.setPrefWidth(125.0);
        PasswordField fldPassword = new PasswordField();
        fldPassword.setPrefWidth(125.0);

        Button btnOk = new Button("OK");
        btnOk.setPrefWidth(125.0);
        btnOk.setDefaultButton(true);

        Button btnCancel = new Button("Abbrechen");
        btnCancel.setDefaultButton(false);
        btnCancel.setPrefWidth(125.0);
        btnCancel.setCancelButton(true);

        btnOk.setOnAction(e -> {
            LoginService loginService = new LoginService();

            if (fldLoginname.getText().trim().isEmpty() || fldPassword.getText().trim().isEmpty()) {
                showValidationMessage("Bitte Anmeldename und Kennwort eingeben!");
            } else if (loginService.checkLogin(fldLoginname.getText(), fldPassword.getText())) {
                retValue.set(true);

                this.login = loginService.getLoginByUsername(fldLoginname.getText());
                stage.close();
            } else {
                fldLoginname.setText("");
                fldPassword.setText("");
                fldLoginname.requestFocus();
                showValidationMessage("Bitte Anmeldename bzw. Kennwort korrigieren!");
            }
        });

        btnCancel.setOnAction(e -> {
            stage.close();
        });

        fldLoginname.requestFocus();

        Label labUsername = new Label("Loginname:");
        labUsername.setPrefWidth(200.0);
        Label labPassword = new Label("Passwort:");
        labPassword.setPrefWidth(200.0);

        GridPane gridPanel = new GridPane();

        gridPanel.setPadding(new Insets(30, 30, 10, 30));
        gridPanel.setVgap(5);
        gridPanel.setHgap(5);

        gridPanel.add(fldLoginname, 1, 1);
        gridPanel.add(fldPassword, 1, 2);
        ButtonBar buttonBar = new ButtonBar();
        buttonBar.setPrefWidth(330.0);

        //Adding the buttons to the btnOk bar
        ButtonBar.setButtonData(btnOk, ButtonBar.ButtonData.APPLY);
        ButtonBar.setButtonData(btnCancel, ButtonBar.ButtonData.APPLY);
        buttonBar.getButtons().addAll(btnOk, btnCancel);

        HBox hbox = new HBox(2);
        hbox.setPadding(new Insets(20, 0, 5, 0));
        hbox.getChildren().addAll(buttonBar);

        gridPanel.add(hbox, 1, 3);

        gridPanel.add(labUsername, 0, 1);
        gridPanel.add(labPassword, 0, 2);

        Scene scene = new Scene(gridPanel, 375, 175);

        stage.setTitle("Anmeldung zu HotelBooking");
        stage.setScene(scene);
        stage.showAndWait();

        return retValue.get();
    }

    public static void showValidationMessage(String message) {
        Alert alert = new Alert(isWarningMessage ? Alert.AlertType.WARNING : Alert.AlertType.INFORMATION);
        alert.setTitle("Information");
        alert.setHeaderText("Hinweis zu Ihrer Eingabe");
        alert.setContentText(message);
        alert.showAndWait().ifPresent(rs -> {
            if (rs == ButtonType.OK) {
                //    System.out.println("Pressed OK.");
            }
        });
    }
}

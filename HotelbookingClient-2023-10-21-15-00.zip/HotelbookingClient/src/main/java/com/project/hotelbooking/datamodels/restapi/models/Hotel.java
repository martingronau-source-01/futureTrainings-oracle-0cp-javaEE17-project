package com.project.hotelbooking.datamodels.restapi.models;

import lombok.Getter;

import java.util.List;
import java.util.Objects;

@Getter
public class Hotel {

	private int id = 0;
	private String name = "";
	private String title = "";

	private String street = "";
	private String zipcode = "";
	private String location = "";
	private String description;
	private String email = "";
	private String phone = "";
	private String website = "";
	private int regionId = 0;
	private String region = "";

	private List<Integer> hotelOptionIds = null;

	private String creator = "";
	private String created = "";
	private boolean hasData = false;

	public Hotel() {
		super();
	}

	public Hotel(int id, String name, String title, String street, String zipcode, String location, String description,
			String email, String phone, String website, int regionId, String region, String creator, String created,
			boolean hasData) {
		this(name, title, street, zipcode, location, description, email, phone, website, regionId, region, creator,
				created, hasData);
		this.id = id;
	}

	public Hotel(String name, String title, String street, String zipcode, String location, String description,
			String email, String phone, String website, int regionId, String region, String creator, String created,
			boolean hasData) {
		this(name, title, street, zipcode, location, description, email, phone, website, regionId, creator, created,
				hasData);
		this.region = region;
	}

	public Hotel(String name, String title, String street, String zipcode, String location, String description,
			String email, String phone, String website, int regionId, String creator, String created, boolean hasData) {
		super();
		this.name = name;
		this.title = title;
		this.street = street;
		this.zipcode = zipcode;
		this.location = location;
		this.description = description;
		this.email = email;
		this.phone = phone;
		this.website = website;
		this.regionId = regionId;
		this.creator = creator;
		this.created = created;
		this.hasData = hasData;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public void setCreated(String created) {
		this.created = created;
	}

	public void setHasData(boolean hasData) {
		this.hasData = hasData;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setRegionId(int regionId) {
		this.regionId = regionId;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public void setWebsite(String website) {
		this.website = website;
	}

	@Override
	public int hashCode() {
		return Objects.hash(created, creator, description, email, hasData, id, location, name, phone, region, regionId,
				street, title, website, zipcode);
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public void setHotelOptionIds(List<Integer> hotelIds) {
		this.hotelOptionIds = hotelIds;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Hotel other = (Hotel) obj;
		return Objects.equals(created, other.created) && Objects.equals(creator, other.creator)
				&& Objects.equals(description, other.description) && Objects.equals(email, other.email)
				&& hasData == other.hasData && id == other.id && Objects.equals(location, other.location)
				&& Objects.equals(name, other.name) && Objects.equals(phone, other.phone)
				&& Objects.equals(region, other.region) && regionId == other.regionId
				&& Objects.equals(street, other.street) && Objects.equals(title, other.title)
				&& Objects.equals(website, other.website) && Objects.equals(zipcode, other.zipcode);
	}

	@Override
	public String toString() {
		return "Hotel [id=" + id + ", name=" + name + ", title=" + title + ", street=" + street + ", zipcode=" + zipcode
				+ ", location=" + location + ", description=" + description + ", email=" + email + ", phone=" + phone
				+ ", website=" + website + ", regionId=" + regionId + ", region=" + region + ", creator=" + creator
				+ ", created=" + created + ", hasData=" + hasData + "]";
	}

}

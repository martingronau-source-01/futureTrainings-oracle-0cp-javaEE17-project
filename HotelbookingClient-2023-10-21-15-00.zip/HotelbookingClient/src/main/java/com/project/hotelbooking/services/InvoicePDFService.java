package com.project.hotelbooking.services;

import com.itextpdf.kernel.color.Color;
import com.itextpdf.layout.border.Border;
import com.itextpdf.layout.border.DashedBorder;
import com.itextpdf.layout.border.SolidBorder;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.property.TextAlignment;
import com.project.hotelbooking.datamodels.restapi.models.Guest;
import com.project.hotelbooking.datamodels.restapi.models.Hotelbooking;
import com.project.hotelbooking.utils.PDFGenerator;
import lombok.Getter;

import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

@Getter
public class InvoicePDFService extends PDFGenerator {

    @Getter
    private Guest guest;
    @Getter
    private Hotelbooking hotelbooking;

    private final List<InvoicePosition> invoicePositionList;
    @Getter
    private List<Hotelbooking> bookingInvoicePositions;

    public void setBookingInvoicePositions(List<Hotelbooking> bookingInvoicePositions) {
        this.bookingInvoicePositions = bookingInvoicePositions;
    }

    public InvoicePDFService(Guest guest, Hotelbooking hotelbooking) {
        this();
        this.guest = guest;
        this.hotelbooking = hotelbooking;
    }


    public InvoicePDFService(Guest guest, Hotelbooking hotelbooking, List<Hotelbooking> bookingInvoicePositions) {
        this(guest, hotelbooking);
        this.bookingInvoicePositions = bookingInvoicePositions;
    }
    
    public InvoicePDFService() {
        super();
        invoicePositionList = new ArrayList<>();
    }

    public void setHotelbooking(Hotelbooking hotelbooking) {
        this.hotelbooking = hotelbooking;
    }

    public void setGuest(Guest guest) {
        this.guest = guest;
    }

    public void generateInvoicePositionsSingle() {

        if(this.hotelbooking != null) {
            addInvoicePosition(this.hotelbooking);
        }
    }

    public void generateInvoicePositionsMulti() {

        if(this.bookingInvoicePositions != null) {
            for(Hotelbooking bookingInvoicePosition : bookingInvoicePositions) {
                addInvoicePosition(bookingInvoicePosition);
            }
        }

    }


    private void addInvoicePosition(Hotelbooking hotelbooking) {

        invoicePositionList.add(new InvoicePosition(hotelbooking.getStartDate(), hotelbooking.getEndDate(),
                hotelbooking.getHotelTitle()+" - Zimmer: "+hotelbooking.getRoomTitle(),
                hotelbooking.getAccommodationPositionMwst(), hotelbooking.getSingleRawPrice(),
                hotelbooking.getCountAccommodations(), hotelbooking.getAccommodationsRawPrice()));
    }

    @Override
    protected void addPDFDocumentPageContents() {

        float threeCol = 190f;
        float twoCol=285f;
        float twoCol150=twoCol+150f;
        float[] twoColumnWidth = {twoCol150, twoCol};
        float[] fiveColumnWidth= {90, 90, 175, 90, 90};

        float[] fullwidth = {threeCol*3};

        final String sGuestFullName = guest.getFirstName()+" "+guest.getLastName();
        final String sZipcodeLocation = guest.getZipcode()+" "+guest.getLocation();

        Table table=new Table(twoColumnWidth);
        table.addCell(new Cell().add("Rechnung").setFontSize(18f).setBorder(Border.NO_BORDER).setBold());
        Table nestedTable = new Table(new float[]{twoCol/2, twoCol/2});
        nestedTable.addCell(getHeaderTextCell("Rechnung-Nr:"));
        nestedTable.addCell(getHeaderTextCellValue(hotelbooking.getInvoiceNumber()).setPaddingLeft(15f));
        nestedTable.addCell(getHeaderTextCell("Rechnung-Datum:"));
        nestedTable.addCell(getHeaderTextCellValue(LocalDate.now().format(DateTimeFormatter.ofPattern("dd.MM.yyyy"))).setPaddingLeft(15f));

        table.addCell(new Cell().add(nestedTable).setBorder(Border.NO_BORDER));

        Border gb = new SolidBorder(Color.GRAY, 1f/2f);
        Table divider = new Table(fullwidth);
        divider.setBorder(gb);

        document.add(table.setMarginTop(45f).setMarginLeft(5f));
        document.add(divider);

        Table tableInformation = new Table(twoColumnWidth);
        tableInformation.addCell(getBillingAndShippingCell("Abrechnungsdaten").setPaddingTop(10f));
        tableInformation.addCell(getBillingAndShippingCell("Versandinformationen").setPaddingTop(10f));
        document.add(tableInformation.setMarginBottom(12f));

        Table tableBillingInformation = new Table(twoColumnWidth);
        tableBillingInformation.addCell(getCell10fLeft("Firma:", true));
        tableBillingInformation.addCell(getCell10fLeft("Name:", true));
        tableBillingInformation.addCell(getCell10fLeft(guest.getCompanyName(), false));
        tableBillingInformation.addCell(getCell10fLeft(sGuestFullName, false));
        document.add(tableBillingInformation);


        Table tableShippingInformation = new Table(twoColumnWidth);
        tableShippingInformation.addCell(getCell10fLeft("Name:", true));
        tableShippingInformation.addCell(getCell10fLeft("Adresse:", true));
        tableShippingInformation.addCell(getCell10fLeft(sGuestFullName, false));
        tableShippingInformation.addCell(getCell10fLeft(guest.getStreet()+"\n"+sZipcodeLocation, false));
        document.add(tableShippingInformation);

        float[] oneColumnWidth = {twoCol150};
        Table tableBillingInformationAddress = new Table(oneColumnWidth);
        tableBillingInformationAddress.addCell(getCell10fLeft("Adresse:", true));
        tableBillingInformationAddress.addCell(getCell10fLeft(guest.getStreet()+"\n"+sZipcodeLocation, false));
        tableBillingInformationAddress.addCell(getCell10fLeft("EMail:", true));
        tableBillingInformationAddress.addCell(getCell10fLeft(guest.getEmail(), false));
        document.add(tableBillingInformationAddress.setMarginBottom(10f));

        Table tableDivider2 = new Table(fullwidth);
        Border dgb = new DashedBorder(Color.GRAY, 0.5f);
        tableDivider2.setBorder(dgb);

        Table tablePositionDataHeader = new Table(fiveColumnWidth);
        tablePositionDataHeader.setBackgroundColor(Color.BLACK, 0.7f);

        tablePositionDataHeader.addCell(new Cell().add("Beginn").setBold().setFontColor(Color.WHITE).setBorder(Border.NO_BORDER).setTextAlignment(TextAlignment.CENTER));
        tablePositionDataHeader.addCell(new Cell().add("Ende").setBold().setFontColor(Color.WHITE).setBorder(Border.NO_BORDER).setTextAlignment(TextAlignment.CENTER));
        tablePositionDataHeader.addCell(new Cell().add("Beschreibung").setBold().setFontColor(Color.WHITE).setBorder(Border.NO_BORDER).setTextAlignment(TextAlignment.CENTER));
        tablePositionDataHeader.addCell(new Cell().add("Mwst").setBold().setFontColor(Color.WHITE).setBorder(Border.NO_BORDER).setTextAlignment(TextAlignment.RIGHT).setPaddingRight(15f));
        tablePositionDataHeader.addCell(new Cell().add("Kosten").setBold().setFontColor(Color.WHITE).setBorder(Border.NO_BORDER).setTextAlignment(TextAlignment.RIGHT).setPaddingRight(15f));
        document.add(tablePositionDataHeader.setMarginTop(10f));

        Table tablePositionData = new Table(fiveColumnWidth);

        double totalRawPrice = 0.00;
        for(InvoicePosition invoicePosition : invoicePositionList) {

//            double cost = invoicePosition.getSinglePrice()*invoicePosition.getQuantity();
  //          double mwst = invoicePosition.getAccommodationPositionMwst()*invoicePosition.getQuantity();

            tablePositionData.addCell(new Cell().add(invoicePosition.getStartDate()).setBorder(Border.NO_BORDER)).setTextAlignment(TextAlignment.CENTER).setMarginLeft(5f);
            tablePositionData.addCell(new Cell().add(invoicePosition.getEndDate()).setTextAlignment(TextAlignment.CENTER)
                    .setBorder(Border.NO_BORDER).setMarginLeft(5f));
            tablePositionData.addCell(new Cell().add(invoicePosition.getDescription())
                    .setBorder(Border.NO_BORDER).setMarginLeft(0.5f).setTextAlignment(TextAlignment.LEFT));
            tablePositionData.addCell(new Cell().add(DecimalFormat.getCurrencyInstance(Locale.GERMANY).format(
                    invoicePosition.getAccommodationPositionMwst())).setTextAlignment(TextAlignment.RIGHT)
                    .setBorder(Border.NO_BORDER)).setMarginRight(5f);
//            tablePositionData.addCell(new Cell().add(DecimalFormat.getCurrencyInstance(Locale.GERMANY).format(cost)).setTextAlignment(TextAlignment.RIGHT)
  //                  .setBorder(Border.NO_BORDER)).setMarginRight(5f);
            tablePositionData.addCell(new Cell().add(DecimalFormat.getCurrencyInstance(Locale.GERMANY).format(
                    invoicePosition.getAccommodationsRawPrice())).setTextAlignment(TextAlignment.RIGHT)
                    .setBorder(Border.NO_BORDER)).setMarginRight(5f);
             totalRawPrice +=  invoicePosition.getAccommodationsRawPrice();
            //formattedAccommodationsRawPrice
        }
        document.add(tablePositionData.setMarginBottom(20f));

        float[] onetwo = {threeCol+125f, threeCol*2};
        Table threeColTable4 = new Table(onetwo);
        threeColTable4.addCell(new Cell().add("").setBorder(Border.NO_BORDER));
        threeColTable4.addCell(new Cell().add(tableDivider2).setBorder(Border.NO_BORDER));
        document.add(threeColTable4);


        float[] summaryOneTwo = {(twoCol*4)+425f, threeCol};
        Table tableSummary1 = new Table(summaryOneTwo);

        tableSummary1.addCell(new Cell().add(hotelbooking.getFormattedMwst()).setTextAlignment(TextAlignment.RIGHT)
                .setBorder(Border.NO_BORDER));
        tableSummary1.addCell(new Cell().add(DecimalFormat.getCurrencyInstance(Locale.GERMANY).format(totalRawPrice)).setTextAlignment(TextAlignment.RIGHT).setBorder(Border.NO_BORDER).setMarginRight(15f));
        document.add(tableSummary1);

        float[] totalSummaryOneTwo = {(twoCol*3), 2*threeCol};
        Table tableSummary2 = new Table(totalSummaryOneTwo);
        tableSummary2.addCell(new Cell().add("Summe:").setBold().setTextAlignment(TextAlignment.RIGHT).setBorder(Border.NO_BORDER));
        tableSummary2.addCell(new Cell().add(hotelbooking.getFormattedTotalcost()).setTextAlignment(TextAlignment.RIGHT).setBorder(Border.NO_BORDER).setMarginRight(15f));
        document.add(tableSummary2);

        document.add(tableDivider2);
        Table tableTermsAndConditions = new Table(fullwidth);
        tableTermsAndConditions.addCell(new Cell().add("Geschäftsbedingungen\n").setBold().setBorder(Border.NO_BORDER));

        List<String> TncList=new ArrayList<>();
        TncList.add("1. Der Verkäufer haftet gegenüber dem Käufer weder direkt noch indirekt für Verluste oder Schäden, die dem Käufer entstehen.");
        TncList.add("2. Der Verkäufer gewährt auf das Produkt eine Garantie von zwei (1) Jahren ab Ausstellungsdatum");

        for(String tnc: TncList) {
            tableTermsAndConditions.addCell(new Cell().add(tnc).setBorder(Border.NO_BORDER).setFontSize(8f));
        }

        if(!tableTermsAndConditions.isEmpty()) {
            tableTermsAndConditions.setMarginLeft(20f).setMarginTop(25f);
            document.add(tableTermsAndConditions);
        }

    }

}


@Getter
class  InvoicePosition {
    private String startDate;
    private String endDate;
    private String description;
    private int quantity;
    private double accommodationPositionMwst;
    @Getter
    private double accommodationsRawPrice;

    public void setAccommodationsRawPrice(double accommodationsRawPrice) {
        this.accommodationsRawPrice = accommodationsRawPrice;
    }

    private double singlePrice;
    
    public InvoicePosition() {
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof InvoicePosition that)) return false;
        return getQuantity() == that.getQuantity() && Double.compare(getAccommodationPositionMwst(), that.getAccommodationPositionMwst()) == 0 && Double.compare(getAccommodationsRawPrice(), that.getAccommodationsRawPrice()) == 0 && Double.compare(getSinglePrice(), that.getSinglePrice()) == 0 && Objects.equals(getStartDate(), that.getStartDate()) && Objects.equals(getEndDate(), that.getEndDate()) && Objects.equals(getDescription(), that.getDescription());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getStartDate(), getEndDate(), getDescription(), getQuantity(), getAccommodationPositionMwst(), getAccommodationsRawPrice(), getSinglePrice());
    }

    @Override
    public String toString() {
        return "InvoicePosition{" +
                "startDate='" + startDate + '\'' +
                ", endDate='" + endDate + '\'' +
                ", description='" + description + '\'' +
                ", quantity=" + quantity +
                ", accommodationPositionMwst=" + accommodationPositionMwst +
                ", accommodationsRawPrice=" + accommodationsRawPrice +
                ", singlePrice=" + singlePrice +
                '}';
    }

    public InvoicePosition(String startDate, String endDate, String description,
                           double accommodationPositionMwst, double singlePrice, int quantity,
                           double accommodationsRawPrice) {
        this.startDate = startDate;
        this.endDate = endDate;
        this.description = description;
        this.accommodationPositionMwst = accommodationPositionMwst;
        this.singlePrice = singlePrice;
        this.quantity = quantity;
        this.accommodationsRawPrice = accommodationsRawPrice;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setAccommodationPositionMwst(double accommodationPositionMwst) {
        this.accommodationPositionMwst = accommodationPositionMwst;
    }

    public void setSinglePrice(double singlePrice) {
        this.singlePrice = singlePrice;
    }


    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

}

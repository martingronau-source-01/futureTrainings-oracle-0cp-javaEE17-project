package com.project.hotelbooking.playground.controllers.tabPanels;

import com.project.hotelbooking.components.LookupCell;
import com.project.hotelbooking.datamodels.restapi.models.Login;
import com.project.hotelbooking.datamodels.restapi.models.Lookup;
import com.project.hotelbooking.datamodels.restapi.models.Role;
import com.project.hotelbooking.services.RoleService;
import com.project.hotelbooking.utils.Common;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;

public class TestTabRegistrationLoginController {

    @FXML
    GridPane registrationLoginDataPanel;
    @FXML
    GridPane registrationGuestDataPanel;

    @FXML
    private ComboBox<Lookup> fldRole = new ComboBox<Lookup>();
    private ObservableList<Lookup> listRoles;
    @FXML
    private TextField fldUsername = new TextField();
    @FXML
    private TextField fldLoginname = new TextField();
    @FXML
    private PasswordField fldPassword = new PasswordField();
    @FXML
    private CheckBox fldRegistered  = new CheckBox();
    @FXML
    private Button btnOk;



    public void initialize() {


        listRoles = FXCollections.observableArrayList();
        RoleService roleService = new RoleService();

        for (Role role : roleService.getRoles()) {
            listRoles.add(new Lookup(role.getId(), role.getDescription()));
        }

        fldRole.setCellFactory(lookups -> new LookupCell());
        fldRole.setButtonCell(new LookupCell());
        fldRole.setItems(listRoles);
        fldRole.setValue(listRoles.get(0));

        /*
        btnOk. setOnAction(actionEvent  -> {

            Login login = getNewLogin();
            System.out.println(login.toString());

            // close the dialog.
            Node source = (Node)  actionEvent.getSource();
            Stage stage  = (Stage) source.getScene().getWindow();
            stage.close();
        }); */
    }

    @FXML
    public void dataAction() {
      //  System.out.println(fldLoginname.getText());
        System.out.println("hallo welt");
    }

    public Login getNewLogin() {
        String username = fldUsername.getText();
        String loginName = fldLoginname.getText();
        String password = fldPassword.getText();
        Lookup role = fldRole.getSelectionModel().getSelectedItem();
     //   Lookup guest = fldGuest.getSelectionModel().getSelectedItem();
        boolean registered = fldRegistered.isSelected();

        int guestId = 0;

        String salt = "";
        String hash = "";
        boolean hasData = true;

        return new Login(username,loginName,password,salt,0,registered,
                guestId, Common.CREATOR, Common.CREATED, hasData);
    }
}

package com.project.hotelbooking.datamodels.restapi.models;

import java.util.Objects;

public class Booking {

	private int id = 0;
	private String startDate;
	private String endDate;
	private int hotelId = 0;
	private int guestId = 0;
	private int roomId = 0;

	private String creator = "";
	private String created = "";
	private boolean hasData = false;
	
	public String getCreated() {
		return created;
	}

	public void setCreated(String created) {
		this.created = created;
	}

	public boolean isHasData() {
		return hasData;
	}

	public void setHasData(boolean hasData) {
		this.hasData = hasData;
	}

	public Booking() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Booking(int id, String startDate, String endDate, int hotelId, int guestId, int roomId, String creator,
			String created, boolean hasData) {
		super();
		this.id = id;
		this.startDate = startDate;
		this.endDate = endDate;
		this.hotelId = hotelId;
		this.guestId = guestId;
		this.roomId = roomId;
		this.creator = creator;
		this.created = created;
		this.hasData = hasData;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public int getHotelId() {
		return hotelId;
	}

	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}

	@Override
	public int hashCode() {
		return Objects.hash(id, created, creator, endDate, guestId, hasData, hotelId, roomId, startDate);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Booking other = (Booking) obj;
		return id == other.id && Objects.equals(created, other.created) && Objects.equals(creator, other.creator)
				&& Objects.equals(endDate, other.endDate) && guestId == other.guestId && hasData == other.hasData
				&& hotelId == other.hotelId && roomId == other.roomId && Objects.equals(startDate, other.startDate);
	}

	@Override
	public String toString() {
		return "Booking [id=" + id + ", startDate=" + startDate + ", endDate=" + endDate + ", hotelId=" + hotelId
				+ ", guestId=" + guestId + ", roomId=" + roomId + ", creator=" + creator + ", created=" + created
				+ ", hasData=" + hasData + "]";
	}

	public int getGuestId() {
		return guestId;
	}

	public void setGuestId(int guestId) {
		this.guestId = guestId;
	}

	public int getRoomId() {
		return roomId;
	}

	public void setRoomId(int roomId) {
		this.roomId = roomId;
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

}

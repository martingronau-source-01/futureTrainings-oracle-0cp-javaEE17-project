package com.project.hotelbooking.playground.controllers;

import com.project.hotelbooking.playground.controllers.tabPanels.TabRegistrationGuestController;
import com.project.hotelbooking.datamodels.restapi.models.Guest;
import com.project.hotelbooking.datamodels.restapi.models.Login;
import com.project.hotelbooking.services.GuestService;
import com.project.hotelbooking.services.LoginService;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;

public class RegistrationMainController {
    private LoginService loginService;
    private GuestService guestService;

    @FXML
    private Tab tabRegistrationGuest;
    @FXML
    private TabRegistrationGuestController tabRegistrationGuestController;

    @FXML
    private TabPane tabPaneRegistrationMain;

    public void initialize() {
        loginService = new LoginService();
        guestService = new GuestService();

        if(tabRegistrationGuestController == null) {
            tabRegistrationGuestController = new TabRegistrationGuestController();
        }
    //    tabRegistrationLoginController = new TabRegistrationLoginController();

        tabPaneRegistrationMain.setPadding(new Insets(15, 25, 15, 25));
        tabPaneRegistrationMain.getSelectionModel().selectFirst();
     //   tabRegistrationGuestController.initialize();

       // Guest guest  =  tabRegistrationGuestController.getNewGuest();
      //  System.out.println(guest.toString());
    }

    public void showNewRegistrationData() {

    }

    public void storeNewRegistration(Guest guest, Login login) {

   //    guest = tabRegistrationGuestController.getNewGuest();
/*
        Login login = tabRegistrationLoginController.getNewLogin();
        System.out.println(login.toString());

        return guest;

         */
//        login = tabRegistrationLoginController.getNewLogin();

    }
}

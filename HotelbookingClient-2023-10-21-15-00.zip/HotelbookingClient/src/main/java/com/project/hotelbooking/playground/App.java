package com.project.hotelbooking.playground;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class App extends Application {

    static ObservableList<String> jvmChoices = FXCollections.observableArrayList(
            "Java",
            "Kotlin",
            "Groovy",
            "Scala",
            "Clojure"
    );

    static VBox contentVBox = new VBox();

    public static void main(String[] args) {
        launch();
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        var root = new BorderPane();

        showJvmLangsChoiceBox();

        root.setCenter(contentVBox);
        primaryStage.setScene(new Scene(root, 400, 100));
        primaryStage.show();
    }

    static void showJvmLangsChoiceBox() {
        contentVBox.getChildren().clear();

        var jvmLangsChoiceBox = new ChoiceBox<String>(jvmChoices);

        // bind ChoiceBox's currently selected valueProperty to the Label's textProperty
        // to make it clear that you can access the selected item of a ChoiceBox
        var valueLabel = new Label();
        valueLabel.textProperty().bind(jvmLangsChoiceBox.valueProperty());

        contentVBox.getChildren().add(
                new HBox(10,
                        new Label("ChoiceBox<String> JVM Languages"),
                        jvmLangsChoiceBox,
                        valueLabel
                )
        );
    }
}
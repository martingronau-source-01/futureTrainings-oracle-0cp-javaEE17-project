package com.project.hotelbooking.playground;

import java.net.InetAddress;
import java.net.Socket;

public class WebPing {
    public static void main(String[] args) {

        boolean bConnected = false;
        try {
            InetAddress addr;
            Socket sock = new Socket("localhost", 8081);
            addr = sock.getInetAddress();
    //        System.out.println("Connected to " + addr);
            bConnected = true;
            sock.close();
        } catch (java.io.IOException e) {
//            System.out.println("Can't connect to " + args[0]);
  //          System.out.println(e);
            bConnected = false;
        }

            System.out.println(bConnected ?"Connection erfolgreich!" : "Connection gescheitert!");
    }
}
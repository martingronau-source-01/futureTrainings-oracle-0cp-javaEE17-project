package com.project.hotelbooking.playground;

import java.net.InetSocketAddress;
import java.net.Socket;

public class TestOnAvailable {

    private static final int PORT = 8088;
    private static final String SERVER_IP_ADDRESS = "127.0.0.1";
    public static boolean isOnline(String serverAddress, int port) {
        boolean b = true;
        try{
            InetSocketAddress sa = new InetSocketAddress(serverAddress, port);
            Socket ss = new Socket();
            ss.connect(sa, 250);          //  --> change from 1 to 500 (for example)
            ss.close();
        }catch(Exception e) {
            b = false;
        }
        return b;
    }


    public static void main(String[] args) {
        System.out.println(isOnline("localhost", 8088));
    }
}

package com.project.hotelbooking.datamodels.restapi.enums;


public enum eHttpStatusCodes {

    HTTP_OK(200), HTTP_CREATED(201), HTTP_ACCEPTED(202), HTTP_NON_AUTHORITATIVE_INFO(203),
    HTTP_NO_CONTENT(204), HTTP_RESET_CONTENT(205), HTTP_PARTIAL_CONTENT(206), HTTP_USED(226),
    HTTP_NOT_MODIFIED(304), HTTP_BAD_REQUEST(400), HTTP_FORBIDDEN(403), HTTP_NOT_FOUND(404),
    HTTP_LOCKED(423), HTTP_INTERNAL_SERVER_ERROR(500), HTTP_BAD_GATEWAY(502),
    HTTP_SERVICE_UNAVAILABLE(503), HTTP_GATEWAY_TIMEOUT(504);

    private final int value;

    eHttpStatusCodes(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }

}

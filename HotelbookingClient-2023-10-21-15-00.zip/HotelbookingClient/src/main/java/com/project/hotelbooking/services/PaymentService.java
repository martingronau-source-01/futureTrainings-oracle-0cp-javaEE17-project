package com.project.hotelbooking.services;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.project.hotelbooking.datamodels.restapi.enums.eHttpStatusCodes;
import com.project.hotelbooking.datamodels.restapi.models.Payment;
import com.project.hotelbooking.utils.Common;
import com.project.hotelbooking.utils.SystemSecure;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;

import java.net.URISyntaxException;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.List;

public class PaymentService extends RestApiService {
    private final String paymentsURI;
    private final Gson gson;

    public PaymentService() {
        super();
        gson = new Gson();

        SystemSecure systemSecure = new SystemSecure();

        String sBaseURI = systemSecure.getRestApiConnectionUri();
        paymentsURI = sBaseURI + systemSecure.getDelimiter() + "payments" + systemSecure.getDelimiter();
    }

    public int insertPayment(Payment payment) throws URISyntaxException {
        String jsonRequest = gson.toJson(payment);
        return this.sendPostRequest(paymentsURI, jsonRequest);

    }

    public int updatePayment(int paymentId, Payment payment) throws URISyntaxException {
        String jsonRequest = gson.toJson(payment);

        return this.sendPutRequest(paymentsURI + paymentId, jsonRequest);
    }

    public int deletePayment(int paymentId) throws URISyntaxException {
        return this.sendDeleteRequest(paymentsURI + paymentId);
    }

    public Payment getPayment(int paymentId) {
        HttpResponse<String> getResponse = this.sendGetRequest(paymentsURI + paymentId);

        return gson.fromJson(getResponse.body(), Payment.class);
    }

    public ObservableList<Payment> getPayments() {
        HttpResponse<String> getResponse = this.sendGetRequest(paymentsURI);

        if (getResponse.statusCode() == eHttpStatusCodes.HTTP_OK.getValue()) {
            List<Payment> payments = gson.fromJson(getResponse.body(), new TypeToken<ArrayList<Payment>>() {
            }.getType());
            return FXCollections.observableList(payments);
        } else if (getResponse.statusCode() == eHttpStatusCodes.HTTP_NO_CONTENT.getValue()) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle(Common.alertMessage.getProperty("informationNoDataTitle"));
            alert.setHeaderText(null);
            alert.setContentText(Common.alertMessage.getProperty("informationNoPaymentsData"));
            alert.showAndWait();
            return null;
        } else {
            return null;
        }

    }

    public ObservableList<Payment> getPaymentsByPaymentOption(int paymentOptionId) {
        HttpResponse<String> getResponse = this.sendGetRequest(paymentsURI + "by-paymentoption/" + paymentOptionId);

        List<Payment> payments = gson.fromJson(getResponse.body(), new TypeToken<ArrayList<Payment>>() {
        }.getType());

        return FXCollections.observableList(payments);
    }
}

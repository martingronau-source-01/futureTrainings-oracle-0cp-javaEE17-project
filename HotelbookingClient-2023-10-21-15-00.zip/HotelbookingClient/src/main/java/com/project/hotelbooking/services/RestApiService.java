package com.project.hotelbooking.services;

import com.project.hotelbooking.datamodels.restapi.enums.eHttpStatusCodes;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandlers;

public class RestApiService {

    protected int sendPostRequest(String URI, String jsonRequest) {

        int iReturn;

        try {
            HttpRequest postRequest = HttpRequest.newBuilder()
                    .uri(new URI(URI))
                    .header("Content-Type", "application/json")
                    .POST(BodyPublishers.ofString(jsonRequest))
                    .build();
            HttpClient httpClient = HttpClient.newHttpClient();
            HttpResponse<String> postResponse = httpClient.send(postRequest, BodyHandlers.ofString());
            iReturn = postResponse.statusCode() == eHttpStatusCodes.HTTP_CREATED.getValue() ?
                    Integer.parseInt(postResponse.body()) : 0;
            return iReturn;
        } catch (IOException | InterruptedException  | URISyntaxException e) {
            System.out.println(e.getMessage());
            throw new RuntimeException(e);
        }
    }

    protected int sendPutRequest(String URI, String jsonRequest) {
        int iReturn;

        try {
            HttpRequest putRequest = HttpRequest.newBuilder()
                    .uri(new URI(URI))
                    .header("Content-Type", "application/json")
                    .PUT(BodyPublishers.ofString(jsonRequest))
                    .build();
            HttpClient httpClient = HttpClient.newHttpClient();
            HttpResponse<String> putResponse = httpClient.send(putRequest, BodyHandlers.ofString());
            iReturn = putResponse.statusCode() == eHttpStatusCodes.HTTP_OK.getValue() ?
                    Integer.parseInt(putResponse.body()) : 0;
        } catch (IOException | InterruptedException  | URISyntaxException e) {
            throw new RuntimeException(e);
        }

        return iReturn;
    }

    protected int sendDeleteRequest(String URI) {
        int iReturn;

        try {
            HttpRequest deleteRequest = HttpRequest.newBuilder()
                    .uri(new URI(URI))
                    .header("Content-Type", "application/json")
                    .DELETE()
                    .build();
            HttpClient httpClient = HttpClient.newHttpClient();
            HttpResponse<String> deleteResponse = httpClient.send(deleteRequest, BodyHandlers.ofString());

            iReturn = deleteResponse.statusCode() == eHttpStatusCodes.HTTP_OK.getValue() ?
                    Integer.parseInt(deleteResponse.body()) : 0;
        } catch (IOException | InterruptedException  | URISyntaxException e) {
            throw new RuntimeException(e);
        }
        return iReturn;
    }

    protected  HttpResponse<String>  sendGetRequest(String URI) {

        HttpResponse<String> getResponse;

        try {
            HttpRequest getRequest = HttpRequest.newBuilder()
                    .uri(new URI(URI))
                    .header("Content-Type", "application/json")
                    .build();
            HttpClient httpClient = HttpClient.newHttpClient();
            getResponse = httpClient.send(getRequest, BodyHandlers.ofString());
        }  catch (IOException | InterruptedException  | URISyntaxException e) {
            throw new RuntimeException(e);
        }
        return getResponse.statusCode() == eHttpStatusCodes.HTTP_OK.getValue()
                ||  getResponse.statusCode() == eHttpStatusCodes.HTTP_NO_CONTENT.getValue() ?
                getResponse : null;
    }

}

package com.project.hotelbooking.services;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.project.hotelbooking.datamodels.restapi.enums.eHttpStatusCodes;
import com.project.hotelbooking.datamodels.restapi.models.Guest;
import com.project.hotelbooking.utils.Common;
import com.project.hotelbooking.utils.SystemSecure;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;

import java.net.URISyntaxException;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.List;

public class GuestService extends RestApiService {

    private  final String guestsURI;
    private final Gson gson;

    public GuestService() {
        super();
        gson= new Gson();

        SystemSecure systemSecure = new SystemSecure();

        String sBaseURI = systemSecure.getRestApiConnectionUri();
        guestsURI = sBaseURI+systemSecure.getDelimiter()+"guests"+systemSecure.getDelimiter();
    }
    public int insertGuest(Guest guest)  throws URISyntaxException  {
        String jsonRequest = gson.toJson(guest);
        return this.sendPostRequest(guestsURI, jsonRequest);

    }

    public int updateGuest(int guestId, Guest guest) throws URISyntaxException {
        String jsonRequest = gson.toJson(guest);

        return this.sendPutRequest(guestsURI + guestId, jsonRequest);
    }

    public int deleteGuest(int guestId) throws URISyntaxException {
        return this.sendDeleteRequest(guestsURI + guestId);
    }

    public Guest getGuest(int guestId) {
        HttpResponse<String> getResponse = this.sendGetRequest(guestsURI + guestId);

        return gson.fromJson(getResponse.body(), Guest.class);
    }

    public ObservableList<Guest> getGuests() {
        HttpResponse<String> getResponse = this.sendGetRequest(guestsURI);

        if(getResponse.statusCode() == eHttpStatusCodes.HTTP_OK.getValue()) {

            List<Guest> guests = gson.fromJson(getResponse.body(), new TypeToken<ArrayList<Guest>>() {
            }.getType());

            return FXCollections.observableList(guests);
        } else if(getResponse.statusCode() == eHttpStatusCodes.HTTP_NO_CONTENT.getValue()) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle(Common.alertMessage.getProperty("informationNoDataTitle"));
            alert.setHeaderText(null);
            alert.setContentText(Common.alertMessage.getProperty("informationNoGuestsData"));
            alert.showAndWait();

            return  null;
        } else {
            return null;
        }
    }
}

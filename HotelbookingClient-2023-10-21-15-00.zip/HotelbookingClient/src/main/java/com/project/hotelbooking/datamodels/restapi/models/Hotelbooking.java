package com.project.hotelbooking.datamodels.restapi.models;

import lombok.Getter;

import java.util.Objects;

@Getter
public class Hotelbooking extends Booking {

	private int roomOccupancyId = 0;
	private int paymentId = 0;
	private int countAccommodations = 0;
	private double accommodationsRawPrice = 0.00;
	private String formattedAccommodationsRawPrice = "";	
	private double accommodationPositionMwst = 0.00;
	private String formattedAccommodationsPositionMwst = "";	
	private int bookingId = 0;
	private String roomName = "";
	private String roomTitle = "";
	private double totalcost = 0.00;
	private String formattedTotalcost = "";
	private double mwst = 0.00;
	private String formattedMwst = "";
	private String hotelTitle = "";
	private String hotelName = "";
	private String hotelStreet = "";
	private String hotelZipcode = "";
	private String hotelLocation = "";
	private String hotelEMail = "";
	private String hotelWebsite = "";
	private String regionName = "";
	private String regionTitle = "";
	private String invoiceNumber = "";

	public void setHotelZipcode(String hotelZipcode) {
		this.hotelZipcode = hotelZipcode;
	}

	public void setHotelLocation(String hotelLocation) {
		this.hotelLocation = hotelLocation;
	}

	public void setHotelEMail(String hotelEMail) {
		this.hotelEMail = hotelEMail;
	}

	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}

	public void setRegionTitle(String regionTitle) {
		this.regionTitle = regionTitle;
	}

	private double singleRawPrice = 0.00;
	private String formattedSingleRawPrice = "";	


	public Hotelbooking() {
		super();
	}

	public Hotelbooking(int id, String startDate, String endDate, int hotelId, int guestId, int roomId, int roomOccupancyId,
			int paymentId, int countAccommodations, double accommodationsRawPrice,  int bookingId, String roomName, String roomTitle, 
			double totalcost, double mwst, String hotelTitle, String hotelName, double singleRowPrice, String created, 
			String creator, boolean hasData) {
		this(startDate, endDate, hotelId, guestId, roomId, roomOccupancyId, paymentId, countAccommodations, accommodationsRawPrice, 
			bookingId, roomName, roomTitle, totalcost, mwst, hotelTitle, hotelName, singleRowPrice,created, created, hasData);
		this.setId(id);
	}

	@Override
	public String toString() {
		return super.toString()+" - Hotelbooking{" +
				"roomOccupancyId=" + roomOccupancyId +
				", paymentId=" + paymentId +
				", countAccommodations=" + countAccommodations +
				", accommodationsRawPrice=" + accommodationsRawPrice +
				", formattedAccommodationsRawPrice='" + formattedAccommodationsRawPrice + '\'' +
				", accommodationPositionMwst=" + accommodationPositionMwst +
				", formattedAccommodationsPositionMwst='" + formattedAccommodationsPositionMwst + '\'' +
				", bookingId=" + bookingId +
				", roomName='" + roomName + '\'' +
				", roomTitle='" + roomTitle + '\'' +
				", totalcost=" + totalcost +
				", formattedTotalcost='" + formattedTotalcost + '\'' +
				", mwst=" + mwst +
				", formattedMwst='" + formattedMwst + '\'' +
				", hotelTitle='" + hotelTitle + '\'' +
				", hotelName='" + hotelName + '\'' +
				", hotelStreet='" + hotelStreet + '\'' +
				", hotelZipcode='" + hotelZipcode + '\'' +
				", hotelLocation='" + hotelLocation + '\'' +
				", hotelEMail='" + hotelEMail + '\'' +
				", hotelWebsite='" + hotelWebsite + '\'' +
				", regionName='" + regionName + '\'' +
				", regionTitle='" + regionTitle + '\'' +
				", invoiceNumber='" + invoiceNumber + '\'' +
				", singleRawPrice=" + singleRawPrice +
				", formattedSingleRawPrice='" + formattedSingleRawPrice + '\'' +
				'}';
	}

	public Hotelbooking(int id, String startDate, String endDate, int hotelId, int guestId, int roomId, int roomOccupancyId,
						int paymentId, int countAccommodations, double accommodationsRawPrice, String created, String creator, boolean hasData) {
		super(id, startDate, endDate, hotelId, guestId, roomId, created, created, hasData);
		this.roomOccupancyId = roomOccupancyId;
		this.paymentId = paymentId;
		this.countAccommodations = countAccommodations;
		this.accommodationsRawPrice = accommodationsRawPrice;
	}

	public Hotelbooking(String startDate, String endDate, int hotelId, int guestId, int roomId, int roomOccupancyId, 
			int paymentId, int countAccommodations, double accommodationsRawPrice,
			int bookingId, String roomName, String roomTitle, double totalcost, double mwst, String hotelTitle,
			String hotelName, double singleRawPrice, String created, String creator, boolean hasData) {
		super();
		this.roomOccupancyId = roomOccupancyId;
		this.paymentId = paymentId;
		this.countAccommodations = countAccommodations;
		this.accommodationsRawPrice = accommodationsRawPrice;
		this.bookingId = bookingId;
		this.roomName = roomName;
		this.roomTitle = roomTitle;
		this.totalcost = totalcost;
		this.mwst = mwst;
		this.hotelTitle = hotelTitle;
		this.hotelName = hotelName;
		this.singleRawPrice = singleRawPrice;
		this.setCreated(created);
		this.setCreator(creator);
		this.setHasData(hasData);
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	public void setRoomName(String roomName) {
		this.roomName = roomName;
	}

	public void setRoomTitle(String roomTitle) {
		this.roomTitle = roomTitle;
	}

	public void setTotalcost(double totalcost) {
		this.totalcost = totalcost;
	}

	public void setMwst(double mwst) {
		this.mwst = mwst;
	}

	public void setHotelTitle(String hotelTitle) {
		this.hotelTitle = hotelTitle;
	}

	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}

	public void setSingleRawPrice(double singleRawPrice) {
		this.singleRawPrice = singleRawPrice;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Objects.hash(accommodationPositionMwst, accommodationsRawPrice, bookingId,
				countAccommodations, formattedAccommodationsPositionMwst, formattedAccommodationsRawPrice,
				formattedMwst, formattedSingleRawPrice, formattedTotalcost, hotelEMail, hotelLocation, hotelName,
				hotelStreet, hotelTitle, hotelWebsite, hotelZipcode, invoiceNumber, mwst, paymentId, regionName,
				regionTitle, roomName, roomOccupancyId, roomTitle, singleRawPrice, totalcost);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Hotelbooking other = (Hotelbooking) obj;
		return Double.doubleToLongBits(accommodationPositionMwst) == Double
				.doubleToLongBits(other.accommodationPositionMwst)
				&& Double.doubleToLongBits(accommodationsRawPrice) == Double
						.doubleToLongBits(other.accommodationsRawPrice)
				&& bookingId == other.bookingId && countAccommodations == other.countAccommodations
				&& Objects.equals(formattedAccommodationsPositionMwst, other.formattedAccommodationsPositionMwst)
				&& Objects.equals(formattedAccommodationsRawPrice, other.formattedAccommodationsRawPrice)
				&& Objects.equals(formattedMwst, other.formattedMwst)
				&& Objects.equals(formattedSingleRawPrice, other.formattedSingleRawPrice)
				&& Objects.equals(formattedTotalcost, other.formattedTotalcost)
				&& Objects.equals(hotelEMail, other.hotelEMail) && Objects.equals(hotelLocation, other.hotelLocation)
				&& Objects.equals(hotelName, other.hotelName) && Objects.equals(hotelStreet, other.hotelStreet)
				&& Objects.equals(hotelTitle, other.hotelTitle) && Objects.equals(hotelWebsite, other.hotelWebsite)
				&& Objects.equals(hotelZipcode, other.hotelZipcode)
				&& Objects.equals(invoiceNumber, other.invoiceNumber)
				&& Double.doubleToLongBits(mwst) == Double.doubleToLongBits(other.mwst) && paymentId == other.paymentId
				&& Objects.equals(regionName, other.regionName) && Objects.equals(regionTitle, other.regionTitle)
				&& Objects.equals(roomName, other.roomName) && roomOccupancyId == other.roomOccupancyId
				&& Objects.equals(roomTitle, other.roomTitle)
				&& Double.doubleToLongBits(singleRawPrice) == Double.doubleToLongBits(other.singleRawPrice)
				&& Double.doubleToLongBits(totalcost) == Double.doubleToLongBits(other.totalcost);
	}

	public void setRoomOccupancyId(int roomOccupancyId) {
		this.roomOccupancyId = roomOccupancyId;
	}

	public void setPaymentId(int paymentId) {
		this.paymentId = paymentId;
	}

	public void setCountAccommodations(int countAccommodations) {
		this.countAccommodations = countAccommodations;
	}

	public void setAccommodationsRawPrice(double accommodationsRawPrice) {
		this.accommodationsRawPrice = accommodationsRawPrice;
	}

	public void setFormattedAccommodationsRawPrice(String formattedAccommodationsRawPrice) {
		this.formattedAccommodationsRawPrice = formattedAccommodationsRawPrice;
	}

	public void setFormattedTotalcost(String formattedTotalcost) {
		this.formattedTotalcost = formattedTotalcost;
	}

	public void setFormattedSingleRawPrice(String formattedSingleRawPrice) {
		this.formattedSingleRawPrice = formattedSingleRawPrice;
	}

	public void setFormattedMwst(String formattedMwst) {
		this.formattedMwst = formattedMwst;
	}

	public void setHotelStreet(String hotelStreet) {
		this.hotelStreet = hotelStreet;
	}

	public void setHotelWebsite(String hotelWebsite) {
		this.hotelWebsite = hotelWebsite;
	}

	public void setAccommodationPositionMwst(double accommodationPositionMwst) {
		this.accommodationPositionMwst = accommodationPositionMwst;
	}

	public void setFormattedAccommodationsPositionMwst(String formattedAccommodationsPositionMwst) {
		this.formattedAccommodationsPositionMwst = formattedAccommodationsPositionMwst;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

}

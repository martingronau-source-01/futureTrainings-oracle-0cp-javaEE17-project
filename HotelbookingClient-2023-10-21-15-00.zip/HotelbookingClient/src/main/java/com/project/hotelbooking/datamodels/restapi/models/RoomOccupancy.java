package com.project.hotelbooking.datamodels.restapi.models;

import java.sql.Date;
import java.util.Objects;

public class RoomOccupancy {

	private int id = 0;
	private Date startDate;
	private Date endDate;
	private int guestId = 0;
	private int roomId = 0;
	private String creator = "";
	private String created = "";
	private boolean hasData = false;

	public RoomOccupancy() {
		super();		
	}

	public RoomOccupancy(int id, Date startDate, Date endDate, int guestId, int roomId, String creator, String created,
			boolean hasData) {
		super();
		this.id = id;
		this.startDate = startDate;
		this.endDate = endDate;
		this.guestId = guestId;
		this.roomId = roomId;
		this.creator = creator;
		this.created = created;
		this.hasData = hasData;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public int getGuestId() {
		return guestId;
	}

	public void setGuestId(int guestId) {
		this.guestId = guestId;
	}

	public int getRoomId() {
		return roomId;
	}

	public void setRoomId(int roomId) {
		this.roomId = roomId;
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public String getCreated() {
		return created;
	}

	public void setCreated(String created) {
		this.created = created;
	}

	public boolean isHasData() {
		return hasData;
	}

	public void setHasData(boolean hasData) {
		this.hasData = hasData;
	}

	@Override
	public int hashCode() {
		return Objects.hash(id, created, creator, endDate, guestId, hasData, roomId, startDate);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RoomOccupancy other = (RoomOccupancy) obj;
		return id == other.id && Objects.equals(created, other.created) && Objects.equals(creator, other.creator)
				&& Objects.equals(endDate, other.endDate) && guestId == other.guestId && hasData == other.hasData
				&& roomId == other.roomId && Objects.equals(startDate, other.startDate);
	}

	@Override
	public String toString() {
		return "RoomOccupancy [id=" + id + ", startDate=" + startDate + ", endDate=" + endDate + ", guestId=" + guestId
				+ ", roomId=" + roomId + ", creator=" + creator + ", created=" + created + ", hasData=" + hasData + "]";
	}

}

package com.project.hotelbooking.controllers;

import com.project.hotelbooking.Main;
import com.project.hotelbooking.datamodels.restapi.models.Region;
import com.project.hotelbooking.services.RegionService;
import com.project.hotelbooking.utils.Common;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.Optional;

public class RegionController {

    @FXML
    private TextField fldName;

    @FXML
    private TextField fldTitle;
    @FXML
    private TextArea fldDescription;

    @FXML
    private BorderPane regionsPanel;

    @FXML
    private TableView<Region> regionsTable;

    private  RegionService regionService;

    private int currentRegionId = 0;

    public void initialize() {
        regionService = new RegionService();

        if(this.regionsTable != null) {
            regionsTable.setItems(regionService.getRegions());
        } else {
            fldName.requestFocus();
        }
    }
    @FXML
    public void showAddRegionDialog() throws URISyntaxException {
        Dialog<ButtonType> dialog = new Dialog<ButtonType>();
        dialog.initOwner(regionsPanel.getScene().getWindow());
        dialog.setTitle("Region hinzufügen");
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(Main.class.getResource("forms/regiondialog.fxml"));
        try {
            dialog.getDialogPane().setContent(fxmlLoader.load());

        } catch(IOException e) {
            System.out.println("Couldn't load the dialog");
            e.printStackTrace();
            return;
        }

        dialog.getDialogPane().getButtonTypes().add(ButtonType.OK);
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CANCEL);

        RegionController regionController = fxmlLoader.getController();
        final Button okButton = (Button) dialog.getDialogPane().lookupButton(ButtonType.OK);
        okButton.addEventFilter(ActionEvent.ACTION, ae -> {
            if (!regionController.isValidRegion()) {
                ae.consume(); //not valid
            }
        });

        Optional<ButtonType> result = dialog.showAndWait();
        if(result.isPresent() && result.get() == ButtonType.OK) {
            Region newRegion = regionController.getNewRegion();
            currentRegionId = regionService.insertRegion(newRegion);
            regionsTable.setItems(regionService.getRegions());
        }
    }

    public Region getNewRegion() {
        String name = fldName.getText();
        String title = fldTitle.getText();
        String description = fldDescription.getText();

        return new Region(name, title,  description, Common.CREATOR,  Common.CREATED, true);
    }

    public void editRegion(Region region) {
        fldName.setText(region.getName());
        fldTitle.setText(region.getTitle());
        fldDescription.setText(region.getDescription());
    }

    public void updateRegion(Region region) {
        region.setName(fldName.getText());
        region.setTitle(fldTitle.getText());
        region.setDescription(fldDescription.getText());
        region.setHasData(true);
    }

    @FXML
    public void showEditRegionDialog() throws URISyntaxException {
        Region selectedRegion = regionsTable.getSelectionModel().getSelectedItem();
        if(selectedRegion == null) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle(Common.alertMessage.getProperty("confirmRegionTitle"));
            alert.setHeaderText(null);
            alert.setContentText(Common.alertMessage.getProperty("confirmEditRegion"));
            alert.showAndWait();
            return;
        }

        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.initOwner(regionsPanel.getScene().getWindow());
        dialog.setTitle("Region bearbeiten");
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(Main.class.getResource("forms/regiondialog.fxml"));
        try {
            dialog.getDialogPane().setContent(fxmlLoader.load());
        } catch (IOException e) {
            System.out.println("Couldn't load the dialog");
            e.printStackTrace();
            return;
        }

        dialog.getDialogPane().getButtonTypes().add(ButtonType.OK);
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CANCEL);

        RegionController regionController = fxmlLoader.getController();
        regionController.editRegion(selectedRegion);

        final Button okButton = (Button) dialog.getDialogPane().lookupButton(ButtonType.OK);
        okButton.addEventFilter(ActionEvent.ACTION, ae -> {
            if (!regionController.isValidRegion()) {
                ae.consume(); //not valid
            }
        });

        Optional<ButtonType> result = dialog.showAndWait();
        if(result.isPresent() && result.get() == ButtonType.OK) {
            regionController.updateRegion(selectedRegion);

            currentRegionId = regionService.updateRegion(selectedRegion.getId(), selectedRegion);
            regionsTable.refresh();
        }

    }

    public boolean isValidRegion() {
        boolean bReturn = true;
        Common.isWarningMessage = true;

        if (fldName.getText().isEmpty()) {
            Common.showValidationMessage("Das Feld Name  darf nicht leer bleiben");
            bReturn = false;
            fldName.requestFocus();
        } else if (fldTitle.getText().isEmpty()) {
            Common.showValidationMessage("Das Feld Titel  darf nicht leer bleiben");
            bReturn = false;
            fldTitle.requestFocus();
        }

        return bReturn;
    }

    @FXML
    public void deleteRegion() throws URISyntaxException {
        Region selectedRegion = regionsTable.getSelectionModel().getSelectedItem();
        if (selectedRegion == null) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle(Common.alertMessage.getProperty("confirmRegionTitle"));
            alert.setHeaderText(null);
            alert.setContentText(Common.alertMessage.getProperty("confirmDeleteRegion"));
            alert.showAndWait();
            return;
        }
        Alert alert = new Alert(Alert.AlertType.NONE,
                "Möchten Sie die Region '"+selectedRegion.getTitle()+"' wirklich löschen?",
                Common.YES, Common.NO);

        alert.setTitle("Lösch-Bestätigung!");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.orElse(Common.NO) == Common.YES) {
            regionService.deleteRegion(selectedRegion.getId());
            regionsTable.setItems(regionService.getRegions());
            regionsTable.refresh();
        }
    }
}

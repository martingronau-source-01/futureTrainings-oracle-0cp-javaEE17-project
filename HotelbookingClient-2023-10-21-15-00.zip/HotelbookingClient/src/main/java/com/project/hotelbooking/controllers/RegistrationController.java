package com.project.hotelbooking.controllers;

import com.project.hotelbooking.components.LookupCell;
import com.project.hotelbooking.datamodels.restapi.models.Guest;
import com.project.hotelbooking.datamodels.restapi.models.Login;
import com.project.hotelbooking.datamodels.restapi.models.Lookup;
import com.project.hotelbooking.datamodels.restapi.models.Role;
import com.project.hotelbooking.services.RoleService;
import com.project.hotelbooking.utils.Common;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.time.LocalDate;

public class RegistrationController {

    @FXML
    public GridPane testRegistrationMainPanel;

    @FXML
    private Button btnOk;

    @FXML
    private Button btnCancel = new Button();

     @FXML
     private TextField fldUsername;

    @FXML
    private TextField fldLoginname;

    @FXML
    private PasswordField fldPassword;
    @FXML
    private PasswordField fldPasswordRepeat;
    @FXML
    private ComboBox<Lookup> fldRole;
    private ObservableList<Lookup> listRoles;

    @FXML
    private GridPane registrationGuestDataPanel;
    @FXML
    private GridPane registrationLoginDataPanel;

    @FXML
    private TextField fldFirstName;

    @FXML
    private TextField fldLastName;

    @FXML
    private DatePicker fldBirthDate;

    @FXML
    private TextField fldStreet;

    @FXML
    private TextField fldZipcode;

    @FXML
    private TextField fldLocation;

    @FXML
    private TextField fldEMail;

    @FXML
    private TextField fldPhone;

    @FXML
    private CheckBox fldBusiness;
    @FXML
    private CheckBox fldRegularCustomer;
    @FXML
    private Tab tabLoginData;
    @FXML
    private Tab tabUserData;
    @FXML
    private TabPane tabPaneRegistrationDialog;

    public void initialize() {

        fldBirthDate.setValue(LocalDate.now());

        registrationGuestDataPanel.setPadding(new Insets(30, 25, 15, 35));
        registrationLoginDataPanel.setPadding(new Insets(30, 25, 15, 35));

        btnCancel. setOnAction(actionEvent  -> {
            // close the dialog.
            Node source = (Node)  actionEvent.getSource();
            Stage stage  = (Stage) source.getScene().getWindow();
            stage.close();
        });

        listRoles = FXCollections.observableArrayList();
        RoleService roleService = new RoleService();

        for (Role role : roleService.getRoles()) {
            listRoles.add(new Lookup(role.getId(), role.getDescription()));
        }

        fldRole.setCellFactory(lookups -> new LookupCell());
        fldRole.setButtonCell(new LookupCell());
        fldRole.setItems(listRoles);
        fldRole.setValue(listRoles.get(0));
    }

    public boolean isValidGuest() {
        boolean bReturn = true;
        Common.isWarningMessage = true;

        if(fldFirstName.getText().isEmpty()) {
            Common.showValidationMessage("Das Feld Vorname  darf nicht leer bleiben");
            bReturn = false;
            tabPaneRegistrationDialog.getSelectionModel().select(tabUserData);
            fldFirstName.requestFocus();
        } else if(fldLastName.getText().isEmpty()) {
            Common.showValidationMessage("Das Feld Nachname  darf nicht leer bleiben");
            bReturn = false;
            tabPaneRegistrationDialog.getSelectionModel().select(tabUserData);
            fldLastName.requestFocus();
        }  else if(fldStreet.getText().isEmpty()) {
            Common.showValidationMessage("Das Feld Strasse darf nicht leer bleiben");
            bReturn = false;
            tabPaneRegistrationDialog.getSelectionModel().select(tabUserData);
            fldStreet.requestFocus();
        }  else if(fldZipcode.getText().isEmpty()) {
            Common.showValidationMessage("Das Feld PLZ darf nicht leer bleiben");
            bReturn = false;
            tabPaneRegistrationDialog.getSelectionModel().select(tabUserData);
            fldZipcode.requestFocus();
        }  else if(fldLocation.getText().isEmpty()) {
            Common.showValidationMessage("Das Feld Ort darf nicht leer bleiben");
            bReturn = false;
            tabPaneRegistrationDialog.getSelectionModel().select(tabUserData);
            fldLocation.requestFocus();
        }  else if(fldEMail.getText().isEmpty()) {
            Common.showValidationMessage("Das Feld EMail darf nicht leer bleiben");
            bReturn = false;
            tabPaneRegistrationDialog.getSelectionModel().select(tabUserData);
            fldEMail.requestFocus();
        }

        return bReturn;
    }

    public boolean isValidRegistration() {
        boolean bReturn;

        bReturn = isValidGuest();

        if(bReturn) {
            bReturn = isValidLogin();
        }

        return bReturn;
    }


    private boolean isValidLogin() {
        boolean bReturn = true;
        Common.isWarningMessage = true;

        if(fldUsername.getText().isEmpty()) {
            Common.showValidationMessage("Das Feld Benutzername  darf nicht leer bleiben");
            bReturn = false;
            tabPaneRegistrationDialog.getSelectionModel().select(tabLoginData);
            fldUsername.requestFocus();
        } else if(fldLoginname.getText().isEmpty()) {
            Common.showValidationMessage("Das Feld Anmeldename  darf nicht leer bleiben");
            bReturn = false;
            tabPaneRegistrationDialog.getSelectionModel().select(tabLoginData);
            fldLoginname.requestFocus();
        } else if(fldPassword.getText().isEmpty()) {
            Common.showValidationMessage("Das Feld Kennwort  darf nicht leer bleiben");
            bReturn = false;
            tabPaneRegistrationDialog.getSelectionModel().select(tabLoginData);
            fldPassword.requestFocus();
        }  else if(fldPasswordRepeat.getText().isEmpty()) {
            Common.showValidationMessage("Das Feld Kennwort-Wiederholung  darf nicht leer bleiben");
            bReturn = false;
            tabPaneRegistrationDialog.getSelectionModel().select(tabLoginData);
            fldPasswordRepeat.requestFocus();
        }   else if(!fldPassword.getText().equals(fldPasswordRepeat.getText())) {
            Common.showValidationMessage("Die Felder Kennwort und Kennwort-Wiederholung stimmen nicht überein");
            bReturn = false;
            tabPaneRegistrationDialog.getSelectionModel().select(tabLoginData);

            fldPassword.setText("");
            fldPasswordRepeat.setText("");

            fldPassword.requestFocus();
        }

        return bReturn;
    }

    public Login getNewLogin() {
        String username = fldUsername.getText();
        String loginName = fldLoginname.getText();
        String password = fldPassword.getText();
        Lookup role = fldRole.getSelectionModel().getSelectedItem();

        int guestId = 0;
        String salt = "";
        boolean hasData = true;
        boolean registered = true;

        return new Login(username,loginName,password,salt,role.getId(),registered,
                guestId, Common.CREATOR, Common.CREATED, hasData);
    }

    public Guest getNewGuest() {
        String firstName = fldFirstName.getText();
        String lastName = fldLastName.getText();
        String birthDate = fldBirthDate.getValue().toString();
        String street = fldStreet.getText();
        String zipcode = fldZipcode.getText();
        String location = fldLocation.getText();
        String email = fldEMail.getText();
        String phone = fldPhone.getText();
        boolean isBusiness = fldBusiness.isSelected();
        boolean isRegularCustomer = fldRegularCustomer.isSelected();

        return new Guest(firstName, lastName,  birthDate, street, zipcode, location, email, phone,
                isBusiness,isRegularCustomer, Common.CREATOR,  Common.CREATED, true);
    }

}

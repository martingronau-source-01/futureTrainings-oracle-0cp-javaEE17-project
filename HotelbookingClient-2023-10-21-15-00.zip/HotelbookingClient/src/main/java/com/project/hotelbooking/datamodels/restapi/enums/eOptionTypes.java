package com.project.hotelbooking.datamodels.restapi.enums;

public enum eOptionTypes {
	NO_OPTION(0), HOTEL_OPTION(1), ROOM_FEATURE(2), PAYMENT_OPTION(3);

	private final int value;

	eOptionTypes(int value) {
		this.value = value;
	}

	public int getValue() {
		return value;
	}
}

package com.project.hotelbooking.playground;

import com.project.hotelbooking.datamodels.restapi.models.Lookup;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

import java.util.Objects;

public class RadioButtonListView extends Application {

    public static final ObservableList<Lookup> names = FXCollections.observableArrayList();
    private final ToggleGroup group = new ToggleGroup();

    private Lookup selectedName ;

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("List View Sample");

        ListView<Lookup> listView = new ListView<>();
        listView.setPrefSize(200, 250);
        listView.setEditable(true);

        names.addAll(new Lookup(1,"Adam"), new Lookup(2,"Alex"), new Lookup(3,"Alfred"),
                new Lookup(4, "Albert"), new Lookup(5,"Brenda"), new Lookup(6, "Connie"),
                new Lookup(7, "Derek"), new Lookup(8,"Donny"), new Lookup(9, "Lynne"),
                new Lookup(10,"Myrtle"), new Lookup(11,"Rose"), new Lookup(12, "Rudolph"),
                new Lookup(13,"Tony"), new Lookup(14, "Trudy"), new Lookup(15, "Williams"),
                new Lookup(16, "Zach"));

        listView.setItems(names);
        //radioListCell
        listView.setCellFactory(param -> new RadioListCell(listView));

        StackPane root = new StackPane();
        root.getChildren().add(listView);
        primaryStage.setScene(new Scene(root, 200, 250));
        primaryStage.show();

    }

    public static void main(String[] args) {
        launch(args);
    }

    private class RadioListCell extends ListCell<Lookup> {

        private final RadioButton radioButton = new RadioButton();

        RadioListCell(ListView listView) {
            radioButton.setToggleGroup(group);
            radioButton.selectedProperty().addListener((obs, wasSelected, isNowSelected) -> {
                if (isNowSelected) {
                    selectedName = getItem();
                    System.out.println(selectedName);
                    listView.getSelectionModel().select(selectedName);

                } else if(wasSelected) {
                    System.out.println(wasSelected);
                }
            });
        }

        @Override
        public void updateItem(Lookup obj, boolean empty) {
            super.updateItem(obj, empty);
            if (empty) {
                setText(null);
                setGraphic(null);
            } else {
                radioButton.setText(obj.getTitle());

                radioButton.setSelected(Objects.equals(obj, selectedName));

                setGraphic(radioButton);
            }
        }
    }

}
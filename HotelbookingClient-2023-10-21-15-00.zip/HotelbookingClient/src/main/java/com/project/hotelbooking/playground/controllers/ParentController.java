package com.project.hotelbooking.playground.controllers;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.VBox;

import java.io.IOException;

public class ParentController {

    @FXML
    private VBox childContainer;

    @FXML
    private void initialize() {
        try {
            FXMLLoader childLoader = new FXMLLoader(getClass().getResource("forms/playground/Child.fxml"));
            VBox childNode = childLoader.load();
            ChildController childController = childLoader.getController();
            // Do something with the child node and controller
            childContainer.getChildren().add(childNode);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

package com.project.hotelbooking.controllers;

import com.project.hotelbooking.Main;
import com.project.hotelbooking.datamodels.restapi.models.CheckBoxLookup;
import com.project.hotelbooking.datamodels.restapi.models.Lookup;
import com.project.hotelbooking.datamodels.restapi.models.Room;
import com.project.hotelbooking.datamodels.restapi.models.RoomFeature;
import com.project.hotelbooking.services.RoomFeatureService;
import com.project.hotelbooking.services.RoomService;
import com.project.hotelbooking.utils.Common;
import javafx.beans.InvalidationListener;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.control.cell.CheckBoxListCell;
import javafx.scene.layout.BorderPane;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class RoomFeatureController {
    @FXML
    private Accordion accordion;
    @FXML
    private BorderPane roomFeaturesPanel;
    @FXML
    private TableView<RoomFeature> roomFeaturesTable;
    RoomFeatureService roomFeatureService;
    RoomService roomService;
    private ObservableList<Lookup> listRooms;

    @FXML
    private TextField fldName;

    @FXML
    private TextField fldTitle;
    @FXML
    private TextArea fldDescription;
    @FXML
    private ListView<CheckBoxLookup> listviewRooms;
    @FXML
    private TitledPane fldRooms;
    private ObservableList<CheckBoxLookup> rooms;

    private int currentRoomFeatureId;

    public void initialize() {
        roomFeatureService = new RoomFeatureService();
        roomService = new RoomService();

        rooms = FXCollections.observableArrayList();

        if(roomFeaturesTable != null) {
            roomFeaturesTable.setItems(roomFeatureService.getRoomFeatures());
        }  else {
            listRooms = FXCollections.observableArrayList();
            RoomService roomService = new RoomService();

            for(Room room : roomService.getRooms()) {
                listRooms.add(new Lookup(room.getId(), room.getName()));
            }
             listviewRooms.setCellFactory(factory -> {
                CheckBoxListCell<CheckBoxLookup> cell = new CheckBoxListCell<CheckBoxLookup>() {
                    // a listener on the graphicProperty: it installs the "real" listener
                    final InvalidationListener graphicListener = g -> {
                        // installs the "real" listener on the graphic control once it is available
                        registerUIListener();
                    };

                    {
                        // install the graphic listener at instantiation
                        graphicProperty().addListener(graphicListener);
                    }

                    private void registerUIListener() {
                        if (!(getGraphic() instanceof CheckBox)) throw new IllegalStateException("checkBox expected");
                        graphicProperty().removeListener(graphicListener);
                        ((CheckBox) getGraphic()).selectedProperty().addListener(
                                (observable, oldValue, newValue) -> listviewRooms.getSelectionModel().select(getItem()));
                    }
                };
                cell.setSelectedStateCallback(CheckBoxLookup::selectedProperty);
                return cell;
            });

            for (Room room : roomService.getRooms()) {
                rooms.add( new CheckBoxLookup(room.getName(), false, room.getId()));
            }
            listviewRooms.setItems(rooms);
            accordion.setExpandedPane(fldRooms);

            fldName.requestFocus();
        }

    }
    @FXML
    public void showAddRoomFeatureDialog() throws URISyntaxException {
        Dialog<ButtonType> dialog = new Dialog<ButtonType>();
        dialog.initOwner(roomFeaturesPanel.getScene().getWindow());
        dialog.setTitle("Room-Feature hinzufügen");
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(Main.class.getResource("forms/roomfeaturedialog.fxml"));
        try {
            dialog.getDialogPane().setContent(fxmlLoader.load());

        } catch(IOException e) {
            System.out.println("Couldn't load the dialog");
            e.printStackTrace();
            return;
        }

        dialog.getDialogPane().getButtonTypes().add(ButtonType.OK);
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CANCEL);

        RoomFeatureController roomFeatureController = fxmlLoader.getController();
        final Button okButton = (Button) dialog.getDialogPane().lookupButton(ButtonType.OK);
        okButton.addEventFilter(ActionEvent.ACTION, ae -> {
            if (!roomFeatureController.isValidRoomFeature()) {
                ae.consume(); //not valid
            }
        });

        Optional<ButtonType> result = dialog.showAndWait();
        if(result.isPresent() && result.get() == ButtonType.OK) {
            RoomFeature newRoomFeature = roomFeatureController.getNewRoomFeature();
            currentRoomFeatureId = roomFeatureService.insertRoomFeature(newRoomFeature);
            roomFeaturesTable.setItems(roomFeatureService.getRoomFeatures());
        }
    }

    public RoomFeature getNewRoomFeature() {
        String name = fldName.getText();
        String title = fldTitle.getText();
        String description = fldDescription.getText();

        RoomFeature roomFeature = new RoomFeature(0,name, title,  description, Common.CREATOR,
                Common.CREATED, true);

        List<Integer> selectedRoomIds = new ArrayList<>();
        for(CheckBoxLookup item :  listviewRooms.getItems()) {
            if(item.isSelected())    {
                selectedRoomIds.add(item.getId());
            }
        }
        roomFeature.setRoomIds(selectedRoomIds);

        return roomFeature;

    }

    public void editRoomFeature(RoomFeature roomFeature) {
        fldName.setText(roomFeature.getName());
        fldTitle.setText(roomFeature.getTitle());
        fldDescription.setText(roomFeature.getDescription());

        ObservableList<Room> roomsList = roomService.getRoomsByRoomFeature(roomFeature.getOptionId());

        for (CheckBoxLookup lookup : listviewRooms.getItems()) {
            lookup.setSelected(roomsList.stream().anyMatch(h -> h.getId() == lookup.getId()));
        }

    }

    public void updateRoomFeature(RoomFeature roomFeature) {
        roomFeature.setName(fldName.getText());
        roomFeature.setTitle(fldTitle.getText());
        roomFeature.setDescription(fldDescription.getText());

        List<Integer> selectedRoomIds = new ArrayList<>();
        for(CheckBoxLookup item :  listviewRooms.getItems()) {
            if(item.isSelected())    {
                selectedRoomIds.add(item.getId());
            }
        }
        roomFeature.setRoomIds(selectedRoomIds);
    }

    @FXML
    public void showEditRoomFeatureDialog() throws URISyntaxException {
        RoomFeature selectedRoomFeature = roomFeaturesTable.getSelectionModel().getSelectedItem();
        if(selectedRoomFeature == null) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle(Common.alertMessage.getProperty("confirmRoomFeatureTitle"));
            alert.setHeaderText(null);
            alert.setContentText(Common.alertMessage.getProperty("confirmEditRoomFeature"));
            alert.showAndWait();
            return;
        }

        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.initOwner(roomFeaturesPanel.getScene().getWindow());
        dialog.setTitle("Room Feature bearbeiten");
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(Main.class.getResource("forms/roomfeaturedialog.fxml"));
        try {
            dialog.getDialogPane().setContent(fxmlLoader.load());
        } catch (IOException e) {
            System.out.println("Couldn't load the dialog");
            e.printStackTrace();
            return;
        }

        dialog.getDialogPane().getButtonTypes().add(ButtonType.OK);
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CANCEL);

        RoomFeatureController roomFeatureController = fxmlLoader.getController();
        roomFeatureController.editRoomFeature(selectedRoomFeature);

        final Button okButton = (Button) dialog.getDialogPane().lookupButton(ButtonType.OK);
        okButton.addEventFilter(ActionEvent.ACTION, ae -> {
            if (!roomFeatureController.isValidRoomFeature()) {
                ae.consume(); //not valid
            }
        });

        Optional<ButtonType> result = dialog.showAndWait();
        if(result.isPresent() && result.get() == ButtonType.OK) {

            roomFeatureController.updateRoomFeature(selectedRoomFeature);
            currentRoomFeatureId = roomFeatureService.updateRoomFeature(
                    selectedRoomFeature.getOptionType(),  selectedRoomFeature.getOptionId(), selectedRoomFeature);
            roomFeaturesTable.setItems(roomFeatureService.getRoomFeatures());
            roomFeaturesTable.refresh();
        }

    }

    public boolean isValidRoomFeature() {
        boolean bReturn = true;
        Common.isWarningMessage = true;

        if (fldName.getText().isEmpty()) {
            Common.showValidationMessage("Das Feld Name  darf nicht leer bleiben");
            bReturn = false;
            fldName.requestFocus();
        } else if (fldTitle.getText().isEmpty()) {
            Common.showValidationMessage("Das Feld Titel  darf nicht leer bleiben");
            bReturn = false;
            fldTitle.requestFocus();
        }

        return bReturn;
    }


    @FXML
    public void deleteRoomFeature() throws URISyntaxException {
        RoomFeature selectedRoomFeature = roomFeaturesTable.getSelectionModel().getSelectedItem();
        if(selectedRoomFeature == null) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle(Common.alertMessage.getProperty("confirmRoomFeatureTitle"));
            alert.setHeaderText(null);
            alert.setContentText(Common.alertMessage.getProperty("confirmDeleteRoomFeature"));
            alert.showAndWait();
            return;
        }
        Alert alert = new Alert(Alert.AlertType.NONE,
                "Möchten Sie das Zimmer Feature '"+selectedRoomFeature.getTitle()+"' wirklich löschen?",
                Common.YES, Common.NO);

        alert.setTitle("Lösch-Bestätigung!");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.orElse(Common.NO) == Common.YES) {
            roomFeatureService.deleteRoomFeature(selectedRoomFeature.getOptionType(), selectedRoomFeature.getOptionId());
            roomFeaturesTable.setItems(roomFeatureService.getRoomFeatures());
            roomFeaturesTable.refresh();
        }
    }
}

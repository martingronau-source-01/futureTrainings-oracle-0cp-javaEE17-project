package com.project.hotelbooking.services;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.project.hotelbooking.datamodels.restapi.enums.eHttpStatusCodes;
import com.project.hotelbooking.datamodels.restapi.models.Role;
import com.project.hotelbooking.utils.Common;
import com.project.hotelbooking.utils.SystemSecure;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;

import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.List;

public class RoleService extends RestApiService {
    private final String rolesURI;
    private final Gson gson;

    public RoleService() {
        super();
        gson= new Gson();

        SystemSecure systemSecure = new SystemSecure();

        String sBaseURI = systemSecure.getRestApiConnectionUri();
        rolesURI = sBaseURI+systemSecure.getDelimiter()+"roles"+systemSecure.getDelimiter();
    }

    public ObservableList<Role> getRoles() {
        HttpResponse<String> getResponse = this.sendGetRequest(rolesURI);
        if(getResponse.statusCode() == eHttpStatusCodes.HTTP_OK.getValue()) {
            List<Role> roles = gson.fromJson(getResponse.body(), new TypeToken<ArrayList<Role>>() {
            }.getType());

            return FXCollections.observableList(roles);
        } else if(getResponse.statusCode() == eHttpStatusCodes.HTTP_NO_CONTENT.getValue()) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle(Common.alertMessage.getProperty("informationNoDataTitle"));
            alert.setHeaderText(null);
            alert.setContentText(Common.alertMessage.getProperty("informationNoRolesData"));
            alert.showAndWait();

            return  null;
        } else {
            return null;
        }
    }

}

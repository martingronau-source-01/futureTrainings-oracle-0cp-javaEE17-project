package com.project.hotelbooking.controllers;

import com.project.hotelbooking.controllers.tabpanels.TabAvailableHotelRoomsController;
import com.project.hotelbooking.controllers.tabpanels.TabHotelContactDataController;
import com.project.hotelbooking.controllers.tabpanels.TabHotelOptionsController;
import com.project.hotelbooking.controllers.tabpanels.TabPaymentOptionsController;
import com.project.hotelbooking.datamodels.restapi.enums.ePaymentTypes;
import com.project.hotelbooking.datamodels.restapi.models.AccommodationSearchResult;
import com.project.hotelbooking.datamodels.restapi.models.Guest;
import com.project.hotelbooking.datamodels.restapi.models.Hotelbooking;
import com.project.hotelbooking.datamodels.restapi.models.Lookup;
import com.project.hotelbooking.services.GuestService;
import com.project.hotelbooking.services.HotelbookingService;
import com.project.hotelbooking.services.MailSendService;
import com.project.hotelbooking.utils.Common;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.control.TabPane;

import java.net.URISyntaxException;
import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;

public class AccommodationDetailsMainController implements Initializable {
    @FXML
    private TabPane tabPaneRoot;
    @FXML
    private TabHotelOptionsController tabHotelOptionsController;
    @FXML
    private TabPaymentOptionsController tabPaymentOptionsController;
    @FXML
    private TabHotelContactDataController tabHotelContactDataController;
    @FXML
    private TabAvailableHotelRoomsController tabAvailableHotelRoomsController;


    @Override
    public void initialize(URL location, ResourceBundle resources) {

        tabPaneRoot.setPadding(new Insets(15, 25, 15, 25));
        tabPaneRoot.getSelectionModel().selectFirst();
    }

    public void showAccommodationDetail(AccommodationSearchResult accommodationSearchResult) {
        tabHotelContactDataController.showAccommodationDetail(accommodationSearchResult);
        tabHotelOptionsController.showAccommodationDetail(accommodationSearchResult);
        tabPaymentOptionsController.showAccommodationDetail(accommodationSearchResult);
        tabAvailableHotelRoomsController.showAccommodationDetail(accommodationSearchResult);
    }

    public void generateHotelBooking(AccommodationSearchResult accommodationSearchResult) throws URISyntaxException {

        Hotelbooking hotelbooking = new Hotelbooking();
        boolean hasAttachment = false;

        hotelbooking.setHotelId(accommodationSearchResult.getHotelId());
        hotelbooking.setGuestId(Common.guestId);
        hotelbooking.setCountAccommodations(accommodationSearchResult.getCountAccommodations());
        hotelbooking.setStartDate(accommodationSearchResult.getStartDate());
        hotelbooking.setEndDate(accommodationSearchResult.getEndDate());
        hotelbooking.setCreator(Common.CREATOR);
        hotelbooking.setCreated(Common.CREATED);
        hotelbooking.setHasData(true);

        Lookup curPaymentOption = tabPaymentOptionsController.listviewPaymentOptions.getSelectionModel().getSelectedItem();
        Lookup curAvailableHotelRooms = tabAvailableHotelRoomsController.listviewAvailableHotelRooms.getSelectionModel().getSelectedItem();

        if (curAvailableHotelRooms != null && curAvailableHotelRooms.getId() > 0) {
            hotelbooking.setRoomId(curAvailableHotelRooms.getId());
        }

        if (curPaymentOption != null && curPaymentOption.getId() == ePaymentTypes.INVOICE_PAYMENT.getValue()
                || (curPaymentOption != null && curPaymentOption.getId() == ePaymentTypes.BANK_TRANSFER_PAYMENT.getValue())) {
            hasAttachment = true;
        }
        HotelbookingService hotelbookingService = new HotelbookingService();
        int hotelBookingID = hotelbookingService.bookAccomodation(hotelbooking);

        Hotelbooking newHotelbooking = hotelbookingService.getHotelbooking(hotelBookingID);
        sendSubmitMessageOnHotelBooking(accommodationSearchResult, newHotelbooking, hasAttachment);
    }

    private void sendSubmitMessageOnHotelBooking(AccommodationSearchResult accommodationSearchResult,
                                                 Hotelbooking hotelbooking, boolean hasAttachment) {

        GuestService guestService = new GuestService();

        Guest guest = guestService.getGuest(Common.guestId);

        LocalDate startDate = LocalDate.parse(accommodationSearchResult.getStartDate(), Common.CUSTOM_FORMATTER_SHORT);
        LocalDate endDate = LocalDate.parse(accommodationSearchResult.getEndDate(), Common.CUSTOM_FORMATTER_SHORT);

        hotelbooking.setStartDate(startDate.format(Common.CUSTOM_FORMATTER_GERMAN_SHORT));
        hotelbooking.setEndDate(endDate.format(Common.CUSTOM_FORMATTER_GERMAN_SHORT));

        MailSendService mailSendService = new MailSendService(guest, hotelbooking, hasAttachment);

        mailSendService.setEmailRecipient(guest.getEmail());

        mailSendService.setEmailFromAdress(!accommodationSearchResult.getHotelEMail().isEmpty() ?
                accommodationSearchResult.getHotelEMail() : Common.DEFAULT_MAIL_FROM_ADDRESS);

        mailSendService.setMessageSubject("Bestätigung Ihrer gebuchten Übernachtungen!");
        mailSendService.setEmailContentType("text/html;");

        StringBuilder sbMessageBody = new StringBuilder("<div class=\"mailtext\">")
                .append("<p stype='margin-top: 3rem'>").append(accommodationSearchResult.getHotelName())
                .append(" (").append(accommodationSearchResult.getHotelTitle()).append(")</p>")
                .append("<p>").append(accommodationSearchResult.getHotelStreet()).append("</p>")
                .append("<p>").append(accommodationSearchResult.getHotelZipcode()).append(" ")
                .append(accommodationSearchResult.getHotelLocation()).append("</p>")
                .append("<p style='margin-bottom: 5rem'>").append(accommodationSearchResult.getHotelWebsite())
                .append("</p>")
                .append("<p style='margin-top: 2rem; margin-right: 0; margin-bottom: 5rem; margin-left: 24rem;'>")
                .append(accommodationSearchResult.getHotelLocation()).append(", ")
                .append(LocalDate.now().format(Common.CUSTOM_FORMATTER_GERMAN_SHORT)).append("</p>")
                .append("<p> Guten Tag ").append(guest.getFirstName() + " " + guest.getLastName() + ",</p>")
                .append("<p style='margin-top:1.75rem'>hiermit bestätigen wir Ihre gebuchten Übernachtungen vom ")
                .append(startDate.format(Common.CUSTOM_FORMATTER_GERMAN_SHORT))
                .append(" bis ").append(endDate.format(Common.CUSTOM_FORMATTER_GERMAN_SHORT))
                .append("</p>").append("<p> in der Unterkunft '").append(accommodationSearchResult.getHotelName()).append("' - (")
                .append(accommodationSearchResult.getHotelTitle()).append(")</p>").append("<p>in unserer wunderschönen Region ")
                .append(accommodationSearchResult.getRegionTitle()).append(".</p>");

        if (hasAttachment) {
            sbMessageBody.append("<p>Bitte begleichen Sie umgehend den fälligen Gesamtbetrag von ")
                    .append(hotelbooking.getFormattedTotalcost()).append("</p><p> auf das in der beiliegenden Rechnung")
                    .append(" aufgeführte Geschäftskonto. Vielen Dank.</p>");
        }

        sbMessageBody.append("<p style='margin-top: 4rem'>Mit besten Grüßen</p>")
                .append("<p style='margin-top: 1.5rem'>Ihre Hotelleitung ").append(accommodationSearchResult.getHotelName())
                .append("</p><p>").append(accommodationSearchResult.getHotelZipcode()).append(" ")
                .append(accommodationSearchResult.getHotelLocation()).append("</p>")
                .append(".</div");

        mailSendService.setGuest(guest);
        mailSendService.setMessageBodyHtml(sbMessageBody.toString());

        mailSendService.sendEMail();
    }
}

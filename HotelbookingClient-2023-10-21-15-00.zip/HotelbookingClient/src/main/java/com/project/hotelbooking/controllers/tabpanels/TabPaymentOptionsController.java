package com.project.hotelbooking.controllers.tabpanels;

import com.project.hotelbooking.datamodels.restapi.models.AccommodationSearchResult;
import com.project.hotelbooking.datamodels.restapi.models.Lookup;
import com.project.hotelbooking.datamodels.restapi.models.PaymentOption;
import com.project.hotelbooking.services.PaymentOptionService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.GridPane;

import java.net.URL;
import java.util.Objects;
import java.util.ResourceBundle;

public class TabPaymentOptionsController implements Initializable {

    @FXML
    private GridPane paymentOptionsPanel;
    private PaymentOptionService paymentOptionService;
    private ToggleGroup toggleGroup;
    private ObservableList<Lookup> paymentOptions;

    @FXML
    public ListView<Lookup> listviewPaymentOptions;

    private Lookup selectedLookup;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        paymentOptionsPanel.setPadding(new Insets(10,20,10,20));
   
        paymentOptionService = new PaymentOptionService();
        paymentOptions = FXCollections.observableArrayList();

        toggleGroup = new ToggleGroup();
    }

    public void showAccommodationDetail(AccommodationSearchResult accommodationSearchResult) {

        for (PaymentOption paymentOption : paymentOptionService.getPaymentOptions()) {
            paymentOptions.add(new Lookup(paymentOption.getOptionId(), paymentOption.getTitle()));
        }

        listviewPaymentOptions.setItems(paymentOptions);
        listviewPaymentOptions.setCellFactory(param -> new RadioLookupCell());
        listviewPaymentOptions.getSelectionModel().selectFirst();

        selectedLookup = listviewPaymentOptions.getItems().get(0);
    }

    private class RadioLookupCell extends ListCell<Lookup> {

        private final RadioButton radioButton = new RadioButton();

        RadioLookupCell() {
            radioButton.setToggleGroup(toggleGroup);
            radioButton.setSelected(true);

            radioButton.selectedProperty().addListener((obs, wasSelected, isNowSelected) -> {
                if (isNowSelected) {
                    selectedLookup = getItem();
                    listviewPaymentOptions.getSelectionModel().select(selectedLookup);
                }
            });
        }

        @Override
        public void updateItem(Lookup obj, boolean empty) {
            super.updateItem(obj, empty);
            if (empty) {
                setText(null);
                setGraphic(null);
            } else {
                radioButton.setText(obj.getTitle());
                radioButton.setSelected(Objects.equals(obj, selectedLookup));
                setGraphic(radioButton);
            }
        }
    }

}

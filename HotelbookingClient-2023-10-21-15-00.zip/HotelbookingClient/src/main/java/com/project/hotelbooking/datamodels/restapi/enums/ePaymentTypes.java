package com.project.hotelbooking.datamodels.restapi.enums;

public enum ePaymentTypes {

    NO_PAYMENT(0), CASH_PAYMENT(10), CREDITCARD_PAYMENT(16), BANK_TRANSFER_PAYMENT(9),
    EC_CARD_PAYMENT(10), INVOICE_PAYMENT(11) ;
    private final int value;

    ePaymentTypes(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }
}

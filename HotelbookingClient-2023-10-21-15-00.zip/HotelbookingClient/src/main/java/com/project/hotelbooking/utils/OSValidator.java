package com.project.hotelbooking.utils;

public class OSValidator {

	private static final String OS = System.getProperty("os.name").toLowerCase();

	public static void main(String[] args) {

		OSValidator os = new OSValidator();
		if (os.isWindows()) {
			System.out.println("This is Windows");
		} else if (os.isMac()) {
			System.out.println("This is MacOS");
		} else if (os.isUnix()) {
			System.out.println("This is Unix or Linux");
		} else if (os.isSolaris()) {
			System.out.println("This is Solaris");
		} else {
			System.out.println("Your OS is not supported!!");
		}
	}

	public boolean isWindows() {
		return OS.contains("win");
	}

	public boolean isMac() {
		return OS.contains("mac");
	}

	public boolean isUnix() {
		return (OS.contains("nix") || OS.contains("nux") || OS.contains("aix"));
	}

	public boolean isSolaris() {
		return OS.contains("sunos");
	}

	public String getOS() {
		if (isWindows()) {
			return "win";
		} else if (isMac()) {
			return "osx";
		} else if (isUnix()) {
			return "uni";
		} else if (isSolaris()) {
			return "sol";
		} else {
			return "err";
		}
	}

}

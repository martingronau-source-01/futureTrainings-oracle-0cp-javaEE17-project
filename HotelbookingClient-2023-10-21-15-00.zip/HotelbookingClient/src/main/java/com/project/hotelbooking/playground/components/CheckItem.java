package com.project.hotelbooking.playground.components;

import lombok.Getter;

public class CheckItem {
    private boolean selected;
    @Getter
    private String displayName;
    @Getter
    private String internalName;

    public boolean isChecked() {
        return selected;
    }

    public void setChecked(boolean checked) {
        this.selected = checked;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public void setInternalName(String internalName) {
        this.internalName = internalName;
    }
}
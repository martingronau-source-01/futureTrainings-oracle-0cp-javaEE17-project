package com.project.hotelbooking.utils;

import lombok.Getter;

import java.io.*;
import java.net.*;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.text.NumberFormat;
import java.text.ParsePosition;
import java.util.Properties;

@Getter
public class SystemSecure {
	private String sPepper = "";

	private static final String CONFIG_FILE = "config.properties";
	private static final String API_CONFIG_FILE = "restapi.properties";
	private static final String URI_PORT_DELIMITER = ":";

	private static final Path resourceDirectory = Paths.get("src", "main", "resources",
			"com", "project", "hotelbooking", "config");
	private static final String sConfigPath = resourceDirectory.toFile().getAbsolutePath();

	private static String sConfigResource = "";
	
	private String workStation = "";

	public void setDelimiter(String delimiter) {
		Delimiter = delimiter;
	}

	@Getter
	private String Delimiter = "";

	private final OSValidator os;

	private boolean netIsAvailable(String uriAddress) {
		try {
			final URL url = new URL(uriAddress);
			final URLConnection conn = url.openConnection();
			conn.connect();
			conn.getInputStream().close();
			return true;
		} catch (MalformedURLException e) {
			throw new RuntimeException(e);
		} catch (IOException e) {
			return false;
		}
	}

	public  boolean checkRestApiServer() {

		Path resourceDirectory = Paths.get("src", "main", "resources", "com", "project", "hotelbooking", "url");
		String sApiConfigPath = resourceDirectory.toFile().getAbsolutePath();
		Properties props = new Properties();

		String sApiConfigResource = sApiConfigPath + Delimiter + API_CONFIG_FILE;

		String inetAddress = "";
		String localAddress = "";
		int iPort = 0;

		try (InputStream input = new FileInputStream(sApiConfigResource)) {

			props.load(input);


			if(!props.get("rest.api.web.host").toString().isEmpty()) {
				localAddress = props.get("rest.api.web.host")+Delimiter+Delimiter;
			}

			if(!props.get("rest.api.web.url").toString().isEmpty()) {
				inetAddress+= props.get("rest.api.web.url");
				localAddress+=inetAddress;
			}
			if(!props.get("rest.api.web.port").toString().isEmpty()
					&& isNumeric(props.get("rest.api.web.port").toString())) {
				iPort = Integer.parseInt(props.get("rest.api.web.port").toString());
			}
			return netIsAvailable(localAddress) && isConnectionAvailable(inetAddress, iPort);
		} catch (IOException io) {
			io.printStackTrace();
			return  false;
		}

	}

	private boolean isConnectionAvailable(String serverAddress, int port) {
		boolean bReturn = true;
		try{
			InetSocketAddress sa = new InetSocketAddress(serverAddress, port);
			Socket ss = new Socket();
			ss.connect(sa, 250);          //  --> change from 1 to 500 (for example)
			ss.close();
		}catch(Exception e) {
			bReturn = false;
		}
		return bReturn;
	}

	public String getRestApiConnectionUri() {
		Path resourceDirectory = Paths.get("src", "main", "resources", "com", "project", "hotelbooking", "url");
		String sApiConfigPath = resourceDirectory.toFile().getAbsolutePath();

		String sApiConfigResource = sApiConfigPath + Delimiter + API_CONFIG_FILE;

		StringBuilder sbConnectUri = new StringBuilder();
		Properties props = new Properties();
		try (InputStream input = new FileInputStream(sApiConfigResource)) {

			props.load(input);

			if(!props.get("rest.api.web.host").toString().isEmpty()) {
				sbConnectUri.append(props.get("rest.api.web.host")).append(Delimiter).append(Delimiter);
			}

			if(!props.get("rest.api.web.url").toString().isEmpty()) {
				sbConnectUri.append(props.get("rest.api.web.url"));
			}
			if(!props.get("rest.api.web.port").toString().isEmpty()
				&& isNumeric(props.get("rest.api.web.port").toString())) {
				sbConnectUri.append(URI_PORT_DELIMITER).append(props.get("rest.api.web.port"));
			}
			if(!props.get("rest.api.web.serverproject").toString().isEmpty()) {
				sbConnectUri.append(Delimiter).append(props.get("rest.api.web.serverproject"));
			}
			if(!props.get("rest.api.web.entrypoint").toString().isEmpty()) {
				sbConnectUri.append(Delimiter).append(props.get("rest.api.web.entrypoint"));
			}

			return sbConnectUri.toString();
		} catch (IOException io) {
			io.printStackTrace();
			return "";
		}

	}
	private  boolean isNumeric(String str) {
		ParsePosition pos = new ParsePosition(0);
		NumberFormat.getInstance().parse(str, pos);
		return str.length() == pos.getIndex();
	}

	private static String getResourceUriDelimiter() {
		OSValidator os = new OSValidator();
		return os.isWindows() ? "\\" : "/";
	}

	public SystemSecure() {
		super();
		os = new OSValidator();
	//	Delimiter = os.isWindows() ? "\\" : "/";
		Delimiter = getResourceUriDelimiter();
		sConfigResource = sConfigPath + Delimiter + CONFIG_FILE;

		setWorkStation();
	}

	public void generatePepperHash() {
		setsPepper(getPepper());		
	}
	
	private void setWorkStation() {
		try {
			InetAddress addr = InetAddress.getLocalHost();
			// Get Hostname
			workStation =  addr.getHostName();			
		} catch(UnknownHostException e) {
			System.out.println(e.getMessage());
		}
		
	}	
	
	/**
	 * In real life this would probably read from a config file, so you could check
	 * your code into a repo without the config file.
	 */
	private String getPepper() {
		return getHashString(randGeneratedStr(30));
	}

	public String getHashString(String text) {
		String generatedPassword = null;
		try {
			MessageDigest md = MessageDigest.getInstance("SHA-512");
			byte[] bytes = md.digest(text.getBytes());
			StringBuilder sb = new StringBuilder();
			for (int i = 0; i < bytes.length; i++) {
				sb.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));
			}
			generatedPassword = sb.toString();
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		return generatedPassword;
	}


	// Add salt
	public String getSalt() throws NoSuchAlgorithmException {
		SecureRandom sr = SecureRandom.getInstance("SHA1PRNG");
		byte[] salt = new byte[16];
		sr.nextBytes(salt);
		return salt.toString();
	}	

	public String getHashedPassword(String password, String salt) {
		String saltedAndPepperedPassword = password + salt +getPepperHash();
		return getHashString(saltedAndPepperedPassword);
	}	
	
	private void storePepperHash(String sPepper) {

		try (OutputStream output = new FileOutputStream(sConfigResource)) {

			Properties prop = new Properties();
			
			// set the properties value
			prop.setProperty("com/project/hotelbooking/url", "localhost");
			prop.setProperty("workStation", workStation);
			prop.setProperty("pepper", sPepper);

			// save properties to project root folder
			prop.store(output, null);			
		} catch (IOException io) {
			io.printStackTrace();
		}
		
	}	
	
	public String getPepperHash() {

		Properties props = new Properties();
		
		try (InputStream is = new FileInputStream(sConfigResource)) {
			props.load(is);
			return props.getProperty("pepper");
		} catch (IOException e) {
			System.out.println(e.getMessage());
			return null;
		}		
	}	
	
	// defining a function to generate a random string of length l
	private String randGeneratedStr(int l) {

		// a list of characters to choose from in form of a string
		final String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvxyz0123456789!§$$%$%&/()=?``<>;:_,.-";

		// creating a StringBuffer size of AlphaNumericStr
		StringBuilder s = new StringBuilder(l);

		int i;

		for (i = 0; i < l; i++) {

			// generating a random number using math.random()
			int ch = (int) (AlphaNumericString.length() * Math.random());

			// adding Random character one by one at the end of s
			s.append(AlphaNumericString.charAt(ch));

		}

		return s.toString();
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public void setsPepper(String sPepper) {
		this.sPepper = sPepper;
		storePepperHash(sPepper);
	}


}

package com.project.hotelbooking.controllers;

import com.project.hotelbooking.Main;
import com.project.hotelbooking.datamodels.restapi.models.Guest;
import com.project.hotelbooking.services.GuestService;
import com.project.hotelbooking.utils.Common;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;

import java.io.IOException;
import java.net.URISyntaxException;
import java.time.LocalDateTime;
import java.util.Optional;

public class GuestController {
    
    @FXML
    private BorderPane guestsPanel;

    @FXML
    private TableView<Guest> guestsTable;

    @FXML
    private TextField fldFirstName;

    @FXML
    private TextField fldLastName;

    @FXML
    private DatePicker fldBirthDate;

    @FXML
    private TextField fldStreet;

    @FXML
    private TextField fldZipcode;

    @FXML
    private TextField fldLocation;

    @FXML
    private TextField fldEMail;

    @FXML
    private TextField fldPhone;

    @FXML
    private CheckBox fldBusiness;

    @FXML
    private CheckBox fldRegularCustomer;

    private GuestService guestService;

    private int currentGuestId = 0;
    

    public void initialize() {
        guestService = new GuestService();

        if(guestsTable != null) {
            guestsTable.setItems(guestService.getGuests());
        } else {
            fldFirstName.requestFocus();
        }
    }

    public void editGuest(Guest guest) {
        fldFirstName.setText(guest.getFirstName());
        fldLastName.setText(guest.getLastName());
        if(!guest.getBirthDate().isEmpty()) {
            fldBirthDate.setValue(LocalDateTime.parse(guest.getBirthDate(),Common.CUSTOM_FORMATTER).toLocalDate());
        }
        fldStreet.setText(guest.getStreet());
        fldZipcode.setText(guest.getZipcode());
        fldLocation.setText(guest.getLocation());
        fldEMail.setText(guest.getEmail());
        fldPhone.setText(guest.getPhone());
        fldBusiness.setSelected(guest.isBusiness());
        fldRegularCustomer.setSelected(guest.isRegularCustomer());
    }
    @FXML
    public void showAddGuestDialog() throws URISyntaxException {
        Dialog<ButtonType> dialog = new Dialog<ButtonType>();
        dialog.initOwner(guestsPanel.getScene().getWindow());
        dialog.setTitle("Gast hinzufügen");
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(Main.class.getResource("forms/guestdialog.fxml"));
        try {
            dialog.getDialogPane().setContent(fxmlLoader.load());

        } catch(IOException e) {
            System.out.println("Couldn't load the dialog");
            e.printStackTrace();
            return;
        }

        dialog.getDialogPane().getButtonTypes().add(ButtonType.OK);
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CANCEL);

        GuestController guestController = fxmlLoader.getController();
        final Button okButton = (Button) dialog.getDialogPane().lookupButton(ButtonType.OK);
        okButton.addEventFilter(ActionEvent.ACTION, ae -> {
            if (!guestController.isValidGuest()) {
                ae.consume(); //not valid
            }
        });

        Optional<ButtonType> result = dialog.showAndWait();
        if(result.isPresent() && result.get() == ButtonType.OK) {
            Guest newGuest = guestController.getNewGuest();

            currentGuestId = guestService.insertGuest(newGuest);
            guestsTable.setItems(guestService.getGuests());
            guestsTable.refresh();
        }
    }

    private boolean isValidGuest() {
        boolean bReturn = true;
        Common.isWarningMessage = true;

        if(fldFirstName.getText().isEmpty()) {
            Common.showValidationMessage("Das Feld Vorname  darf nicht leer bleiben");
            bReturn = false;
            fldFirstName.requestFocus();
        } else if(fldLastName.getText().isEmpty()) {
            Common.showValidationMessage("Das Feld Nachname  darf nicht leer bleiben");
            bReturn = false;
            fldLastName.requestFocus();
        }  else if(fldStreet.getText().isEmpty()) {
            Common.showValidationMessage("Das Feld Strasse darf nicht leer bleiben");
            bReturn = false;
            fldStreet.requestFocus();
        }  else if(fldZipcode.getText().isEmpty()) {
            Common.showValidationMessage("Das Feld PLZ darf nicht leer bleiben");
            bReturn = false;
            fldZipcode.requestFocus();
        }  else if(fldLocation.getText().isEmpty()) {
            Common.showValidationMessage("Das Feld Ort darf nicht leer bleiben");
            bReturn = false;
            fldLocation.requestFocus();
        }

        return bReturn;
    }
    public Guest getNewGuest() {
        String firstName = fldFirstName.getText();
        String lastName = fldLastName.getText();
        String birthDate = fldBirthDate.getValue().toString();
        String street = fldStreet.getText();
        String zipcode = fldZipcode.getText();
        String location = fldLocation.getText();
        String email = fldEMail.getText();
        String phone = fldPhone.getText();
        Boolean isBusiness = fldBusiness.isSelected();
        Boolean isRegularCustomer = fldRegularCustomer.isSelected();

        return new Guest(firstName, lastName,  birthDate, street, zipcode, location, email, phone,
                isBusiness,isRegularCustomer, Common.CREATOR,  Common.CREATED, true);
    }

    @FXML
    public void showEditGuestDialog() throws URISyntaxException {
        Guest selectedGuest = guestsTable.getSelectionModel().getSelectedItem();
        if(selectedGuest == null) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle(Common.alertMessage.getProperty("confirmGuestTitle"));
            alert.setHeaderText(null);
            alert.setContentText(Common.alertMessage.getProperty("confirmEditGuest"));
            alert.showAndWait();
            return;
        }

        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.initOwner(guestsPanel.getScene().getWindow());
        dialog.setTitle("Gast bearbeiten");
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(Main.class.getResource("forms/guestdialog.fxml"));
        try {
            dialog.getDialogPane().setContent(fxmlLoader.load());
        } catch (IOException e) {
            System.out.println("Couldn't load the dialog");
            e.printStackTrace();
            return;
        }

        dialog.getDialogPane().getButtonTypes().add(ButtonType.OK);
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CANCEL);

        GuestController guestController = fxmlLoader.getController();
        guestController.editGuest(selectedGuest);

        final Button okButton = (Button) dialog.getDialogPane().lookupButton(ButtonType.OK);
        okButton.addEventFilter(ActionEvent.ACTION, ae -> {
            if (!guestController.isValidGuest()) {
                ae.consume(); //not valid
            }
        });

        Optional<ButtonType> result = dialog.showAndWait();
        if(result.isPresent() && result.get() == ButtonType.OK) {
            guestController.updateGuest(selectedGuest);

            currentGuestId = guestService.updateGuest(selectedGuest.getId(), selectedGuest);
            guestsTable.setItems(guestService.getGuests());
            guestsTable.refresh();
        }

    }

    public void updateGuest(Guest guest) {
        guest.setFirstName(fldFirstName.getText());
        guest.setLastName(fldLastName.getText());
        guest.setBirthDate((fldBirthDate.getValue().atStartOfDay()).format(Common.CUSTOM_FORMATTER));
        guest.setStreet(fldStreet.getText());
        guest.setZipcode(fldZipcode.getText());
        guest.setLocation(fldLocation.getText());
        guest.setEmail(fldEMail.getText());
        guest.setPhone(fldPhone.getText());
        guest.setBusiness(fldBusiness.isSelected());
        guest.setRegularCustomer(fldRegularCustomer.isSelected());
    }

    @FXML
    public void deleteGuest() throws URISyntaxException {
        Guest selectedGuest = guestsTable.getSelectionModel().getSelectedItem();
        if (selectedGuest == null) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle(Common.alertMessage.getProperty("confirmGuestTitle"));
            alert.setHeaderText(null);
            alert.setContentText(Common.alertMessage.getProperty("confirmDeleteGuest"));
            alert.showAndWait();
            return;
        }
        Alert alert = new Alert(Alert.AlertType.NONE,
                "Möchten Sie den Gast '"+selectedGuest.getFirstName()+" "
                        +selectedGuest.getLastName()+"' wirklich löschen?", Common.YES, Common.NO);

        alert.setTitle("Lösch-Bestätigung!");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.orElse(Common.NO) == Common.YES) {
            guestService.deleteGuest(selectedGuest.getId());
            guestsTable.setItems(guestService.getGuests());
            guestsTable.refresh();
        }
    }
}

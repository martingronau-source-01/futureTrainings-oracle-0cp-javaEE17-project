package com.project.hotelbooking.playground.components;

import com.project.hotelbooking.datamodels.restapi.models.Lookup;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;

import java.util.Objects;

public class RadioListCell extends ListCell<String> {

    public static  String selectedName;
    public static ToggleGroup group;
    public static ListView parentview;

    private final RadioButton radioButton = new RadioButton();

    static  {
        group = new ToggleGroup();
        parentview = new ListView<Lookup>();
    }

   public  RadioListCell() {
        super();
        radioButton.setToggleGroup(group);
        radioButton.selectedProperty().addListener((obs, wasSelected, isNowSelected) -> {
            if (isNowSelected) {
                selectedName = getItem();
                System.out.println(selectedName);
            //    this.parentview.getSelectionModel().select(selectedName);

            } else if(wasSelected) {
                System.out.println(wasSelected);
            }
        });
    }

    @Override
    public void updateItem(String obj, boolean empty) {
        super.updateItem(obj, empty);
        if (empty) {
            setText(null);
            setGraphic(null);
        } else {
            radioButton.setText(obj);

            radioButton.setSelected(Objects.equals(obj, selectedName));

            setGraphic(radioButton);
        }
    }
}
package com.project.hotelbooking.services;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.project.hotelbooking.datamodels.restapi.enums.eHttpStatusCodes;
import com.project.hotelbooking.datamodels.restapi.models.RoomFeature;
import com.project.hotelbooking.utils.Common;
import com.project.hotelbooking.utils.SystemSecure;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;

import java.net.URISyntaxException;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.List;

public class RoomFeatureService extends RestApiService {
    private final String roomFeaturesURI;
    private final Gson gson;

    public RoomFeatureService() {
        super();
        gson= new Gson();

        SystemSecure systemSecure = new SystemSecure();

        String sBaseURI = systemSecure.getRestApiConnectionUri();
        roomFeaturesURI = sBaseURI+systemSecure.getDelimiter()+"room-features"+systemSecure.getDelimiter();
    }

    public ObservableList<RoomFeature> getRoomFeatures() {
        HttpResponse<String> getResponse = this.sendGetRequest(roomFeaturesURI);
        if(getResponse.statusCode() == eHttpStatusCodes.HTTP_OK.getValue()) {
            List<RoomFeature> roomFeatures = gson.fromJson(getResponse.body(), new TypeToken<ArrayList<RoomFeature>>() {
            }.getType());

            return FXCollections.observableList(roomFeatures);
        } else if(getResponse.statusCode() == eHttpStatusCodes.HTTP_NO_CONTENT.getValue()) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle(Common.alertMessage.getProperty("informationNoDataTitle"));
            alert.setHeaderText(null);
            alert.setContentText(Common.alertMessage.getProperty("informationNoRoomFeaturesData"));
            alert.showAndWait();

            return  null;
        } else {
            return null;
        }
    }

    public ObservableList<RoomFeature> getRoomFeaturesByRoom(int roomId) {
        HttpResponse<String> getResponse = this.sendGetRequest(roomFeaturesURI+"by-room/"+roomId);

        List<RoomFeature> roomFeatures = gson.fromJson(getResponse.body(), new TypeToken<ArrayList<RoomFeature>>() {
        }.getType());

        return FXCollections.observableList(roomFeatures);
    }

    public int insertRoomFeature(RoomFeature roomFeature)  throws URISyntaxException {
        String jsonRequest = gson.toJson(roomFeature);

        return this.sendPostRequest(roomFeaturesURI, jsonRequest);
    }

    public int updateRoomFeature(int optionType, int optionId, RoomFeature roomFeature) throws URISyntaxException {
        String jsonRequest = gson.toJson(roomFeature);

        return this.sendPutRequest(roomFeaturesURI + optionType+"/"+optionId, jsonRequest);
    }

    public int deleteRoomFeature(int optionType, int optionId) throws URISyntaxException {
        return this.sendDeleteRequest(roomFeaturesURI + optionType+"/"+optionId);
    }
}

module com.project.hotelbooking {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.kordamp.bootstrapfx.core;
    requires java.xml;
    requires java.ws.rs;
    requires jersey.client;
    requires java.net.http;
    requires com.google.gson;
    requires java.sql;
    requires lombok;
    requires jakarta.mail;
    requires kernel;
    requires layout;
    requires org.controlsfx.controls;
    requires controlsfx.samples;

    opens com.project.hotelbooking to javafx.fxml;
    exports com.project.hotelbooking;
    exports com.project.hotelbooking.controllers;

    exports com.project.hotelbooking.datamodels.restapi.models;
    opens com.project.hotelbooking.controllers to javafx.fxml;

    opens com.project.hotelbooking.datamodels.restapi.models to javafx.base, com.google.gson;
    opens com.project.hotelbooking.controllers.tabpanels to  javafx.fxml;
    exports com.project.hotelbooking.controllers.tabpanels to  javafx.fxml;
    exports com.project.hotelbooking.services;
    opens com.project.hotelbooking.services to javafx.fxml;

     exports com.project.hotelbooking.playground to javafx.graphics;
}
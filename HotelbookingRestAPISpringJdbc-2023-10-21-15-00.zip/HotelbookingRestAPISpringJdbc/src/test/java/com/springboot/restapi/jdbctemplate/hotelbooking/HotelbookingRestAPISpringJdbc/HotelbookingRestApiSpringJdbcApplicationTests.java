package com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelbookingRestApiSpringJdbcApplicationTests {

	@Test
	void contextLoads() {
	}

}

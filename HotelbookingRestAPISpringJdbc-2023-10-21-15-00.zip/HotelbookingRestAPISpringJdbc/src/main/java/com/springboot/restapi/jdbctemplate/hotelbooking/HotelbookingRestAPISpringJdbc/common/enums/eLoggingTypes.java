package com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.common.enums;

public enum eLoggingTypes {
	NO_LOGGING(0), INSERT_LOGGING(1), UPDATE_LOGGING(2), DELETE_LOGGING(3), READ_LOGGING(4), READ_ALL_LOGGING(5), SEARCH_LOGGING(6);	

	private int value;

	private eLoggingTypes(int value) {
		this.value = value;
	}

	public int getValue() {
		return value;
	}	
}

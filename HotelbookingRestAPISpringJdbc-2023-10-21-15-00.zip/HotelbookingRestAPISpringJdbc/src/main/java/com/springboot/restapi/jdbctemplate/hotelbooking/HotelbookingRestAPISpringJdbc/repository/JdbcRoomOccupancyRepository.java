package com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.repository;

import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.common.exception.PersistenceException;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.Booking;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.Room;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.schema.IRoomOccupancyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class JdbcRoomOccupancyRepository implements IRoomOccupancyRepository {
    private final String SQLSELECT_NEXT_FREE_ROOM = "SELECT r1.id, r1.name, r1.title,r1.description,"
            + "r1.category,r1.count_of_beds, r1.hotel_id, r1.accommodation_cost, r1.creator, r1.created "
            + "FROM room r1 "
            + "WHERE r1.hotel_id = ? AND r1.id NOT IN "
            + "(SELECT r.id FROM room_occupancy ro "
            + "INNER JOIN guest g ON ro.guest_id = g.id "
            + "INNER JOIN room r ON ro.room_id = r.id "
            + "WHERE r.hotel_id = ? "
            + "AND ro.start_date >= ? AND ro.end_date <= ?) "
            + "ORDER BY r1.id DESC "
            + "LIMIT 0,1 ";

    private final String SQLSELECT_FREE_ROOMS = "SELECT r1.id, r1.name, r1.title, r1.accommodation_cost,"
            + "r1.description, r1.count_of_beds, r1.hotel_id, r1.category, r1.creator, r1.created "
            + "FROM room r1 "
            + "WHERE r1.hotel_id = ? AND r1.id NOT IN (SELECT r.id FROM room_occupancy ro "
            + "INNER JOIN guest g ON ro.guest_id = g.id "
            + "INNER JOIN room r ON ro.room_id = r.id "
            + "WHERE r.hotel_id = ? "
            + "AND ro.start_date >= ? AND ro.end_date <= ?) "
            + "ORDER BY r1.id DESC ";

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public List<Room> listFreeRooms(Booking booking) throws PersistenceException {
        return jdbcTemplate.query(SQLSELECT_FREE_ROOMS,
                BeanPropertyRowMapper.newInstance(Room.class), booking.getHotelId(), booking.getHotelId(),
                booking.getStartDate(), booking.getStartDate());
    }

    @Override
    public Room getNextFreeRoom(Booking booking) {
        try {
            return jdbcTemplate.queryForObject(SQLSELECT_NEXT_FREE_ROOM,
                    BeanPropertyRowMapper.newInstance(Room.class), booking.getHotelId(), booking.getHotelId(),
                    booking.getStartDate(), booking.getStartDate());
        } catch (EmptyResultDataAccessException e) {
            return null;
        }
    }
}

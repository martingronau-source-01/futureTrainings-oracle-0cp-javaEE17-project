package com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.repository;

import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.common.exception.PersistenceException;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.AccommodationSearchResult;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.Guest;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.Room;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.schema.IAccommodationSearchRepository;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.schema.IRoomRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Repository
public class JdbcAccommodationSearchRepository implements IAccommodationSearchRepository {

    private final String SQL_ACCOMMODATION_SEARCH_STANDARD = "SELECT h.id AS 'hotel_id', DATE_FORMAT(roc1.start_date, '%Y-%m-%d') AS start_date, "
            + "DATE_FORMAT(roc1.end_date, '%Y-%m-%d') AS end_date, r.name as 'region_name', r.title AS 'region_title', "
            + "r.description AS 'region_description',h.name AS 'hotel_name',h.title AS 'hotel_title', h.description AS 'hotel_description',"
            + "h.street AS 'hotel_street', h.zipcode AS 'hotel_zipcode', h.location AS 'hotel_location', "
            + "h.email AS 'hotel_email', h.phone AS 'hotel_phone', h.website AS 'hotel_website', h.region_id, "
            + "COUNT(r1.id) AS 'count_rooms', SUM(r1.count_of_beds) AS 'count_beds',DATEDIFF(?, ?) AS count_accommodations, "
            + "h.creator, h.created "
            + "FROM hotel h  "
            + "LEFT OUTER JOIN region r ON h.region_id = r.id "
            + "LEFT OUTER JOIN room r1 ON r1.hotel_id = h.id  "
            + "LEFT OUTER JOIN room_occupancy roc1 ON roc1.room_id = r1.id "
            + "WHERE r1.id NOT IN ( "
            + "SELECT ro.id FROM `hotel` h1 "
            + "LEFT OUTER JOIN region rg ON h1.region_id = rg.id "
            + "LEFT OUTER JOIN room ro ON ro.hotel_id = h1.id "
            + "LEFT OUTER JOIN room_occupancy roc ON roc.room_id = ro.id "
            + "WHERE roc.start_date >= ? AND roc.end_date <= ? "
            + "OR (roc.start_date < ? AND end_date > ?) "
            + "AND rg.title LIKE ? ) AND r.title LIKE ? "
            + "GROUP BY  h.id, r.name, r.title, r.description, h.name, h.title, h.description, h.street, "
            + "h.zipcode, h.location,h.region_id, roc1.start_date, roc1.end_date   "
            + "HAVING COUNT(r1.id) >= ? AND SUM(r1.count_of_beds) >= ?";


    private final String SQL_ACCOMMODATION_SEARCH_EXTENDED_PART1 = "SELECT h.id AS 'hotel_id', roc1.start_date, roc1.end_date, "
            + " r.name as 'region_name', r.title AS 'region_title', r.description AS 'region_description',h.name AS 'hotel_name', "
            + "h.title AS 'hotel_title', h.description AS 'hotel_description',"
            + "h.street AS 'hotel_street', h.zipcode AS 'hotel_zipcode', h.location AS 'hotel_location', "
            + "h.email AS 'hotel_email', h.phone AS 'hotel_phone', h.website AS 'hotel_website', h.region_id, "
            + "COUNT(r1.id) AS 'count_rooms', SUM(r1.count_of_beds) AS 'count_beds',DATEDIFF(?, ?) AS count_accommodations, "
            + "h.creator, h.created "
            + "FROM hotel h  "
            + "LEFT OUTER JOIN region r ON h.region_id = r.id "
            + "LEFT OUTER JOIN room r1 ON r1.hotel_id = h.id  "
            + "LEFT OUTER JOIN room_occupancy roc1 ON roc1.room_id = r1.id ";

    private final String SQL_ACCOMMODATION_SEARCH_EXTENDED_PART2 = "WHERE h.id NOT IN ( "
            + "SELECT h1.id FROM `hotel` h1 "
            + "LEFT OUTER JOIN region rg ON h1.region_id = rg.id "
            + "LEFT OUTER JOIN room ro ON ro.hotel_id = h1.id "
            + "LEFT OUTER JOIN room_occupancy roc ON roc.room_id = ro.id "
            + "WHERE roc.start_date >= ? AND roc.end_date <= ? "
            + "OR (roc.start_date < ? AND end_date > ?) AND rg.title LIKE ? ) "
            + "AND r.title LIKE ? ";
    private final String SQL_ACCOMMODATION_SEARCH_EXTENDED_PART3 = "GROUP BY  h.id, r.name, r.title, r.description, h.name, h.title, h.description, h.street, h.zipcode, h.location "
            + "HAVING COUNT(r1.id) >= ? AND SUM(r1.count_of_beds) >= ?";

    private final String SQL_ACCOMMODATION_SEARCH_ROOMS = "SELECT r1.id, r1.name, r1.title, r1.description, r1.creator, r1.category, "
            + "r1.count_of_beds, r1.accommodation_cost, r1.hotel_id, h.title AS 'hotel', r1.created, r1.creator "
            + "FROM hotel h "
            + "LEFT OUTER JOIN region r ON h.region_id = r.id "
            + "LEFT OUTER JOIN room r1 ON r1.hotel_id = h.id "
            + "WHERE r1.id NOT IN ( SELECT h1.id "
            + "FROM `hotel` h1 "
            + "LEFT OUTER JOIN region rg ON h1.region_id = rg.id "
            + "LEFT OUTER JOIN room ro ON ro.hotel_id = h1.id "
            + "LEFT OUTER JOIN room_occupancy roc ON roc.room_id = ro.id "
            + "WHERE roc.start_date >= ? AND roc.end_date <= ? AND rg.title LIKE ? ) AND r.title LIKE ? "
            + "GROUP BY r1.id, r1.name, r1.title, r1.description, r1.creator, "
            + "r1.category,r1.count_of_beds, r1.accommodation_cost, r1.created, r1.creator  "
            + "HAVING COUNT(r1.id) >= ? AND SUM(r1.count_of_beds) >= ? ";

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public List<AccommodationSearchResult> searchOvernightStay(String region, String startDate, String endDate,
                                                               int amountOfGuests, int numberOfRooms) throws PersistenceException {
        try {
        return jdbcTemplate.query(SQL_ACCOMMODATION_SEARCH_STANDARD,
                BeanPropertyRowMapper.newInstance(AccommodationSearchResult.class), endDate, startDate, startDate,
                endDate, startDate, startDate, "%" + region + "%", "%" + region + "%", numberOfRooms, amountOfGuests);
        } catch (EmptyResultDataAccessException e) {
            List<AccommodationSearchResult> result = new ArrayList<AccommodationSearchResult>();
            result.add(new AccommodationSearchResult());
            return result;
        }
    }

    @Override
    public List<AccommodationSearchResult> searchOvernightStayExtended(String region, String startDate, String endDate, int amountOfGuests, int numberOfRooms, List<Integer> hotelOptions, List<Integer> roomFeatures) throws PersistenceException {

        String SQL = SQL_ACCOMMODATION_SEARCH_EXTENDED_PART1;
        String sSQlComparePart = "";

        if (!hotelOptions.isEmpty() && hotelOptions.get(0) > 0) {
            SQL += "LEFT OUTER JOIN hotel_option ho ON ho.hotel_id = h.id ";
            String sCompareHotelOptions = hotelOptions.stream().map(String::valueOf)
                    .collect(Collectors.joining(","));
            sSQlComparePart += "AND ho.option_id IN(" + sCompareHotelOptions + ") ";
        }

        if (!roomFeatures.isEmpty() && roomFeatures.get(0) > 0) {
            SQL += "LEFT OUTER JOIN room_feature rf ON rf.room_id = r1.id ";
            String sCompareRoomFeatures = roomFeatures.stream().map(String::valueOf)
                    .collect(Collectors.joining(","));
            sSQlComparePart += "AND rf.option_id IN(" + sCompareRoomFeatures + ") ";
        }

        SQL += SQL_ACCOMMODATION_SEARCH_EXTENDED_PART2 + sSQlComparePart + SQL_ACCOMMODATION_SEARCH_EXTENDED_PART3;

        return jdbcTemplate.query(SQL, BeanPropertyRowMapper.newInstance(AccommodationSearchResult.class),
                endDate, startDate, startDate,
                endDate, startDate, startDate, "%" + region + "%", "%" + region + "%", numberOfRooms, amountOfGuests);
    }

    @Override
    public List<Room> searchOvernightStayRooms(String region, String startDate, String endDate, int amountOfGuests,
                                               int numberOfRooms) throws PersistenceException {

        return jdbcTemplate.query(SQL_ACCOMMODATION_SEARCH_ROOMS,
                BeanPropertyRowMapper.newInstance(Room.class), startDate, endDate,
                "%" + region + "%", "%" + region + "%", numberOfRooms, amountOfGuests);
    }

}

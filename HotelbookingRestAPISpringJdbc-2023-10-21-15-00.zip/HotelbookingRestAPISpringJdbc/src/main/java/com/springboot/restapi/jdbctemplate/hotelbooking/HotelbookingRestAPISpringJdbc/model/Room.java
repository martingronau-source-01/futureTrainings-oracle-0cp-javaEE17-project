package com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model;

import java.util.List;
import java.util.Objects;

public class Room {

	private int id = 0;
	private String name = "";
	private String title = "";
	private String description = "";
	private int countOfBeds = 0;
	private String category = "";
	private int hotelId = 0;
	private String hotel = "";
	private double accommodationCost = 0.00;
	private List<Integer> roomFeatureIds = null;
	private String creator = "";

	@Override
	public String toString() {
		return "Room{" +
				"id=" + id +
				", name='" + name + '\'' +
				", title='" + title + '\'' +
				", description='" + description + '\'' +
				", countOfBeds=" + countOfBeds +
				", category='" + category + '\'' +
				", hotelId=" + hotelId +
				", hotel='" + hotel + '\'' +
				", accommodationCost=" + accommodationCost +
				", roomFeatureIds=" + roomFeatureIds +
				", creator='" + creator + '\'' +
				", created='" + created + '\'' +
				", hasData=" + hasData +
				'}';
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (!(o instanceof Room room)) return false;
		return getId() == room.getId() && getCountOfBeds() == room.getCountOfBeds() && getHotelId() == room.getHotelId() && Double.compare(getAccommodationCost(), room.getAccommodationCost()) == 0 && isHasData() == room.isHasData() && Objects.equals(getName(), room.getName()) && Objects.equals(getTitle(), room.getTitle()) && Objects.equals(getDescription(), room.getDescription()) && Objects.equals(getCategory(), room.getCategory()) && Objects.equals(getHotel(), room.getHotel()) && Objects.equals(getRoomFeatureIds(), room.getRoomFeatureIds()) && Objects.equals(getCreator(), room.getCreator()) && Objects.equals(getCreated(), room.getCreated());
	}

	@Override
	public int hashCode() {
		return Objects.hash(getId(), getName(), getTitle(), getDescription(), getCountOfBeds(), getCategory(), getHotelId(), getHotel(), getAccommodationCost(), getRoomFeatureIds(), getCreator(), getCreated(), isHasData());
	}

	public List<Integer> getRoomFeatureIds() {
		return roomFeatureIds;
	}

	public void setRoomFeatureIds(List<Integer> roomFeatureIds) {
		this.roomFeatureIds = roomFeatureIds;
	}

	private String created = "";
	private boolean hasData = false;

	public Room() {
		super();
	}

	public Room(int id, String name, String title, String description, int countOfBeds, int hotelId, String hotel, 
			String category, double accommodationCost, String creator, String created, boolean hasData) {
		this(name, title, description, countOfBeds, hotelId, hotel,category,  accommodationCost, creator, created, hasData);
		this.id = id;
	}

	public Room(String name, String title, String description, int countOfBeds, int hotelId, String hotel,
			String category, double accommodationCost, String creator,  String created, boolean hasData) {
		this(name, title, description, countOfBeds, hotelId, category, accommodationCost, creator, created, hasData);
		this.hotel = hotel;
	}

	public String getHotel() {
		return hotel;
	}

	public void setHotel(String hotel) {
		this.hotel = hotel;
	}

	public Room(String name, String title, String description, int countOfBeds, int hotelId, String category,
			double accommodationCost, String creator, String created, boolean hasData) {
		super();
		this.name = name;
		this.title = title;
		this.description = description;
		this.countOfBeds = countOfBeds;
		this.hotelId = hotelId;
		this.category = category;
		this.accommodationCost = accommodationCost;
		this.creator = creator;
		this.created = created;
		this.hasData = hasData;
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public String getCreated() {
		return created;
	}

	public void setCreated(String created) {
		this.created = created;
	}

	public boolean isHasData() {
		return hasData;
	}

	public void setHasData(boolean hasData) {
		this.hasData = hasData;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getCountOfBeds() {
		return countOfBeds;
	}

	public void setCountOfBeds(int countOfBeds) {
		this.countOfBeds = countOfBeds;
	}

	public int getHotelId() {
		return hotelId;
	}

	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public double getAccommodationCost() {
		return accommodationCost;
	}

	public void setAccommodationCost(double accommodationCost) {
		this.accommodationCost = accommodationCost;
	}

}

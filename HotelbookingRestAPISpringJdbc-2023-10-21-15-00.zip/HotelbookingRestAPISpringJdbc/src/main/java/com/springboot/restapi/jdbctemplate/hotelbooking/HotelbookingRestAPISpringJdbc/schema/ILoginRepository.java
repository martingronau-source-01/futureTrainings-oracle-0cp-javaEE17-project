package com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.schema;

import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.common.exception.PersistenceException;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.Login;

import java.util.List;

public interface ILoginRepository {

    public int create(Login login) throws PersistenceException;

    public List<Login> getAll() throws PersistenceException;

    public boolean update(int loginId, Login login);

    public Login getDataset(int loginId);

    public Login getDatasetByUsername(String name);

    public boolean delete(int loginId);

    public boolean checkLogin(String loginname, String password);

    public int getIdByUsername(String username);

    public int getIdByLoginname(String loginname);
}


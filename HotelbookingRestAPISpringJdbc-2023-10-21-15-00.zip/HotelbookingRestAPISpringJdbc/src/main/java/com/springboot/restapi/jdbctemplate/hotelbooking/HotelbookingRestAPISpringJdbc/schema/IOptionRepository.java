package com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.schema;

import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.common.exception.PersistenceException;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.Option;

import java.util.List;

public interface IOptionRepository {

    public int create(Option option) throws PersistenceException;

    public List<Option> getAll() throws PersistenceException;

    public boolean update(int optionId, Option option);

    public Option getDataset(int optionId);

    public boolean delete(int optionId);
}


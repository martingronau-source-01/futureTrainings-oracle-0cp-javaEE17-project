package com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model;

import java.util.Objects;

public class Login {

	private int id = 0;
	private String username = "";
	private String loginname = "";
	private String password = "";
	private String salt = "";
	private int roleId = 0;
	private String role = "";
	private int guestId = 0;
	private boolean registered = false;
	private String creator = "";
	private String created = "";
	private boolean hasData = false;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getLoginname() {
		return loginname;
	}

	public void setLoginname(String loginname) {
		this.loginname = loginname;
	}

	public int getRoleId() {
		return roleId;
	}

	public void setRoleId(int roleId) {
		this.roleId = roleId;
	}

	public boolean isRegistered() {
		return registered;
	}

	public void setRegistered(boolean registered) {
		this.registered = registered;
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public String getCreated() {
		return created;
	}

	public void setCreated(String created) {
		this.created = created;
	}

	public Login() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public int hashCode() {
		return Objects.hash(created, creator, guestId, hasData, id, loginname, password, registered, role, roleId, salt,
				username);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Login other = (Login) obj;
		return Objects.equals(created, other.created) && Objects.equals(creator, other.creator)
				&& guestId == other.guestId && hasData == other.hasData && id == other.id
				&& Objects.equals(loginname, other.loginname) && Objects.equals(password, other.password)
				&& registered == other.registered && Objects.equals(role, other.role) && roleId == other.roleId
				&& Objects.equals(salt, other.salt) && Objects.equals(username, other.username);
	}

	public boolean isHasData() {
		return hasData;
	}

	public void setHasData(boolean hasData) {
		this.hasData = hasData;
	}

	public Login(int id, String username, String loginname, String password, String salt,  int roleId,
			String role, boolean registered, int guestId, String creator, String created, boolean hasData) {
		this(username, loginname, password, salt,  roleId, role, registered, guestId, creator, created, hasData);
		this.id = id;
	}	
	
	public Login(String username, String loginname, String password, String salt,  int roleId,
			String role, boolean registered, int guestId, String creator, String created, boolean hasData) {
		this(username, loginname, password, salt, roleId, registered, guestId, creator, created, hasData);
		this.role = role;
	}

	public Login(String username, String loginname, String password, String salt,  int roleId,
			boolean registered, int guestId, String creator, String created, boolean hasData) {
		super();
		this.username = username;
		this.loginname = loginname;
		this.password = password;
		this.salt = salt;
		this.roleId = roleId;
		this.registered = registered;
		this.guestId = guestId;
		this.creator = creator;
		this.created = created;
		this.hasData = hasData;
	}


	@Override
	public String toString() {
		return "Login [id=" + id + ", username=" + username + ", loginname=" + loginname + ", password=" + password
				+ ", salt=" + salt + ", roleId=" + roleId + ", role=" + role + ", guestId=" + guestId + ", registered="
				+ registered + ", creator=" + creator + ", created=" + created + ", hasData=" + hasData + "]";
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getSalt() {
		return salt;
	}

	public void setSalt(String salt) {
		this.salt = salt;
	}

	public int getGuestId() {
		return guestId;
	}

	public void setGuestId(int guestId) {
		this.guestId = guestId;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}
}

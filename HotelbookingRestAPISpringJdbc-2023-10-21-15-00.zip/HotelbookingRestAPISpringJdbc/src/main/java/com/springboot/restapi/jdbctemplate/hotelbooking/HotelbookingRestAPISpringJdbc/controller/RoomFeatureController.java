package com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.controller;

import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.RoomFeature;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.schema.IRoomFeatureRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;


@CrossOrigin(origins = "http://localhost:8088")
@RestController
@RequestMapping("/api/room-features")
public class RoomFeatureController {

    @Autowired
    IRoomFeatureRepository roomFeatureRepository;

    @GetMapping("/")
    public ResponseEntity<List<RoomFeature>> getRoomFeatures() {
        try {
            List<RoomFeature> roomFeatures = new ArrayList<>();

            for (RoomFeature roomFeature : roomFeatureRepository.getAll()) {
                roomFeature.setHasData(true);
                roomFeatures.add(roomFeature);
            }

            if (roomFeatures.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(roomFeatures, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/{roomid}/{id}")
    public ResponseEntity<RoomFeature> getRoomFeature(@PathVariable("roomid") int roomId, @PathVariable("id") int id) {
        RoomFeature roomFeature = roomFeatureRepository.getDataset(roomId, id);

        if (roomFeature != null) {
            return new ResponseEntity<>(roomFeature, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/by-room/{roomid}")
    public ResponseEntity<List<RoomFeature>> getRoomFeaturesByRoom(@PathVariable("roomid") int roomId) {

        try {
            List<RoomFeature> roomFeatures = new ArrayList<>();

            for (RoomFeature roomFeature : roomFeatureRepository.getAllByRoom(roomId)) {
                roomFeature.setHasData(true);
                roomFeatures.add(roomFeature);
            }

            if (roomFeatures.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(roomFeatures, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/")
    public ResponseEntity<Integer> createRoomFeature(@RequestBody RoomFeature roomFeature) {
        try {
            Integer newRoomFeatureId = roomFeatureRepository.create(roomFeature);
            return new ResponseEntity<>(newRoomFeatureId, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(0, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/{roomid}/{id}")
    public ResponseEntity<Integer> updateRoomFeature(@PathVariable("roomid") int roomId, @PathVariable("id")
        int optionId, @RequestBody RoomFeature roomFeature) {
        try {
            roomFeatureRepository.update(roomId, optionId, roomFeature);
            return new ResponseEntity<>(roomId, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(0, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/{roomid}/{id}")
    public ResponseEntity<String> deleteRoomFeature(@PathVariable("roomid") int roomId, @PathVariable("id") int optionId) {
        try {
            if (roomFeatureRepository.delete(roomId, optionId)) {
                return new ResponseEntity<>("Cannot find RoomFeature with optionId=" + optionId, HttpStatus.OK);
            }
            return new ResponseEntity<>("RoomFeature was deleted successfully.", HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("Cannot delete RoomFeature.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
package com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.controller;

import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.HotelOption;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.schema.IHotelOptionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;


@CrossOrigin(origins = "http://localhost:8088")
@RestController
@RequestMapping("/api/hotel-options")
public class HotelOptionController {

    @Autowired
    IHotelOptionRepository hotelOptionRepository;

    @GetMapping("/")
    public ResponseEntity<List<HotelOption>> getHotelOptions() {
        try {
            List<HotelOption> hotelOptions = new ArrayList<>();

            for (HotelOption hotelOption : hotelOptionRepository.getAll()) {
                hotelOption.setHasData(true);
                hotelOptions.add(hotelOption);
            }

            return new ResponseEntity<>(hotelOptions, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/{hotelid}/{id}")
    public ResponseEntity<HotelOption> getHotelOption(@PathVariable("hotelid") int hotelId, @PathVariable("id") int id) {
        HotelOption hotelOption = hotelOptionRepository.getDataset(hotelId, id);

        if (hotelOption != null) {
            return new ResponseEntity<>(hotelOption, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/by-hotel/{hotelid}")
    public ResponseEntity<List<HotelOption>> getHotelOptionsByHotel(@PathVariable("hotelid") int hotelId) {

        try {
            List<HotelOption> hotelOptions = new ArrayList<>();


            if(!hotelOptionRepository.getAllByHotel(hotelId).isEmpty()) {
                for (HotelOption hotelOption : hotelOptionRepository.getAllByHotel(hotelId)) {
                    hotelOption.setHasData(true);
                    hotelOptions.add(hotelOption);
                }
            }

            return new ResponseEntity<>(hotelOptions, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/")
    public ResponseEntity<Integer> createHotelOption(@RequestBody HotelOption hotelOption) {
        try {
            Integer newHotelOptionId = hotelOptionRepository.create(hotelOption);
            return new ResponseEntity<>(newHotelOptionId, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(0, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/{roomid}/{id}")
    public ResponseEntity<Integer> updateHotelOption(@PathVariable("roomid") int roomId, @PathVariable("id")
        int optionId, @RequestBody HotelOption hotelOption) {
        try {
            hotelOptionRepository.update(roomId, optionId, hotelOption);
            return new ResponseEntity<>(optionId, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(0, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/{roomid}/{id}")
    public ResponseEntity<Integer> deleteHotelOption(@PathVariable("roomid") int roomId, @PathVariable("id") int optionId) {
        try {
            hotelOptionRepository.delete(roomId, optionId);
            return new ResponseEntity<>(optionId, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(0, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
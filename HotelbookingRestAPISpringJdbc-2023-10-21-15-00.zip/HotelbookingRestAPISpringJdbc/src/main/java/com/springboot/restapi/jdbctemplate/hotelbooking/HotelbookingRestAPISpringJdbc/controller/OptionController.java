package com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.controller;

import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.Option;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.schema.IOptionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;


@CrossOrigin(origins = "http://localhost:8088")
@RestController
@RequestMapping("/api/options")
public class OptionController {

    @Autowired
    IOptionRepository optionRepository;

    @GetMapping("/")
    public ResponseEntity<List<Option>> getAllOptions() {
        try {
            List<Option> options = new ArrayList<>();

            for (Option option : optionRepository.getAll()) {
                option.setHasData(true);
                options.add(option);
            }

            if (options.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(options, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<Option> getOption(@PathVariable("id") int id) {
        Option option = optionRepository.getDataset(id);

        if (option != null) {
            return new ResponseEntity<>(option, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping("/")
    public ResponseEntity<Integer> createOption(@RequestBody Option option) {
        try {
            Integer newOptionId = optionRepository.create(option);
            return new ResponseEntity<>(newOptionId, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(0, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<Integer> updateOption(@PathVariable("id") int id, @RequestBody Option option) {
        try {
            optionRepository.update(id, option);
            return new ResponseEntity<>(id, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(0, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Integer> deleteOption(@PathVariable("id") int id) {
        try {
            optionRepository.delete(id);
            return new ResponseEntity<>(id, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(0, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
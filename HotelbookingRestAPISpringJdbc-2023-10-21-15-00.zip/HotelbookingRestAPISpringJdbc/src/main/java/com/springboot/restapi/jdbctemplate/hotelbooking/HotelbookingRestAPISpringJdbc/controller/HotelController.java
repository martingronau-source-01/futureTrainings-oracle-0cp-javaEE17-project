package com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.controller;

import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.Hotel;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.schema.IHotelRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@CrossOrigin(origins = "http://localhost:8088")
@RestController
@RequestMapping("/api/hotels")
public class HotelController {

    @Autowired
    IHotelRepository hotelRepository;

    @GetMapping("/")
    public ResponseEntity<List<Hotel>> getAllHotels() {
        try {
            List<Hotel> hotels = new ArrayList<Hotel>();

            for (Hotel hotel : hotelRepository.getAll()) {
                hotel.setHasData(true);
                hotels.add(hotel);
            }

            if (hotels.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(hotels, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/by-hoteloption/{hotelOptionid}")
    public ResponseEntity<List<Hotel>> getHotelsByHotelOption(@PathVariable("hotelOptionid") int hotelOptionId) {

        try {
            List<Hotel> hotels = new ArrayList<Hotel>();

            for (Hotel hotel : hotelRepository.getAllByHotelOption(hotelOptionId)) {
                hotel.setHasData(true);
                hotels.add(hotel);
            }

            if (hotels.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(hotels, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<Hotel> getHotel(@PathVariable("id") int id) {
        Hotel hotel = hotelRepository.getDataset(id);

        if (hotel != null) {
            return new ResponseEntity<>(hotel, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping("/")
    public ResponseEntity<Integer> createHotel(@RequestBody Hotel hotel) {
        try {
            Integer newHotelId = hotelRepository.create(hotel);
            return new ResponseEntity<>(newHotelId, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(0, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<Integer> updateHotel(@PathVariable("id") int id, @RequestBody Hotel hotel) {
        try {
            hotelRepository.update(id, hotel);
            return new ResponseEntity<>(id, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(0, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Integer> deleteHotel(@PathVariable("id") int id) {
        try {
            hotelRepository.delete(id);
            return new ResponseEntity<>(id, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(0, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
package com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.schema;

import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.common.exception.PersistenceException;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.Payment;

import java.util.List;

public interface IPaymentRepository {

    public int addPayment(Payment payment) throws PersistenceException;

    public boolean cancelPayment(int paymentId);

    public List<Payment> getAll() throws PersistenceException;

    public List<Payment> getAllByPaymentOption(int paymentOptionId) throws PersistenceException;

    public Payment getDataset(int paymentId);
}


package com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.schema;

import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.common.exception.PersistenceException;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.AccommodationSearchResult;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.Room;

import java.util.List;

public interface IAccommodationSearchRepository {
    public List<AccommodationSearchResult> searchOvernightStay(String region, String startDate, String endDate, int amountOfGuests,
                                                               int numberOfRooms) throws PersistenceException;

    public List<AccommodationSearchResult> searchOvernightStayExtended(String region, String startDate, String endDate, int amountOfGuests,
                                                                       int numberOfRooms, List<Integer> hotelOptions, List<Integer> roomFeatures) throws PersistenceException;

    public List<Room> searchOvernightStayRooms(String region, String startDate, String endDate, int amountOfGuests,
                                               int numberOfRooms) throws PersistenceException;
}



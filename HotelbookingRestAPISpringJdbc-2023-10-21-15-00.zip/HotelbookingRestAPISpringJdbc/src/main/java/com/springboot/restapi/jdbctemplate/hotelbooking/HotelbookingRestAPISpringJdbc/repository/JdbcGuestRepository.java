package com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.repository;

import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.common.exception.PersistenceException;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.Guest;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.schema.IGuestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class JdbcGuestRepository implements IGuestRepository {
    private final String SQLSELECTALL = "SELECT DISTINCT id, first_name, last_name,company_name,birth_date, "
            + "street, zipcode, location, email, phone, business, regular_customer, creator, created FROM guest ORDER BY id ";
    private final String SQLSELECTSINGLE = "SELECT DISTINCT id, first_name, last_name,company_name, birth_date,"
            + "street, zipcode, location, email, phone, business, regular_customer, creator, created FROM guest WHERE id = ? ";
    private final String SQLUPDATE = "UPDATE guest SET first_name = ?, last_name = ?, company_name = ?, birth_date = ?,"
            + "street= ?, zipcode = ?, location = ?, email= ?, phone = ?,business = ?, regular_customer = ? WHERE id = ? ";
    private final String SQLINSERT = "INSERT INTO guest(first_name, last_name,company_name, birth_date,street, zipcode, "
            + "location, email, phone, business, regular_customer,creator,created) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)";
    private final String SQLDELETE = "DELETE FROM guest WHERE id = ?";

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public int create(Guest guest) throws PersistenceException {
                int iReturn = 0;
                if(jdbcTemplate.update(SQLINSERT, guest.getFirstName(), guest.getLastName(), guest.getCompanyName(),
                guest.getBirthDate(),  guest.getStreet(), guest.getZipcode(), guest.getLocation(), guest.getEmail(),
                guest.getPhone(), guest.isBusiness(), guest.isRegularCustomer(), guest.getCreator(), guest.getCreated()) > 0) {
                    Integer newId = jdbcTemplate.queryForObject("SELECT LAST_INSERT_ID()", Integer.class);
                    iReturn = newId.intValue();
                }
                return iReturn;
    }

    @Override
    public List<Guest> getAll() throws PersistenceException {
        return jdbcTemplate.query(SQLSELECTALL, BeanPropertyRowMapper.newInstance(Guest.class));
    }

    @Override
    public boolean update(int guestId, Guest guest) {
        return jdbcTemplate.update(SQLUPDATE, guest.getFirstName(), guest.getLastName(), guest.getCompanyName(),
                guest.getBirthDate(),  guest.getStreet(), guest.getZipcode(), guest.getLocation(), guest.getEmail(),
                guest.getPhone(), guest.isBusiness(), guest.isRegularCustomer(), guestId) > 0;
    }

    @Override
    public Guest getDataset(int guestId) {
        try {
            return jdbcTemplate.queryForObject(SQLSELECTSINGLE,
                    BeanPropertyRowMapper.newInstance(Guest.class), guestId);
        } catch (EmptyResultDataAccessException e) {
            return null;
        }
    }

    @Override
    public boolean delete(int guestId) {
        return jdbcTemplate.update(SQLDELETE, guestId) > 0;
    }
}

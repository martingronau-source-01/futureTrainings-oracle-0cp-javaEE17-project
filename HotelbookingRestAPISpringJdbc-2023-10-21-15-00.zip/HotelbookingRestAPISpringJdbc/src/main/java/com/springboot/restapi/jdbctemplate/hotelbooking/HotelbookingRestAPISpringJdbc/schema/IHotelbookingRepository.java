package com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.schema;

import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.common.exception.PersistenceException;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.Hotelbooking;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.Booking;

import java.util.List;

public interface IHotelbookingRepository {

    public List<Hotelbooking> getAllByUser(int userId) throws PersistenceException;

    public int bookAccomodation(Hotelbooking hotelbooking) throws PersistenceException;

    public int cancelBooking(int bookingId);

    public int updateBooking(int bookingId, Hotelbooking booking);

    public int bookRoom2Accomodation(Booking booking) throws PersistenceException;

    public Hotelbooking getDataset(int bookingId) throws PersistenceException;
}


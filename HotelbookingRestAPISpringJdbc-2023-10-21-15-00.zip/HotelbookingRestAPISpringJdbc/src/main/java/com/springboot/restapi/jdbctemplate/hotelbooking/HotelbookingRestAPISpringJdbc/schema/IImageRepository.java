package com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.schema;

import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.common.exception.PersistenceException;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.Image;

import java.util.List;

public interface IImageRepository {

    public int create(Image image) throws PersistenceException;

    public List<Image> getAll() throws PersistenceException;

    public boolean update(int imageId, Image image);

    public Image getDataset(int imageId);

    public boolean delete(int imageId);
}

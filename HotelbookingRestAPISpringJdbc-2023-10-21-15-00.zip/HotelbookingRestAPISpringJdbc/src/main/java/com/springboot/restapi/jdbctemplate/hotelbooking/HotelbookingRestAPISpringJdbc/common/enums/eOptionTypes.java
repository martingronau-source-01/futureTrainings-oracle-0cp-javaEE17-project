package com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.common.enums;

public enum eOptionTypes {
	NO_OPTION(0), HOTEL_OPTION(1), ROOM_FEATURE(2), PAYMENT_OPTION(3);

	private int value;

	private eOptionTypes(int value) {
		this.value = value;
	}

	public int getValue() {
		return value;
	}
}

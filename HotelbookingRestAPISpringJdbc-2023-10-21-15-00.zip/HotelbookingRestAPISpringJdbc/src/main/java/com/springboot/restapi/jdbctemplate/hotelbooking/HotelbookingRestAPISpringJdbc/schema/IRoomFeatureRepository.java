package com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.schema;

import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.common.exception.PersistenceException;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.RoomFeature;

import java.util.List;

public interface IRoomFeatureRepository {

    public int create(RoomFeature roomFeature) throws PersistenceException;

    public List<RoomFeature> getAll() throws PersistenceException;

    public List<RoomFeature> getAllByRoom(int roomId) throws PersistenceException;

    public boolean update(int roomId, int optionId, RoomFeature option);

    public RoomFeature getDataset(int roomId, int optionId);

    public boolean delete(int roomId, int optionId);
}


package com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.schema;

import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.common.exception.PersistenceException;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.Hotel;

import java.util.List;

public interface IHotelRepository {

    public int create(Hotel hotel) throws PersistenceException;

    public List<Hotel> getAll() throws PersistenceException;

    public List<Hotel> getAllByHotelOption(int hotelOptionId) throws PersistenceException;

    public boolean update(int hotelId, Hotel hotel);

    public Hotel getDataset(int hotelId);

    public boolean delete(int hotelId);
}


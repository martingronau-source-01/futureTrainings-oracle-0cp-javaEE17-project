package com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.service;

import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.common.exception.PersistenceException;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.Hotelbooking;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.Room;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.repository.JdbcRoomRepository;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.Payment;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.schema.IHotelbookingRepository;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.schema.IPaymentRepository;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.schema.IRoomRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.net.URISyntaxException;
import java.util.List;

@Service
public class HotelbookingDataService {

    @Autowired
    IRoomRepository roomRepository;

    @Autowired
    RoomOccupancyDataService hotelOccupancyDataService;

    @Autowired
    PaymentDataService paymentDataService;

    @Autowired
    IHotelbookingRepository hotelbookingRepository;


    public int bookAccomodation(Hotelbooking hotelbooking) throws URISyntaxException {

        Room room;

        if (hotelbooking.getRoomId() == 0) {

            room = hotelOccupancyDataService.getNextFreeRoom(hotelbooking);

            hotelbooking.setRoomId(room.getId());
        } else {
            room = roomRepository.getDataset(hotelbooking.getRoomId());
        }

        if (hotelbooking.getPaymentId() == 0) {
            Payment payment = new Payment();

            paymentDataService.generateRandomPaymentValues(payment);

            double accommodationRawPrice = room.getAccommodationCost() * hotelbooking.getCountAccommodations();
            double mwst = accommodationRawPrice * 0.19;

            hotelbooking.setAccommodationsRawPrice(Math.round(accommodationRawPrice*100)/100.0);
            payment.setMwst(Math.round(mwst*100)/100.0);

            double totalCost = hotelbooking.getAccommodationsRawPrice() + payment.getMwst();
            payment.setTotalcost(Math.round(totalCost*100)/100.0);

            int paymentId = paymentDataService.addPayment(payment);
            hotelbooking.setPaymentId(paymentId);
        }

        return hotelbookingRepository.bookAccomodation(hotelbooking);
    }

    public List<Hotelbooking> getAllByUser(int userId) throws URISyntaxException {
        return hotelbookingRepository.getAllByUser(userId);
    }

    public Hotelbooking getHotelbooking(int bookingId) throws PersistenceException {
        return hotelbookingRepository.getDataset(bookingId);
    }

    public int updateBooking(int bookingId, Hotelbooking hotelbooking) {
        return hotelbookingRepository.updateBooking(bookingId, hotelbooking);
    }
    public int cancelBooking(int bookingId) {
        return  hotelbookingRepository.cancelBooking(bookingId);
    }

}

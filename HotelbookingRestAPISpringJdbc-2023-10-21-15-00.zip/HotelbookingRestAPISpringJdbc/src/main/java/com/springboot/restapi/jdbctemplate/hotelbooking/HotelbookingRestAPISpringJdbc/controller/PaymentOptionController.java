package com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.controller;

import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.PaymentOption;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.schema.IPaymentOptionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;


@CrossOrigin(origins = "http://localhost:8088")
@RestController
@RequestMapping("/api/payment-options")
public class PaymentOptionController {

    @Autowired
    IPaymentOptionRepository paymentOptionRepository;

    @GetMapping("/")
    public ResponseEntity<List<PaymentOption>> getPaymentOptions() {
        try {
            List<PaymentOption> paymentOptions = new ArrayList<>();

            for (PaymentOption paymentOption : paymentOptionRepository.getAll()) {
                paymentOption.setHasData(true);
                paymentOptions.add(paymentOption);
            }

            if (paymentOptions.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(paymentOptions, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/{paymentid}/{id}")
    public ResponseEntity<PaymentOption> getPaymentOption(@PathVariable("paymentid") int paymentId, @PathVariable("id") int id) {
        PaymentOption paymentOption = paymentOptionRepository.getDataset(paymentId, id);

        if (paymentOption != null) {
            return new ResponseEntity<>(paymentOption, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/{paymentid}")
    public ResponseEntity<List<PaymentOption>> getPaymentOptionsByHotel(@PathVariable("paymentid") int paymentId) {

        try {
            List<PaymentOption> paymentOptions = new ArrayList<>();

            for (PaymentOption paymentOption : paymentOptionRepository.getAllByPayment(paymentId)) {
                paymentOption.setHasData(true);
                paymentOptions.add(paymentOption);
            }

            if (paymentOptions.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(paymentOptions, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/")
    public ResponseEntity<Integer> createPaymentOption(@RequestBody PaymentOption paymentOption) {
        try {
            Integer newPaymentOptionId = paymentOptionRepository.create(paymentOption);
            return new ResponseEntity<>(newPaymentOptionId, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(0, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/{roomid}/{id}")
    public ResponseEntity<Integer> updatePaymentOption(@PathVariable("roomid") int roomId, @PathVariable("id")
        int optionId, @RequestBody PaymentOption paymentOption) {
        try {
            paymentOptionRepository.update(roomId, optionId, paymentOption);
            return new ResponseEntity<>(optionId, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(0, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/{roomid}/{id}")
    public ResponseEntity<String> deletePaymentOption(@PathVariable("roomid") int roomId, @PathVariable("id") int optionId) {
        try {
            if (paymentOptionRepository.delete(roomId, optionId)) {
                return new ResponseEntity<>("Cannot find PaymentOption with optionId=" + optionId, HttpStatus.OK);
            }
            return new ResponseEntity<>("PaymentOption was deleted successfully.", HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("Cannot delete PaymentOption.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
package com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model;

import java.util.Objects;

public class RoomImage {
    private int id = 0;
    private int roomId = 0;
    private int imageId = 0;
    private String imageCategory = "";
    private String creator = "";
    private String created = "";
    private boolean hasData = false;

    public RoomImage() {
    }

    public RoomImage(int id, int roomId, int imageId, String imageCategory, String creator,
                     String created, boolean hasData) {
        this(roomId, imageId, imageCategory, creator, created, hasData);
        this.id = id;
    }

    public RoomImage(int roomId, int imageId, String imageCategory, String creator,
                     String created, boolean hasData) {
        this.roomId = roomId;
        this.imageId = imageId;
        this.imageCategory = imageCategory;
        this.creator = creator;
        this.created = created;
        this.hasData = hasData;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getRoomId() {
        return roomId;
    }

    public void setRoomId(int roomId) {
        this.roomId = roomId;
    }

    public int getImageId() {
        return imageId;
    }

    public void setImageId(int imageId) {
        this.imageId = imageId;
    }

    public String getImageCategory() {
        return imageCategory;
    }

    public void setImageCategory(String imageCategory) {
        this.imageCategory = imageCategory;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public String getCreated() {
        return created;
    }

    public void setCreated(String created) {
        this.created = created;
    }

    public boolean isHasData() {
        return hasData;
    }

    public void setHasData(boolean hasData) {
        this.hasData = hasData;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof RoomImage that)) return false;
        return getId() == that.getId() && getRoomId() == that.getRoomId() && getImageId() == that.getImageId()
                && isHasData() == that.isHasData() && Objects.equals(getImageCategory(), that.getImageCategory())
                && Objects.equals(getCreator(), that.getCreator()) && Objects.equals(getCreated(), that.getCreated());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getRoomId(), getImageId(), getImageCategory(), getCreator(), getCreated(), isHasData());
    }

    @Override
    public String toString() {
        return "RoomImage{" +
                "id=" + id +
                ", roomId=" + roomId +
                ", imageId=" + imageId +
                ", imageCategory='" + imageCategory + '\'' +
                ", creator='" + creator + '\'' +
                ", created='" + created + '\'' +
                ", hasData=" + hasData +
                '}';
    }
}


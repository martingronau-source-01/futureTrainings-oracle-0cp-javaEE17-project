package com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.schema;

import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.common.exception.PersistenceException;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.Region;

import java.util.List;

public interface IRegionRepository {

    public int create(Region region) throws PersistenceException;

    public List<Region> getAll() throws PersistenceException;

    public boolean update(int regionId, Region region);

    public Region getDataset(int regionId);

    public boolean delete(int regionId);
}


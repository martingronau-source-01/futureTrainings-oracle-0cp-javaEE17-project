package com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model;

import java.util.Objects;

public class HotelImage {
    private int id = 0;
    private int hotelId = 0;
    private int imageId = 0;
    private String imageCategory = "";
    private String creator = "";
    private String created = "";
    private boolean hasData = false;

    public HotelImage() {
    }

    public HotelImage(int id, int hotelId, int imageId, String imageCategory, String creator,
                      String created, boolean hasData) {
        this(hotelId, imageId, imageCategory, creator, created, hasData);
        this.id = id;
    }

    public HotelImage(int hotelId, int imageId, String imageCategory, String creator,
                      String created, boolean hasData) {
        this.hotelId = hotelId;
        this.imageId = imageId;
        this.imageCategory = imageCategory;
        this.creator = creator;
        this.created = created;
        this.hasData = hasData;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getHotelId() {
        return hotelId;
    }

    public void setHotelId(int hotelId) {
        this.hotelId = hotelId;
    }

    public int getImageId() {
        return imageId;
    }

    public void setImageId(int imageId) {
        this.imageId = imageId;
    }

    public String getImageCategory() {
        return imageCategory;
    }

    public void setImageCategory(String imageCategory) {
        this.imageCategory = imageCategory;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public String getCreated() {
        return created;
    }

    public void setCreated(String created) {
        this.created = created;
    }

    public boolean isHasData() {
        return hasData;
    }

    public void setHasData(boolean hasData) {
        this.hasData = hasData;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof HotelImage that)) return false;
        return getId() == that.getId() && getHotelId() == that.getHotelId() && getImageId() == that.getImageId()
                && isHasData() == that.isHasData() && Objects.equals(getImageCategory(), that.getImageCategory())
                && Objects.equals(getCreator(), that.getCreator()) && Objects.equals(getCreated(), that.getCreated());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getHotelId(), getImageId(), getImageCategory(), getCreator(), getCreated(), isHasData());
    }

    @Override
    public String toString() {
        return "HotelImage{" +
                "id=" + id +
                ", hotelId=" + hotelId +
                ", imageId=" + imageId +
                ", imageCategory='" + imageCategory + '\'' +
                ", creator='" + creator + '\'' +
                ", created='" + created + '\'' +
                ", hasData=" + hasData +
                '}';
    }
}

package com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.schema;

import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.common.exception.PersistenceException;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.HotelOption;

import java.util.List;

public interface IHotelOptionRepository {

    public int create(HotelOption hotelOption) throws PersistenceException;

    public List<HotelOption> getAll() throws PersistenceException;

    public List<HotelOption> getAllByHotel(int hotelId) throws PersistenceException;

    public boolean update(int hotelId, int optionId, HotelOption option);

    public HotelOption getDataset(int hotelId, int optionId);

    public boolean delete(int hotelId, int optionId);
}


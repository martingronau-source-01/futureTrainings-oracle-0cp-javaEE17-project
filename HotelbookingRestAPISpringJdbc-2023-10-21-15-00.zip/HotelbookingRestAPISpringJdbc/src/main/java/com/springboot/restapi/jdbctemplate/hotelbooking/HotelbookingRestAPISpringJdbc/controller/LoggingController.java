package com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.controller;

import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.Logging;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.schema.ILoggingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;


@CrossOrigin(origins = "http://localhost:8088")
@RestController
@RequestMapping("/api/loggings")
public class LoggingController {

    @Autowired
    ILoggingRepository loggingRepository;

    @GetMapping("/")
    public ResponseEntity<List<Logging>> getLoggings() {
        try {
            List<Logging> loggings = new ArrayList<>();

            for (Logging logging : loggingRepository.getAll()) {
                logging.setHasData(true);
                loggings.add(logging);
            }

            if (loggings.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(loggings, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<Logging> getLogging(@PathVariable("id") int id) {
        Logging logging = loggingRepository.getDataset(id);

        if (logging != null) {
            return new ResponseEntity<>(logging, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/by-userid/{userid}")
    public ResponseEntity<List<Logging>> getLoggingsByUser(@RequestParam("userid") int userId) {

        try {
            List<Logging> loggings = new ArrayList<Logging>();

            for (Logging logging : loggingRepository.getLoggingsByUser(userId)) {
                logging.setHasData(true);
                loggings.add(logging);
            }

            if (loggings.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(loggings, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/")
    public ResponseEntity<Integer> createLogging(@RequestBody Logging logging) {
        try {
            Integer newLoggingId = loggingRepository.addLogging(logging);
            return new ResponseEntity<>(newLoggingId, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(0, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Integer> clearLoggingsByUser(@PathVariable("userid") int userId) {
        try {
            loggingRepository.clearLoggingsByUser(userId);
                return new ResponseEntity<>(userId, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(0, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/")
    public ResponseEntity<Integer> clearLoggings() {
        try {
            loggingRepository.clearLoggings();
            return new ResponseEntity<>(0, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
package com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.controller;

import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.Hotel;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.Payment;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.schema.IPaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;


@CrossOrigin(origins = "http://localhost:9099")
@RestController
@RequestMapping("/api/payments")
public class PaymentController {

    @Autowired
    IPaymentRepository paymentRepository;


    @PostMapping("/")
    public ResponseEntity<Integer> addPayment(@RequestBody Payment payment) {
        try {
            Integer newPaymentId = paymentRepository.addPayment(payment);
            return new ResponseEntity<>(newPaymentId, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Integer> cancelPayment(@PathVariable("id") int paymentId) {
        try {
            if (paymentRepository.cancelPayment(paymentId)) {
                return new ResponseEntity<>(paymentId, HttpStatus.OK);
            }
            return new ResponseEntity<>(0, HttpStatus.NOT_MODIFIED);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/")
    public ResponseEntity<List<Payment>> getAllPayments() {
        try {
            List<Payment> payments = new ArrayList<>();

            for (Payment payment : paymentRepository.getAll()) {
                payment.setHasData(true);
                payments.add(payment);
            }

            if (payments.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(payments, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/by-paymentoption/{paymentOptionid}")
    public ResponseEntity<List<Payment>> getAllPaymentsByPaymentOption(@PathVariable("paymentOptionid") int paymentOptionId) {

        try {
            List<Payment> payments = new ArrayList<>();

            for (Payment payment : paymentRepository.getAllByPaymentOption(paymentOptionId)) {
                payment.setHasData(true);
                payments.add(payment);
            }

            if (payments.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(payments, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    @GetMapping("/{id}")
    public ResponseEntity<Payment> getPayment(@PathVariable("id") int id) {
        Payment payment = paymentRepository.getDataset(id);

        if (payment != null) {
            return new ResponseEntity<>(payment, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

}
package com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model;

import java.util.Objects;

public class Image {

    private int id = 0;
    private int lfdNr = 0;
    private String imgTitle = "";
    private String imgDescription = "";
    private String name = "";
    private String fileName = "";
    private String uploadName = "";
    private String tempName = "";
    private double size = 0.00;
    private String type = "";
    private boolean renderImage = false;
    private boolean showStatus = false;
    private String creator = "";
    private String created = "";
    private boolean hasData = false;

    public Image() {
    }

    public Image(int id, int lfdNr, String imgTitle, String imgDescription, String name, String fileName,
                 String uploadName, String tempName, double size, String type, boolean renderImage,
                 boolean showStatus, String creator, String created, boolean hasData) {
        this(lfdNr, imgTitle, imgDescription, name, fileName, uploadName, tempName, size, type, renderImage,
                showStatus, creator, created, hasData);
        this.id = id;
    }

    public Image(int lfdNr, String imgTitle, String imgDescription, String name, String fileName, String uploadName,
                 String tempName, double size, String type, boolean renderImage, boolean showStatus,
                 String creator, String created, boolean hasData) {
        this.lfdNr = lfdNr;
        this.imgTitle = imgTitle;
        this.imgDescription = imgDescription;
        this.name = name;
        this.fileName = fileName;
        this.uploadName = uploadName;
        this.tempName = tempName;
        this.size = size;
        this.type = type;
        this.renderImage = renderImage;
        this.showStatus = showStatus;
        this.creator = creator;
        this.created = created;
        this.hasData = hasData;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getLfdNr() {
        return lfdNr;
    }

    public void setLfdNr(int lfdNr) {
        this.lfdNr = lfdNr;
    }

    public String getImgTitle() {
        return imgTitle;
    }

    public void setImgTitle(String imgTitle) {
        this.imgTitle = imgTitle;
    }

    public String getImgDescription() {
        return imgDescription;
    }

    public void setImgDescription(String imgDescription) {
        this.imgDescription = imgDescription;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getUploadName() {
        return uploadName;
    }

    public void setUploadName(String uploadName) {
        this.uploadName = uploadName;
    }

    public String getTempName() {
        return tempName;
    }

    public void setTempName(String tempName) {
        this.tempName = tempName;
    }

    public double getSize() {
        return size;
    }

    public void setSize(double size) {
        this.size = size;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public boolean isRenderImage() {
        return renderImage;
    }

    public void setRenderImage(boolean renderImage) {
        this.renderImage = renderImage;
    }

    public boolean isShowStatus() {
        return showStatus;
    }

    public void setShowStatus(boolean showStatus) {
        this.showStatus = showStatus;
    }

    @Override
    public String toString() {
        return "Image{" +
                "id=" + id +
                ", lfdNr=" + lfdNr +
                ", imgTitle='" + imgTitle + '\'' +
                ", imgDescription='" + imgDescription + '\'' +
                ", name='" + name + '\'' +
                ", fileName='" + fileName + '\'' +
                ", uploadName='" + uploadName + '\'' +
                ", tempName='" + tempName + '\'' +
                ", size=" + size +
                ", type='" + type + '\'' +
                ", renderImage=" + renderImage +
                ", showStatus=" + showStatus +
                ", creator='" + creator + '\'' +
                ", created='" + created + '\'' +
                ", hasData=" + hasData +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Image image)) return false;
        return getId() == image.getId() && getLfdNr() == image.getLfdNr() && Double.compare(getSize(),
                image.getSize()) == 0 && isRenderImage() == image.isRenderImage()
                && isShowStatus() == image.isShowStatus() && isHasData() == image.isHasData()
                && Objects.equals(getImgTitle(), image.getImgTitle()) && Objects.equals(getImgDescription(),
                image.getImgDescription()) && Objects.equals(getName(), image.getName())
                && Objects.equals(getFileName(), image.getFileName()) && Objects.equals(getUploadName(),
                image.getUploadName()) && Objects.equals(getTempName(), image.getTempName())
                && Objects.equals(getType(), image.getType()) && Objects.equals(getCreator(), image.getCreator())
                && Objects.equals(getCreated(), image.getCreated());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getLfdNr(), getImgTitle(), getImgDescription(), getName(), getFileName(),
                getUploadName(), getTempName(), getSize(), getType(), isRenderImage(), isShowStatus(), getCreator(),
                getCreated(), isHasData());
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public String getCreated() {
        return created;
    }

    public void setCreated(String created) {
        this.created = created;
    }

    public boolean isHasData() {
        return hasData;
    }

    public void setHasData(boolean hasData) {
        this.hasData = hasData;
    }

}

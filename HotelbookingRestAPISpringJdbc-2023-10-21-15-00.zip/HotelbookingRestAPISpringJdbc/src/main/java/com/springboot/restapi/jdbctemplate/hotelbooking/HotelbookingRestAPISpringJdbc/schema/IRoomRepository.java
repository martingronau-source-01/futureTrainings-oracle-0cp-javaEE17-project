package com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.schema;

import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.common.exception.PersistenceException;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.Room;

import java.util.List;

public interface IRoomRepository {

    public int create(Room room) throws PersistenceException;

    public List<Room> getAll() throws PersistenceException;

    public List<Room> getAllByRoomFeature(int roomFeatureId) throws PersistenceException;

    public boolean update(int roomId, Room room);

    public Room getDataset(int roomId);

    public boolean delete(int roomId);
}


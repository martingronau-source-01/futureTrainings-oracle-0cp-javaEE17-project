package com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model;

import java.util.Objects;

public class Role {
	private int id = 0;
	private String name = "";
	private String title = "";
	private String description = "";
	private Integer roleType = null;
	private String creator = "";
	private String created = "";
	private boolean hasData = false;

	public Role() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Role(int id, String name, String title, String description, int roleType, String creator,
			String created) {
		super();
		this.id = id;
		this.name = name;
		this.title = title;
		this.description = description;
		this.setRoleType(roleType);
		this.creator = creator;
		this.created = created;
	}

	@Override
	public int hashCode() {
		return Objects.hash(id, created, creator, description, hasData, name, title);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Role other = (Role) obj;
		return id == other.id && Objects.equals(created, other.created) && Objects.equals(creator, other.creator)
				&& Objects.equals(description, other.description) && hasData == other.hasData
				&& Objects.equals(name, other.name) && Objects.equals(title, other.title);
	}

	@Override
	public String toString() {
		return "Role [id=" + id + ", name=" + name + ", title=" + title + ", description=" + description + ", creator="
				+ creator + ", created=" + created + ", hasData=" + hasData + "]";
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public String getCreated() {
		return created;
	}

	public void setCreated(String created) {
		this.created = created;
	}

	public boolean isHasData() {
		return hasData;
	}

	public void setHasData(boolean hasData) {
		this.hasData = hasData;
	}

	public int getRoleType() {
		return roleType;
	}

	public void setRoleType(int roleType) {
		this.roleType = roleType;
	}

}

package com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.schema;

import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.common.exception.PersistenceException;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.Role;

import java.util.List;

public interface IRoleRepository {

    public int create(Role role) throws PersistenceException;

    public List<Role> getAll() throws PersistenceException;

    public boolean update(int roleId, Role role);

    public Role getDataset(int roleId);

    public boolean delete(int roleId);
}


package com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.schema;

import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.common.exception.PersistenceException;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.RoomImage;

import java.util.List;

public interface IRoomImageRepository {

    public int create(RoomImage roomImage) throws PersistenceException;

    public List<RoomImage> getAll() throws PersistenceException;

    public List<RoomImage> getAllByRoom(int roomId) throws PersistenceException;

    public boolean update(int roomId, int optionId, RoomImage option);

    public RoomImage getDataset(int roomId, int optionId);

    public boolean delete(int roomId, int optionId);
}

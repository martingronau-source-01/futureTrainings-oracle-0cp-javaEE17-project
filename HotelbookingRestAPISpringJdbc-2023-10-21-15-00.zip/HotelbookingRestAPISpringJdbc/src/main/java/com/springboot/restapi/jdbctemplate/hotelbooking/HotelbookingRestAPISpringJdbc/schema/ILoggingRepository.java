package com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.schema;

import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.common.exception.PersistenceException;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.Logging;

import java.util.List;

public interface ILoggingRepository {

    public int addLogging(Logging logging) throws PersistenceException;

    public boolean clearLoggings() throws PersistenceException;

    public boolean clearLoggingsByUser(int loginId) throws PersistenceException;

    public Logging getDataset(int loggingId);

    public List<Logging> getAll() throws PersistenceException;

    public List<Logging> getLoggingsByUser(int userId) throws PersistenceException;
}



package com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model;

import java.util.Objects;

public class Option {

	private int id = 0;
	private String name = "";
	private String title = "";
	private String description = "";
	private int optionType;
	private String creator = "";
	private String created = "";
	private boolean hasData = false;

	public Option() {
		super();
	}

	public Option(int id, String name, String title, String description, int optionType, String creator,
			String created, boolean hasData) {
		this(name,title,description,optionType,creator,created,hasData);
		this.id = id;
	}

	public Option(String name, String title, String description, int optionType, String creator,
			String created, boolean hasData) {
		super();
		this.name = name;
		this.title = title;
		this.description = description;
		this.optionType = optionType;
		this.creator = creator;
		this.created = created;
		this.hasData = hasData;
	}
	
	@Override
	public String toString() {
		return "Option [id=" + id + ", name=" + name + ", title=" + title + ", description=" + description
				+ ", optionType=" + optionType + ", creator=" + creator + ", created=" + created + ", hasData="
				+ hasData + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(id, created, creator, description, hasData, name, optionType, title);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Option other = (Option) obj;
		return id == other.id && Objects.equals(created, other.created) && Objects.equals(creator, other.creator)
				&& Objects.equals(description, other.description) && hasData == other.hasData
				&& Objects.equals(name, other.name) && optionType == other.optionType
				&& Objects.equals(title, other.title);
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getOptionType() {
		return optionType;
	}

	public void setOptionType(int optionType) {
		this.optionType = optionType;
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public String getCreated() {
		return created;
	}

	public void setCreated(String created) {
		this.created = created;
	}

	public boolean isHasData() {
		return hasData;
	}

	public void setHasData(boolean hasData) {
		this.hasData = hasData;
	}

}

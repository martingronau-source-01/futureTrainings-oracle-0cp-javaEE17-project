package com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.common;

import java.time.format.DateTimeFormatter;

import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.common.exception.PersistenceException;

public class DBUtils {
	
	public static final DateTimeFormatter CUSTOM_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
	public static final DateTimeFormatter CUSTOM_FORMATTER_GERMAN = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm");
	public static final DateTimeFormatter CUSTOM_FORMATTER_GERMAN_SHORT = DateTimeFormatter.ofPattern("dd.MM.yyyy");

	public static final String PAYMENT_BASE_NAME = "Rechnung_";
	public static final String INVOICE_NUMBER_BASE_NAME = "RNG_";
	public static final String DEFAULT_CURRENCY = "EUR";
	public static final String DEFAULT_CREATOR = "MG";

	public DBUtils() {
	}


	protected int getLastIDFromTable(String sTable, String sPKey) {
		int iNewId = 0;

		String sSQL = "SELECT MAX(" + sPKey + ") as NewKey FROM " + sTable;

		/*
		try (Connection connection = DataSourceHelper.getConnection();
				Statement statement = connection.createStatement();
				ResultSet resultSet = statement.executeQuery(sSQL)) {

			if (resultSet != null) {
				while (resultSet.next()) {
					iNewId = resultSet.getInt("NewKey") > 0 ? resultSet.getInt("NewKey") : 1;
				}
			}
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null,
					"SQL-Fehler in JdbcSystemDataSource::getLastIDFromTable(String, String): " + sSQL + e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null,
					"Allgemeiner Fehler in JdbcSystemDataSource::getLastIDFromTable(String, String): "
							+ e.getMessage());
			e.printStackTrace();
		} finally {
			// mCon.closeConnection();
			return iNewId;
		}
*/
		return  0;
	}
}

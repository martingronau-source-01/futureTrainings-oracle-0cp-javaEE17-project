package com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.service;

import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.Booking;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.Room;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.schema.IRoomOccupancyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RoomOccupancyDataService {

    @Autowired
    IRoomOccupancyRepository roomOccupancyRepository;

    public RoomOccupancyDataService() {
    }

    public List<Room> listFreeRooms(Booking booking) {
        try {
            return roomOccupancyRepository.listFreeRooms(booking);
        } catch (Exception e) {
            return null;
        }
    }

    public Room getNextFreeRoom(Booking booking) {
        try {
            return roomOccupancyRepository.getNextFreeRoom(booking);
        } catch (Exception e) {
            return null;
        }
    }

}

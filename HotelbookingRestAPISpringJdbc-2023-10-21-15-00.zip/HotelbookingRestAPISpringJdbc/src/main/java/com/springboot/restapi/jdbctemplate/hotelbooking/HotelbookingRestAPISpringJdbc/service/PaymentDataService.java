package com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.service;

import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.common.DBUtils;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.Payment;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.repository.JdbcPaymentRepository;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.schema.IPaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.net.URISyntaxException;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Random;

@Service
public class PaymentDataService {

    @Autowired
    IPaymentRepository paymentRepository;
    public void generateRandomPaymentValues(Payment payment) {

        Random random = new Random();

        Integer.valueOf(random.nextInt());
        payment.setInvoiceNumber(DBUtils.INVOICE_NUMBER_BASE_NAME + random.nextInt(99999) + "_HB");
        payment.setName(DBUtils.PAYMENT_BASE_NAME + random.nextInt() + "_" + LocalDateTime.now().format(DBUtils.CUSTOM_FORMATTER));
        payment.setTitle("Ihre " + payment.getName());
        payment.setDescription("Rechnung zum " + LocalDateTime.now().format(DBUtils.CUSTOM_FORMATTER_GERMAN));
        payment.setWaehrung(DBUtils.DEFAULT_CURRENCY);
        payment.setCreated(LocalDateTime.now().format(DBUtils.CUSTOM_FORMATTER));
        payment.setCreator(DBUtils.DEFAULT_CREATOR);
    }
    public List<Payment> getPayments() {
        return paymentRepository.getAll();
    }
    public List<Payment> getPaymentsByPaymentOption(int paymentOptionId) {
        return paymentRepository.getAllByPaymentOption(paymentOptionId);
    }

    public Payment getPayment(int id) {
        return paymentRepository.getDataset(id);
    }

    public boolean cancelPayment(int paymentId) {
        return paymentRepository.cancelPayment(paymentId);
    }

    public int addPayment(Payment payment) throws URISyntaxException {
        return paymentRepository.addPayment(payment);
    }

}

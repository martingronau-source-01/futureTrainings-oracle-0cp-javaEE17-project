package com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.schema;

import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.common.exception.PersistenceException;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.PaymentOption;

import java.util.List;

public interface IPaymentOptionRepository {

    public int create(PaymentOption paymentOption) throws PersistenceException;

    public List<PaymentOption> getAll() throws PersistenceException;

    public List<PaymentOption> getAllByPayment(int paymentId) throws PersistenceException;

    public boolean update(int paymentId, int optionId, PaymentOption paymentOption);

    public PaymentOption getDataset(int paymentId, int optionId);

    public boolean delete(int paymentId, int optionId);
}


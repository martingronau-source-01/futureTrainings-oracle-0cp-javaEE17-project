package com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model;

import java.util.Objects;

public class Hotelbooking extends Booking {

	private int roomOccupancyId = 0;
	private int paymentId = 0;
	private int countAccommodations = 0;
	private double accommodationsRawPrice = 0.00;
	private String formattedAccommodationsRawPrice = "";	
	private double accommodationPositionMwst = 0.00;
	private String formattedAccommodationsPositionMwst = "";	
	private int bookingId = 0;
	private String roomName = "";
	private String roomTitle = "";
	private double totalcost = 0.00;
	private String formattedTotalcost = "";
	private double mwst = 0.00;
	private String formattedMwst = "";
	private String hotelTitle = "";
	private String hotelName = "";
	private String hotelStreet = "";
	private String hotelZipcode = "";
	private String hotelLocation = "";
	private String hotelEMail = "";
	private String hotelWebsite = "";
	private String regionName = "";
	private String regionTitle = "";
	private String invoiceNumber = "";
	
	public String getHotelZipcode() {
		return hotelZipcode;
	}

	public void setHotelZipcode(String hotelZipcode) {
		this.hotelZipcode = hotelZipcode;
	}

	public String getHotelLocation() {
		return hotelLocation;
	}

	public void setHotelLocation(String hotelLocation) {
		this.hotelLocation = hotelLocation;
	}

	public String getHotelEMail() {
		return hotelEMail;
	}

	public void setHotelEMail(String hotelEMail) {
		this.hotelEMail = hotelEMail;
	}

	public String getRegionName() {
		return regionName;
	}

	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}

	public String getRegionTitle() {
		return regionTitle;
	}

	public void setRegionTitle(String regionTitle) {
		this.regionTitle = regionTitle;
	}

	private double singleRawPrice = 0.00;
	private String formattedSingleRawPrice = "";	


	public Hotelbooking() {
		super();
	}

	public Hotelbooking(int id, String startDate, String endDate, int hotelId, int guestId, int roomId, int roomOccupancyId,
			int paymentId, int countAccommodations, double accommodationsRawPrice,  int bookingId, String roomName, String roomTitle, 
			double totalcost, double mwst, String hotelTitle, String hotelName, double singleRowPrice, String created, 
			String creator, boolean hasData) {
		this(startDate, endDate, hotelId, guestId, roomId, roomOccupancyId, paymentId, countAccommodations, accommodationsRawPrice, 
			bookingId, roomName, roomTitle, totalcost, mwst, hotelTitle, hotelName, singleRowPrice,created, created, hasData);
		this.setId(id);
	}

	public Hotelbooking(int id, String startDate, String endDate, int hotelId, int guestId, int roomId, int roomOccupancyId,
			int paymentId, int countAccommodations, double accommodationsRawPrice,  String created, String creator, boolean hasData) {
		super(id, startDate, endDate, hotelId, guestId, roomId, created, created, hasData);
		this.roomOccupancyId = roomOccupancyId;
		this.paymentId = paymentId;
		this.countAccommodations = countAccommodations;
		this.accommodationsRawPrice = accommodationsRawPrice;
	}

	public Hotelbooking(String startDate, String endDate, int hotelId, int guestId, int roomId, int roomOccupancyId, 
			int paymentId, int countAccommodations, double accommodationsRawPrice,
			int bookingId, String roomName, String roomTitle, double totalcost, double mwst, String hotelTitle,
			String hotelName, double singleRawPrice, String created, String creator, boolean hasData) {
		super();
		this.roomOccupancyId = roomOccupancyId;
		this.paymentId = paymentId;
		this.countAccommodations = countAccommodations;
		this.accommodationsRawPrice = accommodationsRawPrice;
		this.bookingId = bookingId;
		this.roomName = roomName;
		this.roomTitle = roomTitle;
		this.totalcost = totalcost;
		this.mwst = mwst;
		this.hotelTitle = hotelTitle;
		this.hotelName = hotelName;
		this.singleRawPrice = singleRawPrice;
		this.setCreated(created);
		this.setCreator(creator);
		this.setHasData(hasData);
	}
	
	public int getBookingId() {
		return bookingId;
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	public String getRoomName() {
		return roomName;
	}

	public void setRoomName(String roomName) {
		this.roomName = roomName;
	}

	public String getRoomTitle() {
		return roomTitle;
	}

	@Override
	public String toString() {
		return super.toString()+" - Hotelbooking{" +
				"roomOccupancyId=" + roomOccupancyId +
				", paymentId=" + paymentId +
				", countAccommodations=" + countAccommodations +
				", accommodationsRawPrice=" + accommodationsRawPrice +
				", formattedAccommodationsRawPrice='" + formattedAccommodationsRawPrice + '\'' +
				", accommodationPositionMwst=" + accommodationPositionMwst +
				", formattedAccommodationsPositionMwst='" + formattedAccommodationsPositionMwst + '\'' +
				", bookingId=" + bookingId +
				", roomName='" + roomName + '\'' +
				", roomTitle='" + roomTitle + '\'' +
				", totalcost=" + totalcost +
				", formattedTotalcost='" + formattedTotalcost + '\'' +
				", mwst=" + mwst +
				", formattedMwst='" + formattedMwst + '\'' +
				", hotelTitle='" + hotelTitle + '\'' +
				", hotelName='" + hotelName + '\'' +
				", hotelStreet='" + hotelStreet + '\'' +
				", hotelZipcode='" + hotelZipcode + '\'' +
				", hotelLocation='" + hotelLocation + '\'' +
				", hotelEMail='" + hotelEMail + '\'' +
				", hotelWebsite='" + hotelWebsite + '\'' +
				", regionName='" + regionName + '\'' +
				", regionTitle='" + regionTitle + '\'' +
				", invoiceNumber='" + invoiceNumber + '\'' +
				", singleRawPrice=" + singleRawPrice +
				", formattedSingleRawPrice='" + formattedSingleRawPrice + '\'' +
				'}';
	}

	public void setRoomTitle(String roomTitle) {
		this.roomTitle = roomTitle;
	}

	public double getTotalcost() {
		return totalcost;
	}

	public void setTotalcost(double totalcost) {
		this.totalcost = totalcost;
	}

	public double getMwst() {
		return mwst;
	}

	public void setMwst(double mwst) {
		this.mwst = mwst;
	}

	public String getHotelTitle() {
		return hotelTitle;
	}

	public void setHotelTitle(String hotelTitle) {
		this.hotelTitle = hotelTitle;
	}

	public String getHotelName() {
		return hotelName;
	}

	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}

	public double getSingleRawPrice() {
		return singleRawPrice;
	}

	public void setSingleRawPrice(double singleRawPrice) {
		this.singleRawPrice = singleRawPrice;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Objects.hash(accommodationPositionMwst, accommodationsRawPrice, bookingId,
				countAccommodations, formattedAccommodationsPositionMwst, formattedAccommodationsRawPrice,
				formattedMwst, formattedSingleRawPrice, formattedTotalcost, hotelEMail, hotelLocation, hotelName,
				hotelStreet, hotelTitle, hotelWebsite, hotelZipcode, invoiceNumber, mwst, paymentId, regionName,
				regionTitle, roomName, roomOccupancyId, roomTitle, singleRawPrice, totalcost);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Hotelbooking other = (Hotelbooking) obj;
		return Double.doubleToLongBits(accommodationPositionMwst) == Double
				.doubleToLongBits(other.accommodationPositionMwst)
				&& Double.doubleToLongBits(accommodationsRawPrice) == Double
						.doubleToLongBits(other.accommodationsRawPrice)
				&& bookingId == other.bookingId && countAccommodations == other.countAccommodations
				&& Objects.equals(formattedAccommodationsPositionMwst, other.formattedAccommodationsPositionMwst)
				&& Objects.equals(formattedAccommodationsRawPrice, other.formattedAccommodationsRawPrice)
				&& Objects.equals(formattedMwst, other.formattedMwst)
				&& Objects.equals(formattedSingleRawPrice, other.formattedSingleRawPrice)
				&& Objects.equals(formattedTotalcost, other.formattedTotalcost)
				&& Objects.equals(hotelEMail, other.hotelEMail) && Objects.equals(hotelLocation, other.hotelLocation)
				&& Objects.equals(hotelName, other.hotelName) && Objects.equals(hotelStreet, other.hotelStreet)
				&& Objects.equals(hotelTitle, other.hotelTitle) && Objects.equals(hotelWebsite, other.hotelWebsite)
				&& Objects.equals(hotelZipcode, other.hotelZipcode)
				&& Objects.equals(invoiceNumber, other.invoiceNumber)
				&& Double.doubleToLongBits(mwst) == Double.doubleToLongBits(other.mwst) && paymentId == other.paymentId
				&& Objects.equals(regionName, other.regionName) && Objects.equals(regionTitle, other.regionTitle)
				&& Objects.equals(roomName, other.roomName) && roomOccupancyId == other.roomOccupancyId
				&& Objects.equals(roomTitle, other.roomTitle)
				&& Double.doubleToLongBits(singleRawPrice) == Double.doubleToLongBits(other.singleRawPrice)
				&& Double.doubleToLongBits(totalcost) == Double.doubleToLongBits(other.totalcost);
	}

	public int getRoomOccupancyId() {
		return roomOccupancyId;
	}

	public void setRoomOccupancyId(int roomOccupancyId) {
		this.roomOccupancyId = roomOccupancyId;
	}

	public int getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(int paymentId) {
		this.paymentId = paymentId;
	}

	public int getCountAccommodations() {
		return countAccommodations;
	}

	public void setCountAccommodations(int countAccommodations) {
		this.countAccommodations = countAccommodations;
	}

	public double getAccommodationsRawPrice() {
		return accommodationsRawPrice;
	}

	public void setAccommodationsRawPrice(double accommodationsRawPrice) {
		this.accommodationsRawPrice = accommodationsRawPrice;
	}

	public String getFormattedAccommodationsRawPrice() {
		return formattedAccommodationsRawPrice;
	}

	public void setFormattedAccommodationsRawPrice(String formattedAccommodationsRawPrice) {
		this.formattedAccommodationsRawPrice = formattedAccommodationsRawPrice;
	}

	public String getFormattedTotalcost() {
		return formattedTotalcost;
	}

	public void setFormattedTotalcost(String formattedTotalcost) {
		this.formattedTotalcost = formattedTotalcost;
	}

	public String getFormattedSingleRawPrice() {
		return formattedSingleRawPrice;
	}

	public void setFormattedSingleRawPrice(String formattedSingleRawPrice) {
		this.formattedSingleRawPrice = formattedSingleRawPrice;
	}

	public String getFormattedMwst() {
		return formattedMwst;
	}

	public void setFormattedMwst(String formattedMwst) {
		this.formattedMwst = formattedMwst;
	}

	public String getHotelStreet() {
		return hotelStreet;
	}

	public void setHotelStreet(String hotelStreet) {
		this.hotelStreet = hotelStreet;
	}

	public String getHotelWebsite() {
		return hotelWebsite;
	}

	public void setHotelWebsite(String hotelWebsite) {
		this.hotelWebsite = hotelWebsite;
	}

	public double getAccommodationPositionMwst() {
		return accommodationPositionMwst;
	}

	public void setAccommodationPositionMwst(double accommodationPositionMwst) {
		this.accommodationPositionMwst = accommodationPositionMwst;
	}

	public String getFormattedAccommodationsPositionMwst() {
		return formattedAccommodationsPositionMwst;
	}

	public void setFormattedAccommodationsPositionMwst(String formattedAccommodationsPositionMwst) {
		this.formattedAccommodationsPositionMwst = formattedAccommodationsPositionMwst;
	}

	public String getInvoiceNumber() {
		return invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

}

package com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.schema;

import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.common.exception.PersistenceException;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.Guest;

import java.util.List;

public interface IGuestRepository {

    public int create(Guest guest) throws PersistenceException;

    public List<Guest> getAll() throws PersistenceException;

    public boolean update(int guestId, Guest guest);

    public Guest getDataset(int guestId);

    public boolean delete(int guestId);
}


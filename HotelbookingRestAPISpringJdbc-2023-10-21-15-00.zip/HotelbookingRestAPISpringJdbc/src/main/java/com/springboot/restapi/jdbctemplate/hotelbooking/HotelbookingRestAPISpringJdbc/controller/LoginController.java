package com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.controller;

import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.Guest;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.Login;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.schema.ILoginRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@CrossOrigin(origins = "http://localhost:8088")
@RestController
@RequestMapping("/api/logins")
public class LoginController {

    @Autowired
    ILoginRepository loginRepository;

    @GetMapping("/")
    public ResponseEntity<List<Login>> getAllLogins() {
        try {
            List<Login> logins = new ArrayList<Login>();

                for(Login login : loginRepository.getAll()) {
                    login.setHasData(true);
                    logins.add(login);
                }

            if (logins.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(logins, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<Login> getLogin(@PathVariable("id") int id) {
        Login login = loginRepository.getDataset(id);

        if (login != null) {
            return new ResponseEntity<>(login, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping("/")
    public ResponseEntity<Integer> createLogin(@RequestBody Login login) {
        try {
            Integer newLoginId = loginRepository.create(login);
            return new ResponseEntity<>(newLoginId, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(0, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<Integer> updateLogin(@PathVariable("id") int id, @RequestBody Login login) {
        try {
            loginRepository.update(id, login);
            return new ResponseEntity<>(id, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/data-by-username/{username}")
    public ResponseEntity<Login> getDatasetByUsername(@PathVariable("username") String username) {
        Login login =  loginRepository.getDatasetByUsername(username);

        if (login != null) {
            return new ResponseEntity<>(login, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

    }

    @GetMapping("/check/{name}/{password}")
    public Boolean checkLogin(@PathVariable("name") String name, @PathVariable("password") String password) {
        return loginRepository.checkLogin(name, password);
    }


    @GetMapping("/id-by-username/{username}")
    public int getIdByUsername(@PathVariable("username") String username) {
        return loginRepository.getIdByUsername(username);
    }


    @GetMapping("/id-by-loginname/{loginname}")
    public int getIdByLoginname(@PathVariable("loginname") String loginname) {
        return loginRepository.getIdByLoginname(loginname);
    }

}
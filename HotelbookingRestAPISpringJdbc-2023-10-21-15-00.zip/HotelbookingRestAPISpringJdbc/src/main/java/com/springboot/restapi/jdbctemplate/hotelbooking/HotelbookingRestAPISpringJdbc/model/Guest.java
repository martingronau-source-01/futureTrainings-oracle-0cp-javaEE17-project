package com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model;

import java.util.Objects;

public class Guest {

	private int id = 0;
	private String firstName = "";
	private String lastName = "";
	private String companyName = "";
	private String birthDate;

	private String street = "";
	private String zipcode = "";
	private String location = "";
	private String email = "";


	private String phone = "";
	private boolean business = false;
	private boolean regularCustomer = false;

	private String creator = "";
	private String created = "";
	private boolean hasData = false;

	public Guest() {
		super();
	}

	public Guest(int id, String firstName, String lastName, String birthDate, String street, String zipcode,
			String location, String email, String phone, boolean business, boolean regularCustomer, String creator,
			String created, boolean hasData) {
		this(firstName, lastName, birthDate, street, zipcode, location, email, phone, business, regularCustomer,
				creator, created, hasData);
		this.id = id;
	}

	public Guest(String firstName, String lastName, String birthDate, String street, String zipcode, String location,
			String email, String phone, boolean business, boolean regularCustomer, String creator, String created,
			boolean hasData) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.birthDate = birthDate;
		this.street = street;
		this.zipcode = zipcode;
		this.location = location;
		this.email = email;
		this.phone = phone;
		this.business = business;
		this.regularCustomer = regularCustomer;
		this.creator = creator;
		this.created = created;
		this.hasData = hasData;
	}

	@Override
	public int hashCode() {
		return Objects.hash(birthDate, business, companyName, created, creator, email, firstName, hasData, id, lastName,
				location, phone, regularCustomer, street, zipcode);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Guest other = (Guest) obj;
		return Objects.equals(birthDate, other.birthDate) && business == other.business
				&& Objects.equals(companyName, other.companyName) && Objects.equals(created, other.created)
				&& Objects.equals(creator, other.creator) && Objects.equals(email, other.email)
				&& Objects.equals(firstName, other.firstName) && hasData == other.hasData && id == other.id
				&& Objects.equals(lastName, other.lastName) && Objects.equals(location, other.location)
				&& Objects.equals(phone, other.phone) && regularCustomer == other.regularCustomer
				&& Objects.equals(street, other.street) && Objects.equals(zipcode, other.zipcode);
	}

	@Override
	public String toString() {
		return "Guest [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", companyName="
				+ companyName + ", birthDate=" + birthDate + ", street=" + street + ", zipcode=" + zipcode
				+ ", location=" + location + ", email=" + email + ", phone=" + phone + ", business=" + business
				+ ", regularCustomer=" + regularCustomer + ", creator=" + creator + ", created=" + created
				+ ", hasData=" + hasData + "]";
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(String birthDate) {
		this.birthDate = birthDate;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public boolean isBusiness() {
		return business;
	}

	public void setBusiness(boolean business) {
		this.business = business;
	}

	public boolean isRegularCustomer() {
		return regularCustomer;
	}

	public void setRegularCustomer(boolean regularCustomer) {
		this.regularCustomer = regularCustomer;
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public String getCreated() {
		return created;
	}

	public void setCreated(String created) {
		this.created = created;
	}

	public boolean isHasData() {
		return hasData;
	}

	public void setHasData(boolean hasData) {
		this.hasData = hasData;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
}

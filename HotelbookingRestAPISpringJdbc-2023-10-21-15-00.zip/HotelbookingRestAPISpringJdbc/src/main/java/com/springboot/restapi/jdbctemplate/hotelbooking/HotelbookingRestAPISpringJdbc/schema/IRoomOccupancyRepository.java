package com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.schema;

import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.common.exception.PersistenceException;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.Room;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.Booking;

import java.util.List;

public interface IRoomOccupancyRepository {

    public List<Room> listFreeRooms(Booking booking) throws PersistenceException;

    public Room getNextFreeRoom(Booking booking);
}


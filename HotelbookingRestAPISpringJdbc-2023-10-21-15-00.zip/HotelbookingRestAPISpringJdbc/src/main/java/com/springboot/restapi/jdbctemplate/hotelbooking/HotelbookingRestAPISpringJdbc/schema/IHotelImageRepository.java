package com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.schema;

import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.common.exception.PersistenceException;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.HotelImage;

import java.util.List;

public interface IHotelImageRepository {

    public int create(HotelImage hotelImage) throws PersistenceException;

    public List<HotelImage> getAll() throws PersistenceException;

    public List<HotelImage> getAllByHotel(int hotelId) throws PersistenceException;

    public boolean update(int hotelId, int optionId, HotelImage option);

    public HotelImage getDataset(int hotelId, int optionId);

    public boolean delete(int hotelId, int optionId);
}

package com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.rowmapper;

import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.common.DBUtils;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.Hotelbooking;

import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

public class HotelbookingRowMapper implements RowMapper<Hotelbooking>  {
    @Override
    public Hotelbooking mapRow(ResultSet resultSet, int rowNum) throws SQLException {

        Hotelbooking hotelBooking = new Hotelbooking();

        LocalDate startDate = LocalDate.parse(resultSet.getString("start_date"),  DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        LocalDate endDate = LocalDate.parse(resultSet.getString("end_date"),  DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        double accommodationPositionMwst = resultSet.getDouble("accommodations_raw_price") * 0.19;

        hotelBooking.setId(resultSet.getInt("id"));
        hotelBooking.setStartDate(startDate.format(DBUtils.CUSTOM_FORMATTER_GERMAN_SHORT));
        hotelBooking.setEndDate(endDate.format(DBUtils.CUSTOM_FORMATTER_GERMAN_SHORT));
        hotelBooking.setHotelId(resultSet.getInt("hotel_id"));
        hotelBooking.setRoomOccupancyId(resultSet.getInt("room_occupancy_id"));
        hotelBooking.setPaymentId(resultSet.getInt("payment_id"));
        hotelBooking.setRoomId(resultSet.getInt("room_id"));
        hotelBooking.setAccommodationsRawPrice(resultSet.getDouble("accommodations_raw_price"));
        hotelBooking.setFormattedAccommodationsRawPrice(DecimalFormat.getCurrencyInstance(Locale.GERMANY)
                .format(hotelBooking.getAccommodationsRawPrice()));
        hotelBooking.setCountAccommodations(resultSet.getInt("count_accommodations"));
        hotelBooking.setAccommodationPositionMwst(Math.round(accommodationPositionMwst * 100) / 100.0);
        hotelBooking.setFormattedAccommodationsPositionMwst(DecimalFormat.getCurrencyInstance(Locale.GERMANY)
                .format(hotelBooking.getAccommodationPositionMwst()));
        hotelBooking.setGuestId(resultSet.getInt("guest_id"));
        hotelBooking.setBookingId(resultSet.getInt("booking_id"));
        hotelBooking.setRoomName(resultSet.getString("room_name"));
        hotelBooking.setRoomTitle(resultSet.getString("room_title"));
        hotelBooking.setTotalcost(resultSet.getDouble("totalcost"));
        hotelBooking.setFormattedTotalcost(
                DecimalFormat.getCurrencyInstance(Locale.GERMANY).format(hotelBooking.getTotalcost()));
        hotelBooking.setMwst(resultSet.getDouble("mwst"));
        hotelBooking.setFormattedMwst(
                DecimalFormat.getCurrencyInstance(Locale.GERMANY).format(hotelBooking.getMwst()));
        hotelBooking.setHotelName(resultSet.getString("hotel_name"));
        hotelBooking.setHotelTitle(resultSet.getString("hotel_title"));
        hotelBooking.setCreator(resultSet.getString("creator"));
        hotelBooking.setCreated(resultSet.getString("created"));
        hotelBooking.setSingleRawPrice(resultSet.getDouble("single_raw_price"));
        hotelBooking.setFormattedSingleRawPrice(
                DecimalFormat.getCurrencyInstance(Locale.GERMANY).format(hotelBooking.getSingleRawPrice()));
        hotelBooking.setHotelEMail(resultSet.getString("hotel_email"));
        hotelBooking.setHotelWebsite(resultSet.getString("hotel_website"));
        hotelBooking.setHotelStreet(resultSet.getString("hotel_street"));
        hotelBooking.setHotelZipcode(resultSet.getString("hotel_zipcode"));
        hotelBooking.setHotelLocation(resultSet.getString("hotel_location"));
        hotelBooking.setRegionName(resultSet.getString("region_name"));
        hotelBooking.setRegionTitle(resultSet.getString("region_title"));
        hotelBooking.setInvoiceNumber(resultSet.getString("invoice_number"));
        hotelBooking.setHasData(true);


        return hotelBooking;
    }
}

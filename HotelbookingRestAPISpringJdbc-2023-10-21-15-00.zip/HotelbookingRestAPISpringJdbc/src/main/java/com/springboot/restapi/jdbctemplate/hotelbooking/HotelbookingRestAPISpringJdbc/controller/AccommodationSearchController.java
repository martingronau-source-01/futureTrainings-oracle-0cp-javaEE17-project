package com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.controller;

import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.AccommodationSearchResult;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.Room;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.schema.IAccommodationSearchRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;


@CrossOrigin(origins = "http://localhost:8088")
@RestController
@RequestMapping("/api/accommodation-search")
public class AccommodationSearchController {

    @Autowired
    IAccommodationSearchRepository accommodationSearchResultRepository;

    @GetMapping("/standard/{region}/{startDate}/{endDate}/{amountOfGuests}/{numberOfRooms}")
    public ResponseEntity<List<AccommodationSearchResult>> searchOvernightStay(@PathVariable("region") String region,
                                                                               @PathVariable("startDate") String startDate,
                                                                               @PathVariable("endDate") String endDate,
                                                                               @PathVariable("amountOfGuests") int amountOfGuests,
                                                                               @PathVariable("numberOfRooms") int numberOfRooms) {
        try {
            List<AccommodationSearchResult> accommodationSearchResults = new ArrayList<>();

            for (AccommodationSearchResult accommodationSearchResult : accommodationSearchResultRepository.searchOvernightStay(
                    region, startDate, endDate, amountOfGuests, numberOfRooms)) {
                accommodationSearchResult.setHasData(true);
                if(accommodationSearchResult.getStartDate() == null || accommodationSearchResult.getStartDate().isEmpty()) {
                    accommodationSearchResult.setStartDate(startDate);
                }
                if(accommodationSearchResult.getEndDate() == null || accommodationSearchResult.getEndDate().isEmpty()) {
                    accommodationSearchResult.setEndDate(endDate);
                }
                accommodationSearchResults.add(accommodationSearchResult);
            }

            if (accommodationSearchResults.isEmpty()) {
                accommodationSearchResults.add(new AccommodationSearchResult());
                return new ResponseEntity<>(accommodationSearchResults, HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(accommodationSearchResults, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/extended/{region}/{startDate}/{endDate}/{amountOfGuests}/{numberOfRooms}/{hotelOptions}/{roomFeatures}")
    public ResponseEntity<List<AccommodationSearchResult>> searchOvernightStayExtended(@PathVariable("region") String region,
                                                                                       @PathVariable("startDate") String startDate,
                                                                                       @PathVariable("endDate") String endDate,
                                                                                       @PathVariable("amountOfGuests") int amountOfGuests,
                                                                                       @PathVariable("numberOfRooms") int numberOfRooms,
                                                                                       @PathVariable("hotelOptions") String hotelOptions, @PathVariable("roomFeatures") String roomFeatures) {
        try {
            List<AccommodationSearchResult> accommodationSearchResults = new ArrayList<>();


            // --------- Comma separated Lists hotelOptions and roomFeatures to List<Integer>
            List<Integer> convertedHotelOptionList = Stream.of(hotelOptions.split(","))
                    .map(String::trim)
                    .map(Integer::parseInt)
                    .collect(Collectors.toList());
            //------------------------------------------
            convertedHotelOptionList.forEach(System.out::println);


            List<Integer> convertedRoomFeatureList = Stream.of(roomFeatures.split(","))
                    .map(String::trim)
                    .map(Integer::parseInt)
                    .collect(Collectors.toList());

            for (AccommodationSearchResult accommodationSearchResult : accommodationSearchResultRepository.searchOvernightStayExtended(
                    region, startDate, endDate, amountOfGuests, numberOfRooms, convertedHotelOptionList, convertedRoomFeatureList)) {
                accommodationSearchResult.setHasData(true);
                if(accommodationSearchResult.getStartDate() == null || accommodationSearchResult.getStartDate().isEmpty()) {
                    accommodationSearchResult.setStartDate(startDate);
                }
                if(accommodationSearchResult.getEndDate() == null || accommodationSearchResult.getEndDate().isEmpty()) {
                    accommodationSearchResult.setEndDate(endDate);
                }
                accommodationSearchResults.add(accommodationSearchResult);
            }

            if (accommodationSearchResults.isEmpty()) {
                accommodationSearchResults.add(new AccommodationSearchResult());
                return new ResponseEntity<>(accommodationSearchResults, HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(accommodationSearchResults, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/standard-rooms/{region}/{startDate}/{endDate}/{amountOfGuests}/{numberOfRooms}")
    public ResponseEntity<List<Room>> searchOvernightStayRooms(@PathVariable("region") String region,
                                                               @PathVariable("startDate") String startDate,
                                                               @PathVariable("endDate") String endDate,
                                                               @PathVariable("amountOfGuests") int amountOfGuests,
                                                               @PathVariable("numberOfRooms") int numberOfRooms) {
        try {
            List<Room> accommodationSearchRooms = new ArrayList<>();
            for (Room accommodationSearchRoom : accommodationSearchResultRepository.searchOvernightStayRooms(region, startDate, endDate,
                    amountOfGuests, numberOfRooms)) {
                accommodationSearchRoom.setHasData(true);
                accommodationSearchRooms.add(accommodationSearchRoom);
            }

            if (accommodationSearchRooms.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(accommodationSearchRooms, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

}
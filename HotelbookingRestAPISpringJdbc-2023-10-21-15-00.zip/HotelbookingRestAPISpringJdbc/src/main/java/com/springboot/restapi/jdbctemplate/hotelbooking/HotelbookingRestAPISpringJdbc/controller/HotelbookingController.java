package com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.controller;

import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.HotelOption;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.Hotelbooking;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.Region;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.schema.IHotelbookingRepository;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.schema.IOptionRepository;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.service.HotelbookingDataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;


@CrossOrigin(origins = "http://localhost:8088")
@RestController
@RequestMapping("/api/hotelbookings")
public class HotelbookingController {

    @Autowired
    HotelbookingDataService hotelbookingDataService;


    @GetMapping("/{id}")
    public ResponseEntity<Hotelbooking> getHotelbooking(@PathVariable("id") int hotelbookingId) {
        Hotelbooking hotelbooking = hotelbookingDataService.getHotelbooking(hotelbookingId);

        if (hotelbooking != null) {
            return new ResponseEntity<>(hotelbooking, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(new Hotelbooking(), HttpStatus.NO_CONTENT);
        }
    }


    @GetMapping("/data-by-user/{userid}")
    public ResponseEntity<List<Hotelbooking>> getHotelbookingsByUser(@PathVariable("userid") int userId) {

        try {
            List<Hotelbooking> hotelbookings = new ArrayList<>();


            for (Hotelbooking hotelbooking : hotelbookingDataService.getAllByUser(userId)) {
                hotelbooking.setHasData(true);
                hotelbookings.add(hotelbooking);
            }

            if (hotelbookings.isEmpty()) {
                hotelbookings.add(new Hotelbooking());
                return  new ResponseEntity<>(hotelbookings, HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(hotelbookings, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/")
    public ResponseEntity<Integer> bookAccomodation(@RequestBody Hotelbooking hotelbooking) {
        try {
            Integer newBookingId = hotelbookingDataService.bookAccomodation(hotelbooking);

            return new ResponseEntity<>(newBookingId, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<Integer> updateBooking(@PathVariable("id") int hotelbookingId,@RequestBody Hotelbooking hotelbooking) {
        try {
            Integer retVal = hotelbookingDataService.updateBooking(hotelbookingId, hotelbooking);
            return new ResponseEntity<>(retVal, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(0, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Integer> cancelBooking(@PathVariable("id") int id) {
        try {
            Integer retVal = hotelbookingDataService.cancelBooking(id);
            return new ResponseEntity<>(retVal, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(0, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
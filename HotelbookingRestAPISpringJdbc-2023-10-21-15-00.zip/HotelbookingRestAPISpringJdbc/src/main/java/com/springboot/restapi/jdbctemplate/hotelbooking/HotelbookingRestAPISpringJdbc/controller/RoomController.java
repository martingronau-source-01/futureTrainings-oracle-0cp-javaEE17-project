package com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.controller;

import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.Room;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.schema.IRoomRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;


@CrossOrigin(origins = "http://localhost:8088")
@RestController
@RequestMapping("/api/rooms")
public class RoomController {

    @Autowired
    IRoomRepository roomRepository;

    @GetMapping("/")
    public ResponseEntity<List<Room>> getAllRooms() {
        try {
            List<Room> rooms = new ArrayList<>();

            for (Room room : roomRepository.getAll()) {
                room.setHasData(true);
                rooms.add(room);
            }

            if (rooms.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(rooms, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<Room> getRoom(@PathVariable("id") int id) {
        Room room = roomRepository.getDataset(id);

        if (room != null) {
            return new ResponseEntity<>(room, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/by-roomfeature/{roomFeatureid}")
    public ResponseEntity<List<Room>> getRoomsByRoomFeature(@PathVariable("roomFeatureid") int roomFeatureId) {

        try {
            List<Room> rooms = new ArrayList<Room>();

            for (Room room : roomRepository.getAllByRoomFeature(roomFeatureId)) {
                room.setHasData(true);
                rooms.add(room);
            }

            if (rooms.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(rooms, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/")
    public ResponseEntity<Integer> createRoom(@RequestBody Room room) {
        try {
            Integer newRoomId = roomRepository.create(room);
            return new ResponseEntity<>(newRoomId, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(0, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<Integer> updateRoom(@PathVariable("id") int id, @RequestBody Room room) {
        try {
            roomRepository.update(id, room);
            return new ResponseEntity<>(id, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(0, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Integer> deleteRoom(@PathVariable("id") int id) {
        try {
            roomRepository.delete(id);
            return new ResponseEntity<>(id, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(0, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
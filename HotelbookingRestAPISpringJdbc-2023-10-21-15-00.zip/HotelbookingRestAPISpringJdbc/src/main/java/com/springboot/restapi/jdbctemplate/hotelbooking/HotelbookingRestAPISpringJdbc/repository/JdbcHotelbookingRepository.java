package com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.repository;

import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.common.DBUtils;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.common.exception.PersistenceException;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.Booking;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.Hotelbooking;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.RoomOccupancy;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.rowmapper.HotelbookingRowMapper;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.schema.IHotelbookingRepository;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.service.RoomOccupancyDataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;


import java.time.LocalDateTime;
import java.util.List;

@Repository
public class JdbcHotelbookingRepository implements IHotelbookingRepository {

    private final String SQLSELECTALL_BY_USER = "SELECT 0 AS id, b.id AS booking_id, b.start_date, b.end_date, b.hotel_id, "
            + "roc.guest_id, b.payment_id, b.room_occupancy_id, b.accommodations_raw_price, b.creator, b.created, "
            + "DATEDIFF(b.end_date, b.start_date) AS count_accommodations,roc.room_id, r.name AS room_name, r.title AS room_title,"
            + "p.totalcost, p.mwst, h.title AS hotel_title, h.name AS hotel_name, r.accommodation_cost AS single_raw_price, "
            + "h.street AS hotel_street, h.zipcode AS hotel_zipcode, h.location AS hotel_location,h.email AS hotel_email,"
            + "h.website AS hotel_website, rg.name AS region_name, rg.title AS region_title, p.invoice_number "
            + "FROM booking b "
            + "LEFT OUTER JOIN room_occupancy roc ON b.room_occupancy_id = roc.id "
            + "LEFT OUTER JOIN room r ON roc.room_id = r.id "
            + "LEFT OUTER JOIN hotel h ON r.hotel_id = h.id "
            + "LEFT OUTER JOIN region rg ON h.region_id = rg.id "
            + "LEFT OUTER JOIN payment p ON b.payment_id = p.id "
            + "LEFT OUTER JOIN guest g ON roc.guest_id = g.id "
            + "WHERE g.id = ? ";

    private final String SQLSELECTSINGLE = "SELECT 0 AS id,b.id AS booking_id, b.start_date, b.end_date, b.hotel_id, "
            + "roc.guest_id, b.payment_id, b.room_occupancy_id, b.accommodations_raw_price, b.creator, b.created, "
            + "DATEDIFF(b.end_date, b.start_date) AS count_accommodations,roc.room_id, r.name AS room_name, r.title AS room_title,"
            + "p.totalcost, p.mwst, h.title AS hotel_title, h.name AS hotel_name, r.accommodation_cost AS single_raw_price, "
            + "h.street AS hotel_street, h.zipcode AS hotel_zipcode, h.location AS hotel_location,h.email AS hotel_email,"
            + "h.website AS hotel_website, rg.name AS region_name, rg.title AS region_title, p.invoice_number "
            + "FROM booking b "
            + "LEFT OUTER JOIN room_occupancy roc ON b.room_occupancy_id = roc.id "
            + "LEFT OUTER JOIN room r ON roc.room_id = r.id "
            + "LEFT OUTER JOIN hotel h ON r.hotel_id = h.id "
            + "LEFT OUTER JOIN region rg ON h.region_id = rg.id "
            + "LEFT OUTER JOIN payment p ON b.payment_id = p.id "
            + "LEFT OUTER JOIN guest g ON roc.guest_id = g.id "
            + "WHERE b.id = ? ";

    private final String SQLBOOK_ROOM_TO_ACCOMODATION = "INSERT INTO room_occupancy(start_date, end_date, "
            + "guest_id, room_id, creator, created) VALUES(?,?,?,?,?,?)";

    private final String SQLBOOK_ACCOMODATION = "INSERT INTO booking(start_date, end_date, hotel_id,"
            + "room_occupancy_id, payment_id, accommodations_raw_price, creator,created) VALUES(?,?,?,?,?,?,?,?)";
    private final String SQLUPDATE = "UPDATE booking SET start_date = ?, end_date = ?, hotel_id = ?,"
            + "room_occupancy_id = ?, payment_id = ?,accommodations_raw_price = ? WHERE id = ?";
    private final String SQLCANCEL = "DELETE b,p,roc FROM `booking` b "
            + "LEFT OUTER JOIN payment p ON b.payment_id = p.id "
            + "LEFT OUTER JOIN room_occupancy roc ON b.room_occupancy_id = roc.id "
            + "WHERE b.id = ? ";

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public List<Hotelbooking> getAllByUser(int userId) throws PersistenceException {
        try {
            return jdbcTemplate.query(SQLSELECTALL_BY_USER,
                    new HotelbookingRowMapper(), userId);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return null;
        }
    }

    @Override
    public int bookAccomodation(Hotelbooking hotelbooking) throws PersistenceException {

        hotelbooking.setCreated(LocalDateTime.now().format(DBUtils.CUSTOM_FORMATTER));
        hotelbooking.setCreator(DBUtils.DEFAULT_CREATOR);

        try {
            int roomOccupancyId = this.bookRoom2Accomodation(hotelbooking);

            int iReturn = 0;
            if(jdbcTemplate.update(SQLBOOK_ACCOMODATION, hotelbooking.getStartDate(), hotelbooking.getEndDate(),
                    hotelbooking.getHotelId(), roomOccupancyId, hotelbooking.getPaymentId(),
                    hotelbooking.getAccommodationsRawPrice(), hotelbooking.getCreator(), hotelbooking.getCreated()) > 0) {
                Integer newBookingId = jdbcTemplate.queryForObject("SELECT LAST_INSERT_ID()", Integer.class);
                iReturn = newBookingId.intValue();
            }

            return iReturn;
        } catch (IncorrectResultSizeDataAccessException e) {
            System.out.println(e.getMessage());
            return 0;
        }

    }

    @Override
    public int cancelBooking(int bookingId) {
        return jdbcTemplate.update(SQLCANCEL, bookingId) > 0 ? bookingId : 0;
    }

    @Override
    public int updateBooking(int bookingId, Hotelbooking booking) {
        return jdbcTemplate.update(SQLUPDATE,
                booking.getStartDate(), booking.getEndDate(), booking.getHotelId(), booking.getRoomOccupancyId(),
                booking.getPaymentId(), booking.getAccommodationsRawPrice(), bookingId) > 0 ? bookingId : 0;
    }

    @Override
    public int bookRoom2Accomodation(Booking booking) throws PersistenceException {

        int roomOccupancyId = 0;

        if (booking.getRoomId() == 0) {
            RoomOccupancyDataService roomOccupancyDataService = new RoomOccupancyDataService();
            booking.setRoomId(roomOccupancyDataService.getNextFreeRoom(booking).getId());
        }


        String SQL_CHECK_1 = "SELECT ro.id, ro.room_id, ro.guest_id "
                + "FROM room_occupancy ro "
                + "INNER JOIN guest g ON ro.guest_id = g.id  "
                + "INNER JOIN room r ON ro.room_id = r.id "
                + "WHERE ro.room_id = ? AND ro.start_date >= ?  AND ro.end_date <= ?";

        List<RoomOccupancy> roomOccupancies = jdbcTemplate.query(SQL_CHECK_1,
                BeanPropertyRowMapper.newInstance(RoomOccupancy.class), booking.getRoomId(), booking.getStartDate(),
                booking.getEndDate());

        if (!roomOccupancies.isEmpty()) {
            for (RoomOccupancy roomOccupancy : roomOccupancies) {
                if (roomOccupancy.getGuestId() == booking.getGuestId()) {
                    roomOccupancyId = roomOccupancy.getId();
                    break;
                }
            }
        } else {
            if(jdbcTemplate.update(SQLBOOK_ROOM_TO_ACCOMODATION, booking.getStartDate(),
                    booking.getEndDate(), booking.getGuestId(), booking.getRoomId(), booking.getCreator(), booking.getCreated()) > 0) {
                Integer newRoomOccupancyId = jdbcTemplate.queryForObject("SELECT LAST_INSERT_ID()", Integer.class);
                roomOccupancyId =  newRoomOccupancyId.intValue();
            } else {
                roomOccupancyId = 0;
            }

        }

        return roomOccupancyId;
    }

    @Override
    public Hotelbooking getDataset(int bookingId) throws PersistenceException {
        if (bookingId > 0) {
            return jdbcTemplate.queryForObject(SQLSELECTSINGLE,  new HotelbookingRowMapper(), bookingId);
        } else {
            return new Hotelbooking();
        }
    }

}

package com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.common.enums;

public enum eRoleTypes {
	NO_ROLE(0), GUEST_ROLE(1), MODERATOR_ROLE(2), MANAGER_ROLE(3), ADMIN_ROLE(4), SUPERADMIN_ROLE(5);

	private int value;

	private eRoleTypes(int value) {
		this.value = value;
	}

	public int getValue() {
		return value;
	}
}

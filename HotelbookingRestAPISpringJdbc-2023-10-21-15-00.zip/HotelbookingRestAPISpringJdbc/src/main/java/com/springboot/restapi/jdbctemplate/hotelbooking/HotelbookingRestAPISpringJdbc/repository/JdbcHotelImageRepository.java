package com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.repository;

import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.common.exception.PersistenceException;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.HotelImage;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.schema.IHotelImageRepository;

import java.util.List;

public class JdbcHotelImageRepository implements IHotelImageRepository {
    @Override
    public int create(HotelImage hotelImage) throws PersistenceException {
        return 0;
    }

    @Override
    public List<HotelImage> getAll() throws PersistenceException {
        return null;
    }

    @Override
    public List<HotelImage> getAllByHotel(int hotelId) throws PersistenceException {
        return null;
    }

    @Override
    public boolean update(int hotelId, int optionId, HotelImage option) {
        return false;
    }

    @Override
    public HotelImage getDataset(int hotelId, int optionId) {
        return null;
    }

    @Override
    public boolean delete(int hotelId, int optionId) {
        return false;
    }
}

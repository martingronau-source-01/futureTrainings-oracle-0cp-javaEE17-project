package com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.repository;

import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.common.exception.PersistenceException;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.model.RoomImage;
import com.springboot.restapi.jdbctemplate.hotelbooking.HotelbookingRestAPISpringJdbc.schema.IRoomImageRepository;

import java.util.List;

public class JdbcRoomImageRepository implements IRoomImageRepository {
    @Override
    public int create(RoomImage roomImage) throws PersistenceException {
        return 0;
    }

    @Override
    public List<RoomImage> getAll() throws PersistenceException {
        return null;
    }

    @Override
    public List<RoomImage> getAllByRoom(int roomId) throws PersistenceException {
        return null;
    }

    @Override
    public boolean update(int roomId, int optionId, RoomImage option) {
        return false;
    }

    @Override
    public RoomImage getDataset(int roomId, int optionId) {
        return null;
    }

    @Override
    public boolean delete(int roomId, int optionId) {
        return false;
    }
}
